/*
     MTZ2CIF_LIB
     Copyright (C) 2005 Peter Briggs

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK
*/

/* mtz2cif_lib.c

   Header for pseudo-library for MTZ2CIF program

*/
#include <ccp4/cmtzlib.h>
#include <ccp4/ccp4_general.h>

/*********************************************
 * MTZ-related functions
 *********************************************/

/** Returns the wavelength associated with an MTZ dataset
 * @param set (I) Pointer to MTZ dataset struct
 * @return Wavelength in Angstroms
 */
float MtzSetWavelength(MTZSET *set);

/** Returns the label of a column (not the full path, i.e. without
 ** the leading crystal and dataset names)
 * @param col (I) Pointer to MTZ column struct
 * @return Pointer to column label
 */
char *MtzColLabel(MTZCOL *col);

/** Returns the data stored in the irefl'th reflection of the 
 ** specified MTZ column, converted to an integer
 * @param col (I) Pointer to MTZ column struct
 * @param irefl (I) Number of reflection in the list of reflections
 * @return Integer value of data
 */
int MtzColDataInt(MTZCOL *col, int irefl);

/** Returns the data stored in the irefl'th reflection of the 
 ** specified MTZ column, as a float
 * @param col (I) Pointer to MTZ column struct
 * @param irefl (I) Number of reflection in the list of reflections
 * @return Float value of data
 */
float MtzColDataFloat(MTZCOL *col, int irefl);

/*********************************************
 * Symop-related functions
 *********************************************/

/** Returns the number of symops in a spacegroup
 * @param ccp4_spg (I) Pointer to the spacegroup structure
 * @return Number of symmetry operations
 */
int GetNSymops(CCP4SPG *ccp4_spg);

/** Returns the extended Hermann-Macguin symbol for the spacegroup
 * @param ccp4_spg (I) Pointer to the spacegroup structure
 * @return Pointer to the xHM symbol string
 */
char *GetxHMSymbol(CCP4SPG *ccp4_spg);

/** Returns the i'th symop in the specified spacegroup, as a
 ** 4x4 symmetry matrix
 * @param ccp4_spg (I) Pointer to spacegroup structure
 * @param i (I) Position of the symop in the list
 * @param rsymm (O) Symmetry matrix (4x4)
 * @return 1 on success, 0 on failure
 */
int GetRsymMatrix(CCP4SPG *ccp4_spg, int i, float rsym[4][4]);

/** Returns the string representation of a symop which is
 ** supplied as a 4x4 symmetry matrix
 * @param rsymm (I) Symmetry matrix (4x4)
 * @param symch (I) Pointer to a string which the symop will be written to
 * @param n (I) Length of symch
 * @return 1 on success, 0 on failure
 */
int GetSymopString(float rsym[4][4], char *symch, int n);

/*********************************************
 * General CCP4 library-style functions
 *********************************************/

/** Echo the logical name and associated file name
 ** to the requested output stream
 * @param fp (I) Output stream to write to
 * @param logicalname (I) Logical name to write
 * @return 1 if the logical name has a non-NULL associated
 * value (filename) and 0 if not.
 */
int WriteLogicalName(FILE *fp, char *logicalname);
