/*
     MTZ2CIF
     Copyright (C) 2005 Peter Briggs

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK
*/

/* mtz2cif.c

   Export an MTZ file to CIF format
   Also needs the functions in mtz2cif_lib.c

   To compile:
   gcc -c -o mtz2cif_lib.o mtz2cif_lib.c -I${CLIBS}
   gcc -c -o mtz2cif.o mtz2cif.c -I${CLIBS}
   gcc -o mtz2cif mtz2cif.o mtz2cif_lib.o -L${CLIB} -lccp4c -lm

*/

/****************************************************************
 * Headers
 ****************************************************************/

#include <math.h>
#include <ccp4/cmtzlib.h>
#include <ccp4/ccp4_parser.h>
#include <ccp4/ccp4_general.h>
#include <ccp4/csymlib.h>
#include "mtz2cif_lib.h"

/****************************************************************
 * Define constants
 ****************************************************************/

/* Define numbers as constants not macros
   Kernighan and Pike, "The Practice of Programming" */

static char MTZ2CIF_VERSION[] = "0.9";

/* Some limits */
enum {
  MAX_N_COLS = 200,
  MAX_N_DATASETS = 10,
/* Number of program labels recognised by the program
   This must be consistent with the number of labels declared in
   mtz_labels, mtz_types and cif_labels_* */
  N_PROG_LABELS = 25,
  MAX_LINE_LEN = 1000
};

/****************************************************************
 * CIF dataset structure
 ****************************************************************/

typedef struct {
  int crystal_id;        /* CIF crystal number */
  int wavelength_id;     /* CIF wavelength number */
  char labin_line[1000]; /* Labin line supplied for the dataset */
  char user_labels[N_PROG_LABELS][2][31];
                         /* User label assignments derived from
                            the labin line */
  MTZXTAL *xtal;         /* Pointer to associated MTZ crystal */
  MTZSET  *set;          /* Pointer to associated MTZ dataset */
  MTZCOL  *assigned[N_PROG_LABELS];
                         /* Pointers to assigned MTZ labels*/
  int    n_ref_out;      /* Total number of reflections out */
  int    n_ref_obs;      /* Number of observed reflections */
  int    ihmax[3];       /* Maximal indices */
  int    ihmin[3];       /* Minimal indices */
  float  rmin;           /* Minimum resolution */
  float  rmax;           /* Maximum resolution */
} MTZ2CIFDATASET;

/****************************************************************
 * Function prototypes
 ****************************************************************/

int write_cif_category_comment(FILE *fp, char *category);

int write_cif_datablock_header(FILE *fp, MTZ *hklin, char *dbhead,
				int nsets, MTZ2CIFDATASET *dataset,
				CCP4SPG *ccp4_spg, float sigp);

char *ccp4_utils_cifdate(char *date);

char *ccp4ProgramName(const char *progname);

char *ccp4RCSDate(const char *rcs_string);

char *ccp4_prog_vers(const char *progvers);

/****************************************************************
 * Program code
 ****************************************************************/

static char rcsid[] = "$Id$";

/* Main program */

int main(int argc, char **argv) {

  /* Declarations */

  /* Reading MTZ file */
  MTZ *hklin=NULL;
  MTZCOL *col_list[MAX_N_COLS],*col;
  MTZCOL *col_H,*col_K,*col_L,*col_free=NULL;
  MTZXTAL *xtal;
  MTZSET *set;
  CCP4SPG *mtz_spgrp;

  int   ih,ik,il,isysab,hkl[3];
  int   ncol=0,nfree;
  int   ii,i,j,k;
  float dum1,dum2,cell[6],reso_hkl,ref_data[N_PROG_LABELS],free_percent;
  int   present[N_PROG_LABELS],ipresent;
  double coefhkl[6];
  char  *label;

  /* Dealing with multiple CIF datasets */
  int            ndatasets=0;
  MTZ2CIFDATASET dataset[MAX_N_DATASETS],*d;

  /* Dealing with labels */
  /* Pointers to the positions in the mtz_labels array corresponding
     to specific labels */
  int j_f,j_sigf,j_fplus,j_sigfplus;
  int j_fminus,j_sigfminus,j_free;
  /* Array of labels recognised by the program */
  char *mtz_labels[N_PROG_LABELS] =
    { "FP","SIGFP",
      "DP","SIGDP",
      "FC","PHIC",
      "PHIB","FOM",
      "FPART_BULK_S","PHIPART_BULK_S",
      "F(+)","SIGF(+)",
      "F(-)","SIGF(-)",
      "I","SIGI",
      "I(+)","SIGI(+)",
      "I(-)","SIGI(-)",
      "HLA","HLB",
      "HLC","HLD",
      "FREE" };
  /* Array of types corresponding to the labels recognised by
     the program */
  char *mtz_types[N_PROG_LABELS] =
    { "F","Q",
      "D","Q",
      "F","P",
      "P","W",
      "F","P",
      "G","L",
      "G","L",
      "J","Q",
      "K","M",
      "K","M",
      "A","A",
      "A","A",
      "I" };
  /* Array of CCP4 CIF tokens corresponding to the labels
     recognised by the program
     Note that FREER is treated differently from the others
     and so has no corresponding token */
  char *cif_labels_ccp4[N_PROG_LABELS] =
    { "_refln.F_meas_au","_refln.F_meas_sigma_au",
      "_refln.ccp4_SAD_phase_anom","_refln.ccp4_SAD_phase_anom_sigma",
      "_refln.F_calc","_refln.phase_calc",
      "_refln.phase_meas","_refln.fom",
      "_refln.ebi_F_xplor_bulk_solvent_calc",
      "_refln.ebi_phase_xplor_bulk_solvent_calc",
      "_refln.ccp4_SAD_F_meas_plus_au","_refln.ccp4_SAD_F_meas_plus_sigma_au",
      "_refln.ccp4_SAD_F_meas_minus_au","_refln.ccp4_SAD_F_meas_minus_sigma_au",
      "_refln.intensity_meas","_refln.intensity_sigma",
      "_refln.ccp4_I_plus","_refln.ccp4_I_plus_sigma",
      "_refln.ccp4_I_minus","_refln.ccp4_I_minus_sigma",
      "_refln.ccp4_SAD_HL_A_iso","_refln.ccp4_SAD_HL_B_iso",
      "_refln.ccp4_SAD_HL_C_iso","_refln.ccp4_SAD_HL_D_iso",
      "" };
  /* Array of PDBX CIF tokens corresponding to the labels
     recognised by the program
     Note that FREER is treated differently from the others
     and so has no corresponding token */
  char *cif_labels_pdbx[N_PROG_LABELS] =
    { "_refln.F_meas_au","_refln.F_meas_sigma_au",
      "_refln.pdbx_anom_difference","_refln.pdbx_anom_difference_sigma",
      "_refln.F_calc","_refln.phase_calc",
      "_refln.phase_meas","_refln.fom",
      "_refln.ebi_F_xplor_bulk_solvent_calc",
      "_refln.ebi_phase_xplor_bulk_solvent_calc",
      "_refln.pdbx_F_meas_plus","_refln.pdbx_F_meas_plus_sigma",
      "_refln.pdbx_F_meas_minus","_refln.pdbx_F_meas_minus_sigma",
      "_refln.intensity_meas","_refln.intensity_sigma",
      "_refln.pdbx_I_plus","_refln.pdbx_I_plus_sigma",
      "_refln.pdbx_I_minus","_refln.pdbx_I_minus_sigma",
      "_refln.pdbx_HL_A_iso","_refln.pdbx_HL_B_iso",
      "_refln.pdbx_HL_C_iso","_refln.pdbx_HL_D_iso",
      "" };
  char cif_labels[N_PROG_LABELS][50],cif_mode[5];
  char *prog_labels;

  /* Store multiple labin lines */
  int  label_present[N_PROG_LABELS];

  /* Writing out reflections */
  FILE   *fp=NULL,*fptmp=NULL;
  int    ireso=0,idbhead=0,freeval=0;
  float  sigp=0.0;
  char   rstat,*hklout,*tmpout,line0[1000],dbhead[1000];
  double reso_max=-1.0,reso_min=99999.0;

  /* CCP4 parser parameters */
  int           ntok=0,cont;
  char          line[MAX_LINE_LEN+1],*key;
  CCP4PARSERARRAY *parser;

  /****************
    PROGRAM START
  *****************/

  /* Perform CCP4 initialisations */
  ccp4ProgramName ("mtz2cif");
  ccp4RCSDate     ("$Date$");
  ccp4_prog_vers(MTZ2CIF_VERSION);
  ccp4_banner();
  if (ccp4fyp(argc,argv)) {
    ccperror(1,"Error parsing command line (see above)");
  }

  printf(" Maximum number of columns from file: %d\n",MAX_N_COLS);
  printf(" Maximum number of datasets: %d\n\n",MAX_N_DATASETS);

  /* Initialise program labels */
  /* This inane code is based on code from cmtzlib_f.c, function LKYIN */
  prog_labels = (char *) ccp4_utils_malloc(N_PROG_LABELS*31*sizeof(char));
  for (i = 0; i < N_PROG_LABELS; ++i) {
    j = 0;
    while (mtz_labels[i][j] != '\0') {
      prog_labels[i*31+j] = mtz_labels[i][j];
      j++;
    }
    prog_labels[i*31+j] = '\0';
  }
  strncpy(cif_mode,"PDBX",5);

  /* Locate the position of the key columns amongst the program
     labels, and assign these positions to "pointers"

     Nb This adaptive code should free the programmer from the
     requirement to update the pointers whenever new labels are
     added to the program
  */
  j_free = 0;
  j_f = 0;
  j_sigf = 0;
  j_fplus = 0;
  j_sigfplus = 0;
  j_fminus = 0;
  j_sigfminus = 0;
  for (i = 0; i < N_PROG_LABELS; ++i) {
    if (strcmp("FREE",mtz_labels[i]) == 0) {
      j_free = i;
    } else if (strcmp("FP",mtz_labels[i]) == 0) {
      j_f = i;
    } else if (strcmp("SIGFP",mtz_labels[i]) == 0) {
      j_sigf = i;
    } else if (strcmp("F(+)",mtz_labels[i]) == 0) {
      j_fplus = i;
    } else if (strcmp("SIGF(+)",mtz_labels[i]) == 0) {
      j_sigfplus = i;
    }else if (strcmp("F(-)",mtz_labels[i]) == 0) {
      j_fminus = i;
    }else if (strcmp("SIGF(-)",mtz_labels[i]) == 0) {
      j_sigfminus = i;
    }
  }

  /***************************
    Read the keyworded input
  ****************************/
  
  /* Set up the parser
     This is used to return the tokens and associated info
     Set maximum number of tokens per line to 50 */
  parser = (CCP4PARSERARRAY *) ccp4_parse_start(50);
  if (parser == NULL)
    ccperror ( 1,"Couldn't create parser array" );

  /* Set up handy shortcuts */
  key   = parser->keyword;

  /* Read lines from stdin until END/end keyword is entered or
     EOF is reached */
  cont = 1;

  while (cont) {
    /* Blank the line before calling ccp4_parser
       to force reading from stdin */
    line[0] = '\0';

    /* Call ccp4_parser to read input line and break into tokens
       Returns the number of tokens, or zero for eof */
    ntok = ccp4_parser(line,MAX_LINE_LEN,parser,1);

    if (ntok < 1) {
      /* End of file encountered */
      cont = 0;
    } else {      
      /* Lookup keywords */

      /* LABIN keyword */
      if (ccp4_keymatch("LABIN",key) == 1) {
	/* Store the labinline for later processing */
	strncpy(dataset[ndatasets].labin_line,line,1000);
	dataset[ndatasets].labin_line[999] = '\0';
	ndatasets++;
	printf("\n*** Storing LABIN line #%d for later processing\n\n",
	       ndatasets);
      }

      /* RESOLUTION keyword
	 Usage: RESO <res1> <res2> */
      if (ccp4_keymatch("RESOLUTION",key) == 1) {
	/* Syntax is RESO <hi_res> <lo_res> */
	if (parser->ntokens != 3) {
          ccperror(2, "Error: RESO keyword - requires two arguments");
        } else {
	  if (! parser->token[1].isnumber || ! parser->token[2].isnumber) {
	    ccperror(2, "Error: RESO keyword - arguments must be numerical");
	  } else {
	    /* Set ireso to indicate that this keyword was given */
	    ireso = 1;
	    if (parser->token[1].value < parser->token[2].value) {
	      reso_max = parser->token[1].value;
	      reso_min = parser->token[2].value;
	    } else {
	      reso_max = parser->token[2].value;
	      reso_min = parser->token[1].value;
	    }
	    /* Check that the limits are sensible */
	    if (reso_max < 0.0 || reso_min < 0.0 || reso_max == reso_min)
	      ccperror(1,"Nonsense resolution limits supplied");
          }
        }
      }

      /* DATABLOCK keyword
	 Usage: DATA <data_block_header>
	 Datablock header must start with "data_" */
      if (ccp4_keymatch("DATABLOCK",key) == 1) {
	if (parser->ntokens != 2)
	  ccperror(1,"Incorrect number of arguments for DATABLOCK");
	strcpy(dbhead,parser->token[1].fullstring);
	/* Check that datablock name is valid
	   It must start "data_" and not exceed 80 characters
	   in length */
	strncpy(line0,dbhead,5);
        line0[5] = '\0';
	if (strcmp(line0,"data_") != 0)
	  ccperror(1,"Invalid datablock name (must start with \"data_\")");
	if (strlen(dbhead) > 80)
	  ccperror(1,"Invalid datablock name (length exceeds 80 characters)");
	/* Flag that we have a datablock header */
	idbhead = 1;
      }

      /* EXLCUDE_SIGP keyword
	 Usage: EXCL <Nsig1>
	 Reflections are excluded if FP < (<Nsig1>*SIGFP) */
      if (ccp4_keymatch("EXCLUDE_SIGP",key) == 1) {
	if (parser->ntokens != 2)
	  ccperror(1,"Incorrect number of arguments for EXCLUDE_SIGP");
	if (!parser->token[1].isnumber)
	  ccperror(1,"EXCLUDE_SIGP expects a numerical argument");
	sigp = parser->token[1].value;
	if (sigp <= 0.0)
	  ccperror(1,"EXCLUDE_SIGP: value is too small");
      }

      /* FREEVAL keyword
	 Usage: FREE <num>
	 The reflections with FreeRflag = <num> are treated as the freeR
	 set: the default is 0 if FREE is assigned */
      if (ccp4_keymatch("FREEVAL",key) == 1) {
	if (parser->ntokens != 2)
	  ccperror(1,"Incorrect number of arguments for FREEVAL");
	if (!parser->token[1].isnumber)
	  ccperror(1,"FREEVAL expects a single numerical argument");
	freeval = (int) parser->token[1].value;
      }

      /* MODE keyword
	 Usage: MODE PDBX|CCP4
	 Sets which CIF tokens to use (default is the PDBX set) */
      if (ccp4_keymatch("MODE",key) == 1) {
	if (parser->ntokens != 2)
	  ccperror(1,"Incorrect number of arguments for MODE");
	strncpy(cif_mode,parser->token[1].fullstring,5);
	cif_mode[4] = '\0';
      }

      /* END keyword
         Usage: END */
      if (ccp4_keymatch("END",key) && parser->ntokens == 1) {
	printf("END of input\n");
        cont = 0;
      }
    }
      
    /* Loop around to read next line */
  }

  /* Clean up parser array */
  ccp4_parse_end(parser);

  /**************************************
   * Check and report input
   **************************************/

  /* Check the input before proceeding */
  if (!idbhead) {
    /* No data block name was supplied so we cannot proceed */
    ccperror(1,"No data block name supplied! (Use DATABLOCK keyword)");
  }
  
  /* Report the datablock name */
  printf("\nCIF data block name: \"%s\"\n",dbhead);

  /* Do we have anything to output? */
  if (ndatasets == 0)
    ccperror(1,"No LABIN lines supplied - no datasets to output");

  /* Load the appropriate set of CIF tokens to be written out */
  printf("Requested CIF token set (MODE keyword) is \"%s\"\n",cif_mode);
  for ( i=0 ; i<N_PROG_LABELS; i++ ) {
    if (strcmp(cif_mode,"CCP4") == 0)
      strcpy(cif_labels[i],cif_labels_ccp4[i]);
    else if (strcmp(cif_mode,"PDBX") == 0)
      strcpy(cif_labels[i],cif_labels_pdbx[i]);
    else
      ccperror(1,"Unrecognised MODE: only PDBX or CCP4 allowed");
  }

  /* Report user defined resolution limits */
  if (ireso) { 
    printf("\nUser-defined resolution limits: % 8.3f % 8.3f (A)\n",
	   reso_max,reso_min);
    printf("Reflections outside these limits will be flagged in the CIF\n");
  } else {
    printf("\nNo user-defined resolution limits\n");
  }

  /* Other exclusion criteria */
  if (sigp > 0.01)
    printf("\nReflections with F > %5.2f sigma(F) will be excluded\n",
	   sigp);

  /**************************************************
   * Open and read in the MTZ data
   **************************************************/

  /* Open the MTZ file and read into memory */
  printf("\nOpening MTZ file for reading\n");
  WriteLogicalName(stdout,"HKLIN");
  hklin = MtzGet("HKLIN",1);
  if (hklin == NULL)
    ccperror(1, "\nFATAL: failed to read file\n");

  /* Print some information about the file */
  ncol = MtzNcol(hklin);
  printf("\tNumber of columns in file: %d\n",ncol);
  printf("\tSpacegroup: %d\n",MtzSpacegroupNumber(hklin));

  /* Acquire the spacegroup information */
  mtz_spgrp = ccp4spg_load_by_ccp4_num(MtzSpacegroupNumber(hklin));
  if (!mtz_spgrp)
    ccperror (1, "Failed to load spacegroup info from symmetry library");
  else
    printf("Successfully loaded spacegroup info from symmetry library\n");

  /* Get resolution limits if user didn't supply them using the
     keywords */
  if (! ireso) {
    /* Use dummy float arguments and then convert to double later
       Also must convert the resolution values to Angstroms */
    MtzResLimits(hklin,&dum1,&dum2);
    reso_min = (double) 1.0/sqrt(dum1);
    reso_max = (double) 1.0/sqrt(dum2);
    printf("\nResolution limits over all datasets in input file (Angstroms):\n\t% 8.3f % 8.3f\n",reso_max,reso_min);
  }

  /**************************************************
   * Deal with multiple datasets
   * Each LABIN line is a new crystal-dataset pair
   **************************************************/

  /* Initialise for processing */
  xtal = NULL;
  set = NULL;

  /* Process each dataset */
  printf("\nProcessing labin line(s):\n");
  for ( i=0 ; i<ndatasets ; i++ ) {
    printf("\tDataset #%d:",(i+1));
    /* Initialise */
    /* MTZ dataset and crystal */
    dataset[i].xtal = NULL;
    dataset[i].set = NULL;
    /* Statistics */
    dataset[i].n_ref_out=0;
    dataset[i].n_ref_obs=0;
    for (j = 0; j < 3; j++) {
      dataset[i].ihmin[j] = 9999;
      dataset[i].ihmax[j] = -9999;
    }
    dataset[i].rmin=0.0;
    dataset[i].rmax=99999.0;
    /* Parse the associated labin line */
    if ( MtzParseLabin(dataset[i].labin_line,prog_labels,N_PROG_LABELS,
		       dataset[i].user_labels) <= 0 )
      ccperror(1,"\nUnable to extract labels from LABIN line");
    /* Determine the assigments for the first dataset to check
       other datasets against */
    if ( i == 0 ) {
      for ( j=0 ; j<N_PROG_LABELS ; j++) {
	label_present[j] = (strcmp(dataset[0].user_labels[j][0],""));
      }
    }
    /* Check for consistency with first dataset
       Ignore free reflections for now */
    if ( i > 0 ) {
      for ( j=0 ; j<N_PROG_LABELS ; j++) {
	if (strcmp(dataset[i].user_labels[j][0],"") != label_present[j]
	    && j != j_free) {
	  printf(" mismatch in label assignments\n");
	  printf("\nMismatch between LABIN lines for datasets 1 and %d\n",(i+1));
	  if ( !label_present[j] )
	    printf("\tLabel \"%s\" is assigned in %d but not in 1\n",
		   mtz_labels[j],(i+1));
	  else
	    printf("\tLabel \"%s\" is assigned in 1 but not in %d\n",
		   mtz_labels[j],(i+1));
	  ccperror(1,"Label assigments not consistent between datasets");
	}
      }
      /* FREE should only appear on the first LABIN line */
      if ( strcmp(dataset[i].user_labels[j_free][0],"") != 0) {
	printf(" duplication of FREE assignment\n");
	ccperror(1,"FREE can only be assigned on the first LABIN line");
      }
    }
    /* Check the crystal and datasets */
    for ( j=0 ; j<N_PROG_LABELS ; j++ ) {
      /* Ignore labels that aren't present, or FREE */
      if (! label_present[j] ||
	  strcmp(dataset[0].user_labels[j][0],"FREE") == 0)
	continue;
      /* Get pointer to current column */
      col = MtzColLookup(hklin,dataset[i].user_labels[j][1]);
      if (! col ) {
	/* Lookup of column failed */
	printf(" failed to get pointer to column \"%s\"\n",
	       dataset[i].user_labels[j][1]);
	ccperror(1,"Failed to lookup MTZ column");
      }
      /* Get pointers to MTZ crystal and dataset */
      set = MtzColSet(hklin,col);
      if (! set ) {
	/* Lookup of dataset failed */
	printf(" failed to get pointer to dataset for column \"%s\"\n",
	       dataset[i].user_labels[j][1]);
	ccperror(1,"Failed to lookup MTZ dataset");
      }
	if (! dataset[i].set ) {
	dataset[i].set = set;
      } else if (dataset[i].set != set) {
	printf(" column \"%s\" is from a different dataset\n",
	       dataset[i].user_labels[j][1]);
	ccperror(1,"MTZ dataset information is inconsistent");
      }
      xtal = MtzSetXtal(hklin,dataset[i].set);
      if (! dataset[i].xtal ) {
	dataset[i].xtal = xtal;
      } else if (dataset[i].xtal != xtal) {
	printf("column \"%s\" is from a different crystal to others\n",
	       dataset[i].user_labels[j][1]);
	ccperror(1,"MTZ crystal information is inconsistent");
      }
    }
    /* Assign the crystal and wavelength ids for this
       dataset */
    /* printf(" (%s)",MtzXtalPath(dataset[i].xtal)); */
    printf(" (%s) ",MtzSetPath(hklin,dataset[i].set));
    if (i == 0) {
      /* First dataset */
      printf("first dataset: ");
      dataset[i].crystal_id = 1;
      dataset[i].wavelength_id = 1;
    } else {
      /* Subsequent datasets */
      if (dataset[i-1].xtal == dataset[i].xtal) {
	printf("new wavelength: ");
	/* Same crystal, new wavelength */
	dataset[i].crystal_id = dataset[i-1].crystal_id;
	dataset[i].wavelength_id = dataset[i-1].wavelength_id + 1;
      } else {
	/* New crystal */
	printf("new crystal: ");
	dataset[i].crystal_id = dataset[i-1].crystal_id + 1;
	dataset[i].wavelength_id = 1;
      }
    }
    printf("crystal %d wavelength %d\n",
	   dataset[i].crystal_id,dataset[i].wavelength_id);
  }

  /********************************************************
   * Sort out the label assignments
   ********************************************************/

  /* For each column get the label and match this to the
     labels given on the LABIN line

     To do this, access the MTZ data structure directly
     and bypass the APIs in cmtzlib */
  printf("\nLooping over all columns in the MTZ file\n");

  /* Get array of pointers to all columns in the file */
  if (ncol > MAX_N_COLS) {
    printf("File has more columns (%d) than MTZ2CIF can handle\n",ncol);
    ccperror(1,"Too many columns in input file");
  }
  ii = 0;
  for (i = 0; i < MtzNxtal(hklin); i++) {
    xtal = MtzIxtal(hklin,i);
    for (j = 0; j < MtzNsetsInXtal(xtal);  j++) {
      set = MtzIsetInXtal(xtal,j);
      for (k = 0; k < MtzNcolsInSet(set); k++) {
	col_list[ii] = MtzIcolInSet(set,k);
	ii++;
      }
    }
  }
  printf("\nAcquired MTZ columns\n");

  /* Look up columns for H K L */
  col_H = MtzColLookup(hklin,"H");
  col_K = MtzColLookup(hklin,"K");
  col_L = MtzColLookup(hklin,"L");
  if (! col_H )
    ccperror(1, "Failed to find column for index H");
  else
  if (! col_K )
    ccperror(1, "Failed to find column for index K");
  if (! col_L )
    ccperror(1, "Failed to find column for index L");
  printf("\nLocated columns for indices H K L\n");

  /* Look up FREE column */
  if ( label_present[j_free] ) {
    col_free = MtzColLookup(hklin,dataset[0].user_labels[j_free][1]);
    if (! col_free )
      ccperror(1, "Failed to find column for FREE flag");
    printf("\nFree reflections flagged by value of %d in column \"%s\"\n",
	   freeval,MtzColLabel(col_free));
  }

  /*******************************************************
   * Loop over all datasets and assign columns
   *******************************************************/

  printf("\nChecking and assigning columns:\n");

  for (i = 0; i < ndatasets; i++) {

    printf("\tDataset #%d\n",(i+1));

    /* Initialise assignments to all be NULL */
    for (j = 0; j < N_PROG_LABELS; j++) {
      dataset[i].assigned[j] = NULL;
    }

    /* Check the column types and match the file column pointers to
       the program labels identified from the labin line
    */
    for (j = 0; j < ncol; j++) {
      label = MtzColLabel(col_list[j]);
      for (k = 0; k < N_PROG_LABELS; k++) {
	if (strcmp(label,dataset[i].user_labels[k][1]) == 0 ) { 
	  if (strcmp(mtz_labels[k],"FREE") != 0) {
	    /* Found a match to a non-FREE label
	       Assign the column pointer to the appropriate column */
	    dataset[i].assigned[k] = col_list[j];
	    /* Check the type */
	    if (strcmp(mtz_types[k],MtzColType(dataset[i].assigned[k])) != 0)
	      printf("\t* Type mismatch for %s (type is %s, should be %s)\n",
		     MtzColLabel(dataset[i].assigned[k]),
		     MtzColType(dataset[i].assigned[k]),
		     mtz_types[k]);
	  }
	  /* Break out of the loop now that this column
	     has been identified and assigned */
	  break;
	}
      }
    }
  }

  /* Review the labels that will be written out */
  printf("\nReview the labels to be written to the CIF file:\n");
  printf("\n                                   ");
  for (i = 0; i < ndatasets; i++)
    printf("    Dataset %d",(i+1));
  printf("\n");
  for (i = 0; i < N_PROG_LABELS; i++) {
    if (dataset[0].assigned[i]) {
      sprintf(line0,"%35s",cif_labels[i]);
      for (j = 0; j < ndatasets; j++) {
	d = &dataset[j];
	sprintf(line," %12s",MtzColLabel(d->assigned[i]));
	strcat(line0,line);
      }
      printf("%s\n",line0);
    }
  }
  printf("\n");

  /**********************************************
   * Get the names of the output files
   **********************************************/

  /* Fetch the name of the temporary output file
     We'll write all the reflections to this file and gather
     the statistics, then transfer the data to the real output
     file at the end (along with the CIF header) */
  if (getenv("MTZ2VSCR") != NULL) {
    tmpout = strdup(getenv("MTZ2VSCR"));
  } else {
    ccperror(1,"Unable to get name for temporary file");
  }
  printf("Temporary output file (MTZ2VSCR): %s\n",tmpout);

  /* Fetch the name of the output file */
  if (getenv("HKLOUT") != NULL) {
    hklout = strdup(getenv("HKLOUT"));
  } else {
    hklout = strdup("HKLOUT");
  }
  printf("Output file (HKLOUT): %s\n",hklout);

  /********************************************
   * Output reflection data in CIF format
   ********************************************/

  /* Open a temporary output file - we'll write the reflections
     to this */
  /* Is there a CCP4 library function to do this?
     Just use fopen for now */
  fp = fopen(tmpout,"w");
  if (!fp)
    ccperror(1,"Failed to open temporary output file for writing");

  /* Write the header for the REFLN loop to the output file */
  write_cif_category_comment(fp,"REFLN");
  fprintf(fp,"loop_\n_refln.wavelength_id\n_refln.crystal_id\n_refln.scale_group_code\n_refln.index_h\n_refln.index_k\n_refln.index_l\n_refln.status\n");
  for (i = 0; i < N_PROG_LABELS; i++)
    if (dataset[0].assigned[i])
      fprintf(fp,"%s\n",cif_labels[i]);

  /* Loop over all datasets to be output */
  for (k = 0; k < ndatasets; k++) {
    printf("\nWriting CIF reflections for dataset #%d\n",(k+1));
    printf("\tCrystal % 2d wavelength % 2d\n",
	   dataset[k].crystal_id,dataset[k].wavelength_id);

    /* Reset counter for free reflections */
    nfree = 0;

    /* Acquire the cell parameters for this crystal
       These are needed to calculate the resolution for the
       reflection */
    if (ccp4_lrcell(dataset[k].xtal,cell))
      printf("\tCell parameters: %6.2f %6.2f %6.2f %6.2f %6.2f %6.2f\n",
	     cell[0],cell[1],cell[2],cell[3],cell[4],cell[5]);
    else
      ccperror(1,"Unable to fetch cell parameters for crystal");

    /* Loop over all reflections in the file */
    for (i = 0; i < MtzNref(hklin); i++) {

      /* Get the h k l index for this reflection */
      ih = MtzColDataInt(col_H,i);
      ik = MtzColDataInt(col_K,i);
      il = MtzColDataInt(col_L,i);

      /* Load into an array */
      hkl[0] = ih;
      hkl[1] = ik;
      hkl[2] = il;

      /* Initialise rstat to be "observed"
	 This is used to flag the reflections based on whether
	 they are systematic absences, outside resolution range
	 etc */
      rstat = 'o';

      /* Check the resolution limits for this reflection
	 Flag reflections that are fall outside the specified range
	 
	 Note that "low" resolutions have high values, and vice
	 versa for "high" resolutions - so the tests below seem
	 counter-intuitive */
      MtzHklcoeffs(cell,coefhkl);
      reso_hkl = 1.0/sqrt(MtzInd2reso(hkl,coefhkl));
      if (ireso && reso_hkl > reso_min) {
	rstat = 'l';
	printf("Reflection %d %d %d: resolution is too low (%f)\n",
	       ih,ik,il,reso_hkl);
      } else if (reso_hkl < reso_max) {
	rstat = 'h';
	printf("Reflection %d %d %d: resolution is too high (%f)\n",
	       ih,ik,il,reso_hkl);
      }

      /* Check if this reflection is a systematic absence
	 and flag if it is */
      isysab = ccp4spg_is_sysabs(mtz_spgrp,ih,ik,il);
      if (isysab) {
	printf("%d %d %d is flagged as a systematic absence\n",ih,ik,il);
	rstat = '-';
      }

      /* Get the data for this reflection
	 Also check which items are present, and check that there
	 is at least one item present on the whole line */
      ipresent = 0;
      for (j = 0; j < N_PROG_LABELS; j++) {
	if (dataset[k].assigned[j]) {
	  ref_data[j] = MtzColDataFloat(dataset[k].assigned[j],i);
	  present[j] = (!ccp4_ismnf(hklin,ref_data[j]));
	  if (present[j]) ipresent = 1;
	}
      }
      
      /* Check that there is data to output
	 If not then flag the reflection as missing */
      if (!ipresent)
	rstat = 'x';

      /* Deal with sigma cutoff
	 In CIF we don't exclude the reflections but just flag them
	 as being "low" */
      if (sigp > 0.0001 && rstat == 'o') {

	/* Cut-off applied using FP */
	if (dataset[k].assigned[j_f] && dataset[k].assigned[j_sigf])
	  if (present[j_f] && present[j_sigf])
	    if (abs(ref_data[j_f]) <= sigp*ref_data[j_sigf])
	      rstat = '<';

	/* Cut-off applied using F(+) */
	if (dataset[k].assigned[j_fplus] && dataset[k].assigned[j_sigfplus])
	  if (present[j_fplus] && present[j_sigfplus])
	    if (abs(ref_data[j_fplus]) <= sigp*ref_data[j_sigfplus])
	      rstat = '<';

	/* Cut-off applied using F(-) */
	if (dataset[k].assigned[j_fminus] && dataset[k].assigned[j_sigfminus])
	  if (present[j_fminus] && present[j_sigfminus])
	    if (abs(ref_data[j_fminus]) <= sigp*ref_data[j_sigfminus])
	      rstat = '<';
      }

      /* Gather statistics on the reflections */
      d = &dataset[k];
      d->n_ref_out++;
      if (rstat == 'o')
	d->n_ref_obs++;
      for (j = 0; j < 3; j++) {
	if (hkl[j] > d->ihmax[j])
	  d->ihmax[j] = hkl[j];
	else if (hkl[j] < d->ihmin[j])
	  d->ihmin[j] = hkl[j];
      }
      /* Note that "high" is a low value, and vice versa */
      if (reso_hkl > d->rmin)
	d->rmin = reso_hkl;
      else if (reso_hkl < d->rmax)
	d->rmax = reso_hkl;

      /* Flag the free reflections
	 Note that FREE reflections are considered to be "observed"
	 when counting n_ref_obs, though the definition of
	 _refln.status is ambiguious */
      if (col_free) {
	if (!ccp4_ismnf(hklin,MtzColDataFloat(col_free,i)))
	  if (abs(MtzColDataFloat(col_free,i) - freeval) < 0.0001)
	    if (rstat == 'o') {
	      rstat='f';
	      nfree++;
	    }
      }

      /* Initialise the line to write for this reflection */
      sprintf(line0," %d %d 1   % 4d % 4d % 4d %c",
	      dataset[k].wavelength_id,dataset[k].crystal_id,
	      ih,ik,il,rstat);

      /* Write the data to the line */
      for (j = 0; j < N_PROG_LABELS; j++) {
	if (dataset[k].assigned[j]) {
	  if (present[j])
	    sprintf(line," % 8.1f",ref_data[j]);
	  else
	    sprintf(line,"        ?");
	  /* Append the value to the line */
	  strcat(line0,line);
	}
      }

      /* Write the line to the file */
      fprintf(fp,"%s\n",line0);
    }

    /* End of the current dataset - check the number of free
       reflections versus the total number written out */
    if ( col_free ) {
      free_percent = ((float) nfree)/((float) dataset[k].n_ref_out);
      printf("\tFraction of free reflections: %.2f\n",free_percent);
      if ( free_percent > 0.5 ) {
	/* Probably got the wrong FREE value */
	ccperror(2,"Free reflections are more than half those output!\nCheck the value being used to flag free reflections!");
      }
    }
    /* Next dataset */
  }

  printf("\nWrote all reflections to temporary file\n");

  /* Close the temporary output file */
  if (fp) fclose(fp);

  /*************************************
   * Write the full output file
   *************************************/

  /* Open the actual output file for writing */
  /* Is there a CCP4 library function to do this?
     Just use fopen for now */
  fp = fopen(hklout,"w");
  if (!fp)
    ccperror(1,"Failed to open output file for writing");

  /* Write the CIF header */
  printf("\nWriting CIF header ...");
  write_cif_datablock_header(fp,hklin,dbhead,ndatasets,dataset,
			      mtz_spgrp,sigp);
  printf("done\n\n");

  /* Open temporary file for reading */
  fptmp = fopen(tmpout,"r");
  if (!fptmp)
    ccperror(1,"Failed to open temporary output file for reading");

  /* Transfer the lines in the temporary file to the real
     output file */
  printf("Transferring reflection data to final output file ...");
  while (fgets(line,1000,fptmp)) {
    fprintf(fp,"%s",line);
  }
  printf("done\n\n");

  /* Close all the files */
  if (fptmp) fclose(fptmp);
  if (fp) fclose(fp);
  if (hklin) MtzFree(hklin);

  /* Finish */
  ccperror(0, "Normal termination");
}

/****************************************************************
 * Supplementary functions
 ****************************************************************/


/***********************************************
 * Write out a comment box for a CIF category
 * Based on subroutine wccatc in mtz2various.f
 ***********************************************/
int write_cif_category_comment(FILE *fp, char *category) {
  /* Declarations */
  int i,ichar,ispace,width;
  char catstr[80],hash[100],spaces[100];

  /* Strip leading spaces from category name
     Note that strlen doesn't count the trailing '\0' character */
  ispace = 1;
  ichar = 0;
  for ( i=0 ; i < (strlen(category)+1) ; i++ ) {
    if (ispace)
      if (category[i] != ' ')
	ispace = 0;
    if (!ispace) {
      catstr[ichar] = category[i];
      ichar++;
    }
  }
  
  /* Compute the size of the bounding box */
  width = 6 + strlen(catstr);

  /* Construct the box lines */
  for ( i=0 ; i < width ; i++) {
    hash[i] = '#';
    if ( i == 0 || i == (width-1) )
      spaces[i] = '#';
    else
      spaces[i] = ' ';
  }
  hash[width] = '\0';
  spaces[width] = '\0';

  /* Write to the file */
  fprintf(fp,"\n\n%s\n%s\n#  %s  #\n%s\n%s\n\n\n",
	  hash,spaces,catstr,spaces,hash);
  return 1;
}

/**********************************************************
 * Write the CIF datablock header
 * This version deals with multiple output datasets
 **********************************************************/
int write_cif_datablock_header(FILE *fp, MTZ *hklin, char *dbhead,
			       int nsets, MTZ2CIFDATASET *dataset,
			       CCP4SPG *ccp4_spg, float sigp) {
  int   i,j,nsympx,nspgrx,nsym;
  float rsym[4][4],cell[6];
  char  cifdat[12];
  char  ltypex[100],spgrnx[100],pgnamx[100],temp_symch[80];
  char  *fname=NULL;
  char  *cif_cell[6] =
    { "_cell.length_a   ","_cell.length_b   ","_cell.length_c   ",
      "_cell.angle_alpha","_cell.angle_beta ","_cell.angle_gamma" };
  char *index[3] = { "h","k","l" };
  MTZ2CIFDATASET *d;

  /************************
   * Initialise
   ************************/

  /* Today's date (in CIF format) */
  ccp4_utils_cifdate(cifdat);

  /* Source file name */
  if (getenv("HKLIN") != NULL) fname = strdup(getenv("HKLIN"));

  /* Symmetry information
     Note that ccp4_lrsymi expects that the pointers for the
     spacegroup names etc are already allocated memory to
     store the resulting strings
  */
  ccp4_lrsymi(hklin,&nsympx,ltypex,&nspgrx,spgrnx,pgnamx);

  /* Data block header */
  fprintf(fp,"%s\n",dbhead);

  /* ENTRY block */
  write_cif_category_comment(fp,"ENTRY");
  fprintf(fp,"_entry.id   %s\n",&dbhead[5]);

  /* AUDIT block */
  write_cif_category_comment(fp,"AUDIT");
  fprintf(fp,"_audit.revision_id        1\n");
  fprintf(fp,"_audit.creation_date      '%s'\n",cifdat);
  fprintf(fp,"_audit.creation_method\n");
  fprintf(fp,"; Created by mtz2cif (CCP4) from\n");
  fprintf(fp,"%s\n;\n",fname);
  fprintf(fp,"_audit.update_record\n;\n;\n");

  /* CELL block */
  write_cif_category_comment(fp,"CELL");
  if ( nsets == 1 ) {
    /* Single dataset form */
    ccp4_lrcell(dataset[0].xtal,cell);
    fprintf(fp,"_cell.entry_id     %s\n",&dbhead[5]);
    for ( i=0 ; i < 6 ; i++ )
      fprintf(fp,"%s     % 10.4f\n",cif_cell[i],cell[i]);
  } else {
    /* Multiple datasets form */
    /* Note that _cell.CCP4_crystal_id and _cell.CCP4_wavelength_id
       are non-standard CIF at the time of coding - August 2005 */
    fprintf(fp,"loop_\n_cell.entry_id\n");
    fprintf(fp,"_cell.CCP4_wavelength_id\n_cell.CCP4_crystal_id\n");
    for ( i=0 ; i < 6 ; i++ )
      fprintf(fp,"%s\n",cif_cell[i]);
    /* Write data for each dataset one per row */
    for ( i=0 ; i < nsets ; i++ ) {
      ccp4_lrcell(dataset[i].xtal,cell);
      fprintf(fp,"%s %2d %2d",&dbhead[5],
	      dataset[i].wavelength_id,dataset[i].crystal_id);
      for ( j=0 ; j < 6 ; j++ )
	fprintf(fp," % 8.4f",cell[j]);
      fprintf(fp,"\n");
    }
  }

  /* SYMMETRY block */
  write_cif_category_comment(fp,"SYMMETRY");
  fprintf(fp,"_symmetry.entry_id     %s\n",&dbhead[5]);
  fprintf(fp,"_symmetry.Int_Tables_number        ");
  if (nspgrx == 0)
    fprintf(fp,"?\n");
  else
    fprintf(fp,"%d\n",nspgrx);
  fprintf(fp,"_symmetry.space_group_name_H-M    '");
  if (strlen(GetxHMSymbol(ccp4_spg)) == 0)
    fprintf(fp,"?");
  else
    fprintf(fp,"%s",GetxHMSymbol(ccp4_spg));
  fprintf(fp,"'\n");

  /* SYMMETRY_EQUIV block */
  write_cif_category_comment(fp,"SYMMETRY_EQUIV");
  fprintf(fp,"loop_\n _symmetry_equiv.id\n _symmetry_equiv.pos_as_xyz\n");

  /* Get the symops in string notation
     For each symop, obtain the matrix representation
     directly from the CCP4SPG structure
     Then feed this into the conversion function */
  nsym = GetNSymops(ccp4_spg);
  for ( i=0 ; i < nsym ; i++ ) {
    /* Get rsym matrix */
    GetRsymMatrix(ccp4_spg,i,rsym);
    /* Get C string representation */
    GetSymopString(rsym,temp_symch,80);
    fprintf(fp," % 3d '%s'\n",(i+1),temp_symch);
  }

  /* REFLNS block */
  write_cif_category_comment(fp,"REFLNS");
  if (nsets == 1) {
    /* Single dataset form */
    d = &dataset[0];
    fprintf(fp,"_reflns.entry_id     %s\n",&dbhead[5]);
    fprintf(fp,"_reflns.d_resolution_high     % 10.3f\n",d->rmax);
    fprintf(fp,"_reflns.d_resolution_low      % 10.3f\n",d->rmin);
    for ( i=0 ; i<3 ; i++ ) {
      fprintf(fp,"_reflns.limit_%s_max     % 8d\n",index[i],d->ihmax[i]);
      fprintf(fp,"_reflns.limit_%s_min     % 8d\n",index[i],d->ihmin[i]);
    }
    fprintf(fp,"_reflns.number_all     % 8d\n",d->n_ref_out);
    fprintf(fp,"_reflns.number_obs     % 8d\n",d->n_ref_obs);
    if (sigp > 0.0001)
      fprintf(fp,"_reflns.observed_criterion     'F > %5.2f sigma(F)'\n",
	      sigp);
  } else {
    /* Multiple wavelength form */
    /* Note that _reflns.CCP4_wavelength_id and _reflns.CCP4_crystal_id
       are non-standard CIF at the time of coding - August 2005 */
    fprintf(fp,"loop_\n");
    fprintf(fp,"_reflns.entry_id\n");
    fprintf(fp,"_reflns.CCP4_wavelength_id\n");
    fprintf(fp,"_reflns.CCP4_crystal_id\n");
    fprintf(fp,"_reflns.d_resolution_high\n");
    fprintf(fp,"_reflns.d_resolution_low\n");
    for ( i=0 ; i<3 ; i++ ) {
      fprintf(fp,"_reflns.limit_%s_max\n",index[i]);
      fprintf(fp,"_reflns.limit_%s_min\n",index[i]);
    }
    fprintf(fp,"_reflns.number_all\n");
    fprintf(fp,"_reflns.number_obs\n");
    if (sigp > 0.0001)
      fprintf(fp,"_reflns.observed_criterion     'F > %5.2f sigma(F)'\n",
	      sigp);
    /* Write out statistics for each dataset */
    for ( i=0 ; i<nsets ; i++ ) {
      d = &dataset[i];
      fprintf(fp,"%s %2d %2d",&dbhead[5],
	      dataset[i].wavelength_id,dataset[i].crystal_id);
      fprintf(fp," % 8.3f % 8.3f",d->rmax,d->rmin);
      for ( j=0 ; j<3 ; j++ )
	fprintf(fp," %5d %5d",d->ihmax[j],d->ihmin[j]);
      fprintf(fp," % 6d % 6d",d->n_ref_out,d->n_ref_obs);
      if (sigp > 0.0001)
	fprintf(fp," 'F > %5.2f sigma(F)'\n",sigp);
      else
	fprintf(fp,"\n");
    }
  }

  /* DIFFRN_RADIATION_WAVELENGTH block */
  write_cif_category_comment(fp,"DIFFRN_RADIATION_WAVELENGTH");
  if ( nsets == 1 ) {
    /* Single dataset version */
    fprintf(fp,"loop_\n_diffrn_radiation_wavelength.id\n_diffrn_radiation_wavelength.wavelength\n");
    fprintf(fp,"  1   %10.5f\n",MtzSetWavelength(dataset[0].set));
  } else {
    /* Multiple wavelength version */
    /* Note that _diffrn_radiation_wavelength.CCP4_crystal_id is
       non-standard CIF at the time of coding - August 2005 */
    fprintf(fp,"loop_\n");
    fprintf(fp,"_diffrn_radiation_wavelength.id\n");
    fprintf(fp,"_diffrn_radiation_wavelength.CCP4_crystal_id\n");
    fprintf(fp,"_diffrn_radiation_wavelength.wavelength\n");
    for ( i=0 ; i<nsets; i++ )
      fprintf(fp," %2d %2d   %10.5f\n",
	      dataset[i].wavelength_id,
	      dataset[i].crystal_id,
	      MtzSetWavelength(dataset[i].set));
  }

  /* EXPTL_CRYSTAL block */
  write_cif_category_comment(fp,"EXPTL_CRYSTAL");
  if ( nsets == 1 ) {
    /* Single dataset version */
    fprintf(fp,"_exptl_crystal.id     1\n");
  } else {
    /* Multiple wavelength version */
    fprintf(fp,"loop_\n");
    fprintf(fp,"_exptl_crystal.id\n");
    j=0;
    for ( i=0 ; i<nsets; i++ ) {
      if (dataset[i].crystal_id != j) {
	j = dataset[i].crystal_id;
	fprintf(fp," %2d\n",j);
      }
    }
  }

  /* REFLNS_SCALE block */
  write_cif_category_comment(fp,"REFLNS_SCALE");
  fprintf(fp,"_reflns_scale.group_code     1\n");

  return 1;
}

/***********************************************************
   Return the current date as a string in CIF format
   i.e. YYYY-MM-DD (year-month-day)
   Essentially this is a modified version of ccp4_utils_date
   from library_utils.c
************************************************************/
char *ccp4_utils_cifdate(char *date)
{
  int iarray[3];

  ccp4_utils_idate(iarray);
  sprintf(date,"%4d-%02d-%02d",iarray[2],iarray[1],iarray[0]);
  date[10] = '\0';

  return (date);
}
