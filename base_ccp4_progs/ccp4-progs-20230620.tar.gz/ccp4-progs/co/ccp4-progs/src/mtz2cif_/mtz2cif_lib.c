/*
     MTZ2CIF_LIB
     Copyright (C) 2005 Peter Briggs

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK
*/

/* mtz2cif_lib.c

   Pseudo-library for MTZ2CIF program

*/
#include "mtz2cif_lib.h"

#define MTZ2CIF_LIB_VERSION "0.1"

/*********************************************
 * MTZ-related functions
 *********************************************/

/* Return the wavelenth associated with a dataset */
float MtzSetWavelength(MTZSET *set) {
  if (set)
    return set->wavelength;
  else
    return 0.0;
}

/* Return the label of a column */
char *MtzColLabel(MTZCOL *col) {
  if (col)
    return col->label;
  else
    return NULL;
}

/* Return the data stored in a column*/
int MtzColDataInt(MTZCOL *col, int irefl){
  if (!col) {
    /* Column pointer is NULL */
    return 0;
  }
  return (int) col->ref[irefl];
}

/* Return the data stored in a column */
float MtzColDataFloat(MTZCOL *col, int irefl) {
  if (!col) {
    /* Column pointer is NULL */
    return 0.0;
  }
  return (float) col->ref[irefl];
}

/*********************************************
 * Symop-related functions
 *********************************************/

/* Return number of symops */
int GetNSymops(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->nsymop;
  else
    return 0;
}

/* Get extended Hermann-Macguin symbol for spacegroup */
char *GetxHMSymbol(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->symbol_xHM;
  else
    return NULL;
}

/* Return symmetry matrix (4x4) */
int GetRsymMatrix(CCP4SPG *ccp4_spg, int i, float rsym[4][4]) {
  int j,k;
  for ( j=0 ; j < 3 ; j++ ) {
    for ( k=0 ; k < 3; k++ ) {
      rsym[j][k] = ccp4_spg->symop[i].rot[j][k];
    }
    rsym[3][j] = ccp4_spg->symop[i].trn[j];
    rsym[j][3] = ccp4_spg->symop[i].trn[j];
  }
  rsym[3][3] = 1.0;
  return 1;
}

/* Return symop string from symmetry matrix */    
int GetSymopString(float rsym[4][4], char *symch, int n) {
  int i,j,k,l;
  char *temp_symch;

  /* Check inputs */
  if (!symch || n<1) return 0;

  /* Allocate memory for temporary string */
  temp_symch = (char *) ccp4_utils_malloc(n*sizeof(char));

  /* Call the conversion function (which is tailored to Fortran) */
  mat4_to_symop(temp_symch,temp_symch+(n-1),rsym);
  /* Need to post-process the output because the
     string is not null-terminated - it is padded with
     spaces */
  j = 0;
  k = 0;
  l = 0;
  while (j < n) {
    if (temp_symch[j] == ',') {
      /* Count the number of commas */
      k++;
    } else if (k == 2) {
      /* After 2 commas we are on the last part of the
	 symop */
      if ( !l && temp_symch[j] != ' ' ) {
	/* Flag that we have passed the leading spaces
	   in the third component of the symop */
	l=1;
      } else if ( l && temp_symch[j] == ' ' ) {
	/* We've encountered spaces after the last
	   part of the symop */
	temp_symch[j] = '\0';
	break;
      }
    }
    j++;
  }

  /* Copy the temporary string to the final result */
  strncpy(symch,temp_symch,n);

  /* Free memory and return */
  if (!temp_symch) {
    free(temp_symch);
    temp_symch = NULL;
  }
  return 1;
}

/*********************************************
 * General CCP4 library-style functions
 *********************************************/

/* Echo the logical name and associated file name */
int WriteLogicalName(FILE *fp, char *logicalname)
{
  char *filename=NULL;
  if (getenv(logicalname) != NULL) {
    filename = strdup(getenv(logicalname));
    printf(" Logical name: %s   Filename: %s\n",logicalname,filename);
    return 1;
  } else {
    printf(" Logical name: %s   No associated filename\n",logicalname);
    return 0;
  }
}
