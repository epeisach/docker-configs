/*
     PLTDEV
     Copyright (C) 1992 Peter Daly

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
*/

/*
    This program borrows heavily from D. J. Parry-Smith's C programs LPLOT84 
    and CLI_CHECK, with several extensions. This program maps a PLOT84 meta-
    on to one of the devices below: (default options in capitals)

    Device       Thick    Dashed      Grey      Colour    

    POSTSCRIPT    yes       yes        yes        YES
    hp7550         no       yes         no        YES
    hp7470         no       yes         no        YES
    tektronix      no       YES         no         no

    Warning: The routine date () at the end of this code may need adjusting 
             when porting to different machines.

    Author of LPLOT84:			  Modifications for Unix by:

    D J Parry-Smith			  P. J. Daly
    Astbury Department of Biophysics	  SERC,
    University of Leeds			  Daresbury Laboratory,
    Leeds				  Warrington,
    LS16  5NP				  WA4 4AD,
    United Kingdom			  U.K.

*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#ifndef VMS
#  if defined (vms) || defined (__vms) || defined (__VMS)
#    define VMS 1
#  endif
#endif

/* OPTCHAR is the character that introduces switches e.g. -log */

#define OPTCHAR '-'

/****************************************************************************
 * Definitions for different machines to override defaults can go here      *
 ****************************************************************************/

#ifdef VMS

#define DIRDELIM ']'
#include processes
static char *print_command = "PRINT /AT=";
static char *delete_command = "DELETE /SINCE ";

#else

#define DIRDELIM '/'
#include <sys/types.h>
static char *print_command = "lpr -P";
static char *delete_command = "/bin/rm ";

#endif

#include <time.h>

/****************************************************************************
 * MACRO definitions                                                        *
 ****************************************************************************/

#define lcase(c) ((c>='A' && c <= 'Z') ? c - 'A' + 'a' : c)
#define ucase(c) ((c>='a' && c <= 'z') ? c - 'a' + 'A' : c)

/* Command Line option values */
static char *opt_type[]={"", "file", "value", "line/dash/grey/col", "id", "string"};

typedef int boolean;

#define NO       			 0
#define YES      			 1

/* for checking return val of fprintf etc. */
#define CHKPOS(_foo) if ((_foo)<0) perror ("pltdev");

/****************************************************************************
 * Colour table definition - you can edit the table MAXCOLOUR definition    *
 ****************************************************************************/

#define MAXCOLOUR                        10     /* Maximum number of colours */
struct colours
{
  char *name;				                     /* Colour name */
  float red;                           /* RGB RED scale numbers (0.0 - 1.0) */
  float green;                       /* RGB GREEN scale numbers (0.0 - 1.0) */
  float blue;                         /* RGB BLUE scale numbers (0.0 - 1.0) */
  float grey_level;			   /* Grey scale number (0.0 - 1.0) */
  char *dash_length;			   /* Array specifying dash lengths */
} colour_table[MAXCOLOUR + 1]= {
    {"default", 0.00, 0.00, 0.00, 1.00, "[]"},
    {"black",   0.00, 0.00, 0.00, 1.00, "[]"},
    {"cyan",    0.00, 1.00, 1.00, 0.30, "[]"},
    {"red",     1.00, 0.00, 0.00, 0.80, "[2 2]"},
    {"green",   0.00, 1.00, 0.00, 0.40, "[1 3]"},
    {"blue",    0.00, 0.00, 1.00, 0.70, "[8 8]"},
    {"magenta", 1.00, 0.00, 1.00, 0.60, "[4 12]"},
    {"yellow",  1.00, 1.00, 0.00, 0.20, "[2 2]"},
    {"purple",  0.63, 0.13, 0.94, 0.90, "[1 3]"},
    {"orange",  1.00, 0.65, 0.00, 0.50, "[8 8]"},
    {"black",   0.00, 0.00, 0.00, 1.00, "[4 12]"}
};

/****************************************************************************
 * Command Line Switch values and types - if you add commands, edit NVALUES *
 ****************************************************************************/

#define NVALUES 		        28      /* Number of cli qualifiers */
struct cli_arguments
{
 char id[4];		                     /* Name of command line switch */
 boolean present;	                 /* true if present on command line */
 char value[256];	       /* value associated with it (if appropriate) */
 boolean opt_type;	                 /* type of argument value expected */
 char *help;		                  /* short line of help information */
} qual[]= {  
  {"log",      NO, "off",        0, "produce log information"},         /*  0 */
  {"del",      NO, "off",        0, "delete file after processing"},  /*  1 */
  {"lan" ,     NO, "undefined",  0, "select landscape format"},       /*  2 */
  {"por",      NO, "undefined",  0, "select portrait format"},        /*  3 */
  {"aut",      NO, "on\0",       0, "select automatic scaling"},      /*  4 */
  {"abs",      NO, "off",        0, "select absolute scaling"},       /*  5 */
  {"hea",      NO, "off",        0, "produce header line/picture"},   /*  6 */
  {"pri",      NO, "off",        0, "print the result"},              /*  7 */
  {"i",        NO, "plot84.plt", 1, "input file name"},               /*  8 */
  {"o",        NO, "plot84.ps",  1, "output file name"},              /*  9 */
  {"xp",       NO, "0.7",	2, "start x position"},               /* 10 */
  {"yp",       NO, "0.7",	2, "start y position"},               /* 11 */
  {"lnw",      NO, "0.8",	2, "line thickness"},                 /* 12 */
  {"lni",      NO, "0.1",	2, "line increment"},                 /* 13 */
  {"pen",      NO, "line", 	3, "set shade by line/dash/grey/col"},/* 14 */
  {"sca",      NO, "1.0",        1, "select scale"},                  /* 15 */
  {"n",        NO, "500",	2, "number of pictures"},             /* 16 */
  {"pnt",      NO, "1.0",  	2, "point thickness"},                /* 17 */
  {"P",        NO, "psp",   	4, "select printer name"},            /* 18 */
  {"sta",      NO, "1",  	2, "start picture number"},           /* 19 */
  {"pwd",      NO, "PLOT%%84",   5, "password in meta-file"},         /* 20 */
  {"hel",      NO, "0",	        2, "print help information"},         /* 21 */
  {"sh",       NO, "-1", 	2, "print colour info. -1 for all"},  /* 22 */
  {"xs",       NO, "6.5", 	2, "overall size in x direction"},    /* 23 */
  {"ys",       NO, "6.5", 	2, "overall size in y direction"},    /* 24 */
  {"sep",      NO, "0.3", 	2, "gap between stereo pair in cm"},  /* 25 */
  {"ste",      NO, "off", 	0, "select stereo picture mode"},     /* 26 */
  {"dev",      NO, "PostScript", 5, "set device ps/hp7550/hp7470/tek"}/* 27 */
};

/* these definitions make editing much easier - the ones with .present after
   them are simple flags so the value field is never used */

#define LOG            qual[0].present
#define DELETE         qual[1].present
#define LANDSCAPE      qual[2]
#define PORTRAIT       qual[3]
#define AUTO           qual[4]
#define ABSOLUTE       qual[5]
#define HEADER         qual[6].present
#define PRINT_FILE     qual[7].present
#define IN_FILE        qual[8]
#define OUT_FILE       qual[9]
#define X_POSITION    qual[10]
#define Y_POSITION    qual[11]
#define LINE_WT       qual[12]
#define LINE_INC      qual[13]
#define COLOUR        qual[14]
#define SCALE         qual[15]
#define N_PICT        qual[16]
#define POINT_WT      qual[17]
#define PRINTER_NAME  qual[18]
#define START_PICTURE qual[19]
#define PASSWORD      qual[20]
#define HELP_LEVEL    qual[21]
#define COLOUR_TABLE  qual[22]
#define X_SIZE        qual[23]
#define Y_SIZE        qual[24]
#define SEPARATION    qual[25]
#define STEREO        qual[26].present

/****************************************************************************
 * Other defines used by program                                            *
 ****************************************************************************/

#define SIZE                    1
#define NUMBER                512     /* SIZE * NUMBER must equal 512 */
#define TRUE                    1
#define FALSE                   0
#define ZERO                  0.0
#define PI            3.141592654
#define POSTSCRIPT              0
#define HP7550                  1
#define HP7470                  2
#define TEK                     3

#define NREC       header.hint[0]
#define DOTMMX     header.real[1]
#define DOTMMY     header.real[2]
#define IXMIN      header.hint[3]
#define IXMAX      header.hint[4]
#define IYMIN      header.hint[5]
#define IYMAX      header.hint[6]
#define LINWT      header.hint[7]
#define ICOLOUR    header.hint[8]
#define MIXCOL     header.hint[9]
#define MDEVIC    header.hint[10]
#define MDIREC    header.hint[11]
#define MOUT      header.hint[12]
#define MPIC      header.hint[13]
#define MSCAFL    header.hint[14]
#define MCNTFL    header.hint[15]
#define DWLIMX    header.real[16]
#define DWLIMY    header.real[17]
#define DVXMIN    header.real[18]
#define DVXMAX    header.real[19]
#define DVYMIN    header.real[20]
#define DVYMAX    header.real[21]
#define NPICS     header.hint[22]
#define PASWRD header.hchar[23*4]
#define TITLEH header.hchar[40*4]

union{
  int hint[128];
  float real[128];
  char hchar[512];
} header;

float xscale;
float yscale;

FILE *plot84, *ps;

float lwt;
float lwtstart;
float lwtinc;
float sep,xoff,yoff,xsize,ysize;
float A4X, Xold = 0;
float A4Y, Yold = 0;
float A4XD = 576.0, A4YD = 830.0;
float CMPTS = 28.35, MMPTS = 2.835;
float theta, costheta, sintheta; /* used to map portrait or landscape */
float Xt = 0.0, Yt = 0.0;   /* used to translate for portrait or landscape */

int num_pictures;
int start_picture;
int plots = 0;			          /* used to count pictures in file */
int help_level;
int colour_number;
int device;                                /* used to indicate which device */
char *arg0, *temp, *mast_head;            /* arg0 is set to argv[0] in main */

/* pwtstart is the amount added to produce a point in point plot mode */
float pwtstart; 

boolean path_started = FALSE;
boolean landscape = FALSE;

/****************************************************************************
 * Routine Prototypes                                                       *
 ****************************************************************************/

#if defined (PROTOTYPE)

void blanklines (int number);
void cli_check (int count, char *args[]);
void do_header (float scale_factor);
void epilogue (void);
void error (char *s1, char *s2, int level, int errnum);
void finish (void);
void init (void);
void line_weight (short int weight);
void logput (char *messaage);
void logputf (char *message, float arg);
void logputs (char *message, char *args);
void logputd (char *meassge, int args);
void maybeswap (float *a, float *b);
void move_to (float x, float y);
void newpen (short int pen);
void p842ps (int ix, int iy, float *x, float *y);
void prepare (void);
void prologue (void);
void ps_header (float scale_factor, char my_time[26]);
void hp_header (float scale_factor, char my_time[26]);
void tk_header (float scale_factor, char my_time[26]);
void ps_newpen (short int pen);
void hp_newpen (short int pen);
void tk_newpen (short int pen);
void ps_portrait(void), hp_portrait(void), tk_portrait(void);
void ps_landscape(void), hp_landscape(void), tk_landscape(void);
void ps_prepare(void), hp_prepare(void), tk_prepare(void);
void ps_epilogue(void), ps_prologue(void);
void put_line (float x, float y);
void set_landscape (void);
void set_portrait (void);
void show_colour (int value);
void show_help (int level);
void to_device (float scale_factor);

boolean get_header (int *plot);
boolean put_point (float x, float y);

float set_scale (void);

int print_file(char *fname, char *pname);
int delete_file(char *fname);

char *date (void);
char *pltdev_ftoa (float f, int d);
char *pltdev_itoa (int i);

#endif    /* (PROTOTYPE) */  

/****************************************************************************
 * Main program starts here                                                 *
 ****************************************************************************/

main (argc,argv)
int argc;
char *argv[];
{
  float scale_factor;
  int ret_val;
#if !defined (PROTOTYPE)
  int get_header ();
  void cli_check (),init (), logput(), logputd (), logputs (),
    to_device (), show_colour (), show_help (), error (), prologue (),
    epilogue ();
  float set_scale();
  int print_file();
  int delete_file();
  char *pltdev_itoa();
#endif

  arg0 = strrchr (argv[0], DIRDELIM);	/* strips off leading directories   */
  if (arg0 == NULL)			/* of argv[0] leaving just the name */
     arg0 = argv[0];
  else
     arg0++;

  cli_check (argc, argv);	            /* check command line arguments */

  init ();			            /* parse command line arguments */

  mast_head = malloc (40 + strlen(qual[27].value));   /* set up header line */
  sprintf (mast_head,"Plot84 to %s (V2.4 Unix/VMS May 1990)\n",qual[27].value);

  if (HELP_LEVEL.present) show_help (help_level);		       /* give help */

  if (COLOUR_TABLE.present) show_colour (colour_number);	    /* give colours */

  logput (mast_head);

  if (STEREO) logput ("Stereo picture mode selected");

  lwt = lwtstart; /* Make initial line_weight same as user's starting point */  
  
  A4X = A4XD - xoff;
  if (HEADER)         /* Reduce the page size if header is wanted */
      A4Y = A4YD - yoff - 15;
  else
      A4Y = A4YD - yoff - 10;

#if defined WIN32
  plot84 = fopen(IN_FILE.value,"rb"); 
#else
  plot84 = fopen(IN_FILE.value,"r");
#endif
  if (plot84 == NULL)              
    error ("error opening input file", IN_FILE.value,1,-1);

  num_pictures = start_picture + num_pictures - 1;
  (void) get_header (&plots);	  /* Read in the Plot84 header information. */

  logputd ("Total pictures in file :",NPICS);

  if (start_picture > NPICS)
    error (pltdev_itoa (start_picture), pltdev_itoa (NPICS),2,5); /* can't find start pic */

  if (STEREO && num_pictures > NPICS)
    num_pictures = start_picture + 1;  /* can't find 2nd pic use start + 1 */

  if (num_pictures > NPICS) 
    {
      num_pictures = NPICS;
      logputd ("Not enough pictures in file - only printing up to",NPICS);
    }

  while (plots < start_picture)		/* skip to first picture to process */
    {
      temp = malloc ((unsigned int) (4 * NREC));
      if ((ret_val = (int) fread (temp,4,NREC,plot84)) != NREC) 
        error (IN_FILE.value, pltdev_itoa (ret_val), 10 ,6);
      (void) free (temp);
      (void) get_header (&plots);
    }

  if ((ps = fopen (OUT_FILE.value,"w")) == NULL)
    error ("problem opening the output file",OUT_FILE.value,9,-1);

  scale_factor = set_scale ();	/* needed by prologue */
  prologue ();

  do
    {
      if (strncmp (PASSWORD.value,&PASWRD,strlen (&PASWRD)) != 0)
        error (PASSWORD.value,&PASWRD,3,3);
      scale_factor = set_scale ();
      to_device (scale_factor);
      if (STEREO)
        {
          (void) get_header (&plots);
          while (plots < num_pictures) /* skip to second picture to process */
           {
             temp = malloc ((unsigned int) (4 * NREC));
             if ((ret_val = (int) fread (temp,4,NREC,plot84)) != NREC)
               error (IN_FILE.value, pltdev_itoa (ret_val), 10 ,6);
             (void) free (temp);
             (void) get_header (&plots);
            }
          if (strncmp (PASSWORD.value,&PASWRD,strlen (&PASWRD)) != 0)
            error (PASSWORD.value,&PASWRD,3,3);
          STEREO = FALSE;      /* turn off stereo since its last pic */
          HEADER = FALSE;     /* turn off header line for second pic */
          xoff = xsize + sep;/* change x offset value for second pic */
          yoff = 0;        /* turn off y offset value for second pic */
          to_device (scale_factor);
          plots = num_pictures + 1;              /* to stop plotting */
        }
      else
        (void) get_header (&plots);
    } while (plots <= num_pictures);

  epilogue ();
  logput ("Output complete.");

  if (PRINT_FILE && print_file (OUT_FILE.value,PRINTER_NAME.value) != 0)
    logputs ("unable to print output file",OUT_FILE.value); 

  if (DELETE && delete_file (OUT_FILE.value) != 0) 
    logputs ("unable to delete output file",OUT_FILE.value); 

  exit (0);
} /* End of MAIN */


/****************************************************************************
 * Error Message Handler                                                    *
 ****************************************************************************/

#if defined (PROTOTYPE)
void error (char *s1, char *s2, int level, int errnum)
#else
void error (s1, s2, level, errnum)
char *s1, *s2;			   /* allows programmer two output messages */
int level;			         /* error number to hand back to OS */
int errnum;			   /* error message number for output below */
#endif
{
  if (errnum != 0) CHKPOS(fprintf (stderr,"%s: ",arg0));
  switch (errnum)
    {
      case 0: break;
      case 1: CHKPOS(fprintf (stderr,"cannot allow %s and %s together\n",s1,s2));
              break;
      case 2: CHKPOS(fprintf (stderr,"value for %s is invalid (%s) ",s1,s2));
              CHKPOS(fprintf (stderr,"- number expected\n"));
              break;
      case 3: CHKPOS(fprintf (stderr,"password mismatch - user: %s ",s1));
              CHKPOS(fprintf (stderr,"file: %s Not a Plot84 file?\n",s2));
              break;
      case 4: CHKPOS(fprintf (stderr,"show must be between 0 and %s ",s1));
              CHKPOS(fprintf (stderr,"- show=%s\n",s2));
              break;
      case 5: CHKPOS(fprintf (stderr,"can't find picture %s ",s1));
              CHKPOS(fprintf (stderr,"only %s pictures in file\n",s2));
              break;
      case 6: CHKPOS(fprintf (stderr,"problem reading the input file %s",s1));
              CHKPOS(fprintf (stderr,"- fread returned %s\n",s2));
              break;
     default: CHKPOS(fprintf (stderr,"%s %s\n",s1,s2));
              break;
    }
  exit (level);
} /* End of error */

/****************************************************************************
 * Routines Called by Main                                                  *
 ****************************************************************************/

#if defined (PROTOTYPE)
void cli_check (int count, char *args[])
#else
void cli_check (count, args)
int count;
char *args[];
#endif
{
 char *qualifier, *value;
 int i, j;
#if !defined (PROTOTYPE)
 void error (), logputs ();
#endif

 for (i = 1; i < count && *args[i] == OPTCHAR; i++)
  {
    ++args[i];					 /* skip over minus sign    */
    qualifier = args[i];			 /* remember start location */
    for (j = 0; j < NVALUES; j++)		/* qualifiers with values   */
      if (strncmp (qualifier, qual[j].id, strlen (qual[j].id)) == 0)
       {
         qual[j].present = YES;
         if (qual[j].opt_type == 0)
           {
             (void) strcpy (qual[j].value, "on\0");
           }
         else
           {
             value = strchr (qualifier, '=');	/* look for equals sign      */
             if (value != NULL)
               {
                 ++value;			  /* grab value after equals */
                 if (*value == '\0') value = NULL;
               }
             else
               value = ((++i) == count ? NULL : args[i]);    /* use next arg */
             if (value != NULL) 
               {
                 (void) strncpy (qual[j].value, value, 256);
		 (qual[j].value)[255] = '\0';
               }
             else
               logputs ("argument missing, using default, for",qual[j].id);
           }
         break;
    }
  }

  if (STEREO)                         /* stereo flag */
    {
      X_SIZE.present = TRUE;           /* xsize flag */
      Y_SIZE.present = TRUE;           /* ysize flag */
      START_PICTURE.present = TRUE;    /* start flag */
    }

  /* Now check for inconsistencies */

  if (LANDSCAPE.present && PORTRAIT.present)   /* landscape with portrait */
    error (LANDSCAPE.id,PORTRAIT.id,4,1);

  if (AUTO.present && ABSOLUTE.present)        /* absolute with autoscale */
    error (AUTO.id,ABSOLUTE.id,5,1);

  if (ABSOLUTE.present && SCALE.present)       /* absolute with scale     */
    error (ABSOLUTE.id,SCALE.id,6,1);

  if (AUTO.present && SCALE.present)           /* autoscale with scale    */
    error (AUTO.id,SCALE.id,7,1);

  if (X_SIZE.present && (AUTO.present || 
			   ABSOLUTE.present || 
			   SCALE.present))  /* xsize with auto/abs/scale */
    error (X_SIZE.id,"auto/abs/scale",8,1);
  
  if (Y_SIZE.present && (AUTO.present || 
			   ABSOLUTE.present || 
			   SCALE.present))  /* ysize with auto/abs/scale */
    error (Y_SIZE.id,"auto/abs/scale",9,1);

  if (STEREO && (AUTO.present || 
			   ABSOLUTE.present || 
			   SCALE.present)) /* stereo with auto/abs/scale */
    error ("stereo","auto/abs/scale",10,1);

  if (i < count) 				           /* grab filename */
    {
      IN_FILE.present = YES;
      (void) strcpy (IN_FILE.value, args [i]);
    }
} /* End of cli_check */

#if defined (PROTOTYPE)
void init (void)
#else
void init ()
#endif
{
  float dummy;
#if !defined (PROTOTYPE)
  void error (), logput (), logputf ();
  char *pltdev_itoa (), *pltdev_ftoa ();
#endif

  if (sscanf (X_POSITION.value,"%f",&xoff) != 1)
    error (X_POSITION.id,X_POSITION.value,20,2);
  if (sscanf (Y_POSITION.value,"%f",&yoff) != 1)
    error (Y_POSITION.id,Y_POSITION.value,30,2);
  if (sscanf (LINE_WT.value,"%f",&lwtstart) != 1)  
    error (LINE_WT.id,LINE_WT.value,40,2);
  if (sscanf (LINE_INC.value,"%f",&lwtinc) != 1)
    error (LINE_INC.id,LINE_INC.value,50,2);
  if (SCALE.present)  
      if (sscanf (SCALE.value,"%f",&dummy) != 1)
	error (SCALE.id,SCALE.value,70,2);
      else if (dummy < 0.0)
        error ("negative scaling is invalid scale=",pltdev_ftoa (dummy,5),71,-1);
  if (sscanf (N_PICT.value,"%d",&num_pictures) != 1)
    error (N_PICT.id,N_PICT.value,80,2);
  else if (num_pictures < 1)
    error ("npict must be at least 1 - npict=",pltdev_itoa(num_pictures),81,-1);
  if (sscanf (POINT_WT.value,"%f",&pwtstart) != 1)
    error (POINT_WT.id,POINT_WT.value,90,2);
  if (sscanf (START_PICTURE.value,"%d",&start_picture) != 1)
    error (START_PICTURE.id,START_PICTURE.value,110,2);
  else if (start_picture < 1)
    error ("start must be at least 1 - start=",pltdev_itoa(start_picture),111,-1);
  if (sscanf (HELP_LEVEL.value,"%d",&help_level) != 1)
    error (HELP_LEVEL.id,HELP_LEVEL.value,130,2);
  else if (help_level < 0 || help_level > 2) help_level = 0;
  if (sscanf (COLOUR_TABLE.value,"%d",&colour_number) != 1)
    error (COLOUR_TABLE.id,COLOUR_TABLE.value,140,2);
  else if (colour_number < -1 || colour_number > MAXCOLOUR)
    error (pltdev_itoa(MAXCOLOUR), pltdev_itoa (colour_number),141,4);
  if (sscanf (X_SIZE.value,"%f",&xsize) != 1)
    error (X_SIZE.id,X_SIZE.value,230,2);
  else if (xsize <= 0) 
    error ("xsize must be greater than zero",X_SIZE.value,231,-1);
  if (sscanf (Y_SIZE.value,"%f",&ysize) != 1)
    error (Y_SIZE.id,Y_SIZE.value,240,2);
  else if (ysize <= 0) 
    error ("ysize must be greater than zero",Y_SIZE.value,241,-1);
  if (sscanf (SEPARATION.value,"%f",&sep) != 1)
    error (SEPARATION.id,SEPARATION.value,250,2);
  else if (sep < 0.0) 
    error ("sep must be >= zero",SEPARATION.value,251,-1);

  for (temp = qual[27].value; *temp != '\0'; temp++) *temp = lcase (*temp);

  if (strcmp(qual[27].value,"ps") == 0 || 
      strcmp(qual[27].value,"postscript") == 0)
    {
      device = (int) POSTSCRIPT;
      A4XD = 576.0;
      A4YD = 830.0;
      CMPTS = 28.35;
      MMPTS = 2.835;
    }
  else if (strcmp(qual[27].value,"hp7550") == 0)
    {
      device = (int) HP7550;
      A4XD = 10500.0;
      A4YD = 7150.0;
      CMPTS = 400.0;
      MMPTS = 40.0;
    }
  else if (strcmp(qual[27].value,"hp7470") == 0)
    {
      device = (int) HP7470;
      A4XD = 10500.0;
      A4YD = 7150.0;
      CMPTS = 400.0;
      MMPTS = 40.0;
    }
  else if (strcmp(qual[27].value,"tek") == 0)
    {
      device = (int) TEK;
      A4XD = 1023.0;
      A4YD = 779.0;
      CMPTS = 46.5;
      MMPTS = 4.65;
    }
  else
    error ("Unknown device",qual[27].value,160,-1);

  /*offsets are in cm so convert into points*/
  logputf ("X offset (cm): ",xoff);
  logputf ("Y offset (cm): ",yoff);
  xoff *= CMPTS;
  yoff *= CMPTS;
  if (X_SIZE.present)
    logputf ("X size (cm): ",xsize);
  if (Y_SIZE.present)
    logputf ("Y size (cm): ",ysize);
  if (SEPARATION.present)
    logputf ("Separation (cm): ",sep);
  sep  *= CMPTS;
  xsize *= CMPTS;
  ysize *= CMPTS;
} /* End of init */

#if defined (PROTOTYPE)
void show_colour (int value)
#else
void show_colour (value)
int value;
#endif
{
  int sfinish = MAXCOLOUR, i;
#if !defined (PROTOTYPE)
  void error ();
#endif

  if (value == -1)
      value = 0;
  else
    sfinish = value;
  CHKPOS(printf ("\n%s\n",mast_head));
  CHKPOS(printf ("Colour\tColour\t Red\t Green\t Blue\t Grey\tDash\n"));
  CHKPOS(printf ("Number\tName\t \t \t \t Level\tLength\n"));
  for (i = value; i <= sfinish; i++)
    {
      CHKPOS(printf ("%4d\t",i));
      CHKPOS(printf ("%s\t",colour_table[i].name));
      CHKPOS(printf ("%6.3f\t",colour_table[i].red));
      CHKPOS(printf ("%6.3f\t",colour_table[i].green));
      CHKPOS(printf ("%6.3f\t",colour_table[i].blue));
      CHKPOS(printf ("%6.3f\t",colour_table[i].grey_level));
      CHKPOS(printf ("%s\n",colour_table[i].dash_length));
    }
  error ("","",0,0);
} /* End of show_colour */

#if defined (PROTOTYPE)
void show_help (int level)
#else
void show_help (level)
int level;
#endif
{
  int i;
#if !defined (PROTOTYPE)
  void error ();
#endif

  CHKPOS(printf ("%s ",arg0));
  if (level > 0)
    {
      i = 0;
      while (i < NVALUES)
        {
          CHKPOS(printf ("[-%s",qual[i].id));
          if (qual[i].opt_type) 
            CHKPOS(printf (" %s",opt_type[qual[i].opt_type]));
          CHKPOS(printf ("] "));
          i++;
        }
      CHKPOS(printf ("filename \n\naction: "));
    }
  CHKPOS(printf ("%s",mast_head));
  if (level > 1)
    {
      i = 0;
      CHKPOS(printf ("\nwhere (current value in brackets):\n\n"));
      while (i < NVALUES)
        {
          CHKPOS(printf ("-%s\t%s (%s)\n",qual[i].id,qual[i].help,qual[i].value));
          i++;
        }
    }
  error ("","",0,0);
} /* End of show_help */

#if defined (PROTOTYPE)
boolean get_header (int *plot)
#else
boolean get_header (plot)
int *plot;
#endif
{
#if !defined (PROTOTYPE)
  void logputs ();
#endif

  (*plot)++;
  if (*plot >num_pictures || fread (header.hchar,SIZE,NUMBER,plot84)< NUMBER) 
      return (FALSE);  
  else 
   {
     header.hchar[26*4] = '\0';
     header.hchar[61*4] = '\0';
     logputs ("Title: ",&TITLEH);
     return (TRUE);
   }
} /* End of get header */

#if defined (PROTOTYPE)
float set_scale (void)
#else
float set_scale ()
#endif
{
  float DX, DY;
  float dx, ximax, ximin;
  float dy, yimax, yimin;
  float scale_factor = 1.0;
#if !defined (PROTOTYPE)
  char *pltdev_ftoa();
  void error (),logput(),logputf(),set_landscape(),set_portrait(),p842ps();
#endif

  if (SCALE.present) 
    {
      if (sscanf (SCALE.value,"%f",&scale_factor) != 1)
	error ("-sca", pltdev_ftoa(scale_factor,3), 1,2);
      logputf ("Scale factor was supplied as: ",scale_factor);
    }

  DX = (float) (IXMAX - IXMIN);
  DY = (float) (IYMAX - IYMIN);

  if (X_SIZE.present)
      DOTMMX = CMPTS*xsize/DX;
  if (Y_SIZE.present)
      DOTMMY = CMPTS*ysize/DY;

  logputf ("DOTMMX: ",DOTMMX); /* Now translate into printer's points */
  logputf ("DOTMMY: ",DOTMMY);
  xscale = DOTMMX / (float) CMPTS ;
  yscale = DOTMMY / (float) CMPTS ;


  /* DX & DY are used to choose between portrait and landscape. Unless told
     either -por or-lan we choose whichever fits the plot best, then we scale.*/

  if (PORTRAIT.present == FALSE && (LANDSCAPE.present  || DY/DX < 1.0))
    set_landscape ();
  else
    set_portrait ();

  /* Now por or lan has been chosen we can use the p842ps() function to convert
     the plot84 coords IXMIN, IYMIN, IXMAX, IYMAX into ps coords, to get side 
     dimensions dx & dy. We then scale using these. */

  p842ps(IXMIN, IYMIN, &ximin, &yimin);
  p842ps(IXMAX, IYMAX, &ximax, &yimax);

  dx = ximax - ximin;
  dy = yimax - yimin;

  if(dx < 0.0)
    dx = - dx;
  if(dy < 0.0)
    dy = - dy;

  /* Having determined the orientation see if rescaling is necessary */
  if (SCALE.present || STEREO || (X_SIZE.present && Y_SIZE.present))
    {
      xscale = xscale * scale_factor;
      yscale = yscale * scale_factor;
    }
  else     /* user has chosen absolute or autoscale */
    {
      if (AUTO.present  || ABSOLUTE.present != TRUE)
	{
	  scale_factor = A4X/dx; 
	  if (A4Y/dy < scale_factor)
	    scale_factor = A4Y/(dy);
	  xscale = xscale * scale_factor;
	  yscale = yscale * scale_factor;
	  logput("The image has been scaled to fit the page,");
	  logput("the scale shown will be in correct.");
	  logputf("The scale factor is now ",scale_factor);
	}
    }
  return (scale_factor);
} /* End of set_scale */

/* convert plot84 (integer) to (float) postscript coordinates */
#if defined (PROTOTYPE)
void p842ps (int ix, int iy, float *x, float *y)
#else
void p842ps (ix, iy, x, y)
int ix;
int iy;
float *x;
float *y;
#endif
{
  float  xi, yi;
  xi = (float)(ix-IXMIN) * xscale;
  yi = (float)(iy-IYMIN) * yscale;
  *x = xi*costheta - yi*sintheta + Xt;
  *y = xi*sintheta + yi*costheta + Yt;
}

#define xx  vals[0]
#define yy  vals[1]

#if defined (PROTOTYPE)
void to_device (float scale_factor)
#else
void to_device (scale_factor)
float scale_factor;
#endif
{
  int i, ret_val;
  short int vals[2];
  float xi, yi;
  boolean point_plot;
#if !defined (PROTOTYPE)
  char *pltdev_itoa();
  void error (),logput(),finish(),move_to(),put_line(),prepare(),
     blanklines(),newpen(),line_weight(),do_header();
  boolean put_point();
#endif

  /* Header always goes at the top of the portrait page */
  if (HEADER)
    do_header (scale_factor);

  logput ("Translation begins ... ");

  prepare ();
  point_plot = FALSE; /* Point plot mode is not the default */
  for (i = 0; i < NREC; i++)
    {
      if ((ret_val = (int) fread(vals,2,2,plot84)) != 2)
        error (IN_FILE.value, pltdev_itoa (ret_val), 10 ,6);
      switch(xx)
	{
	  case -1 : logput ("End of plot");
		    break;
	  case -2:  /* Turn on point plot mode */
		    point_plot = TRUE;
		    break;
  	  case -3:  line_weight (yy);
		    break;
	  case -4 : newpen (yy);
		    break;
	  case -5 : blanklines (yy);
		    break;
	  default : if (yy >= 0)
		      {
			p842ps (xx, yy, &xi, &yi);
			if (point_plot == FALSE) 
			  put_line (xi,yi);
			else 
			  point_plot = put_point (xi,yi);
		      }
		    else
 	              {
			yy = -yy;
			p842ps (xx, yy, &xi, &yi);
			move_to (xi,yi);
		       }
		    break;
	}
    } /* Next i */
  finish ();
} /* End of to_device */

/****************************************************************************
 * Routines used by to_device                                           *
 ****************************************************************************/

#if defined (PROTOTYPE)
void do_header (float scale_factor)
#else
void do_header (scale_factor)
float scale_factor;
#endif
{
  /* Print a header on the top line of the page */
  char my_time[26];
#if !defined (PROTOTYPE)
  char *date();
  void ps_header(), hp_header(), tk_header();
#endif

  (void) strcpy(my_time, date ());
  my_time[strlen (my_time) - 1] = '\0';	/* remove new line at end of string */
  if (device == POSTSCRIPT)
    ps_header (scale_factor,my_time);
  else if (device == HP7550 || device == HP7470)
    hp_header (scale_factor,my_time);
  else if (device == TEK)
    tk_header (scale_factor,my_time);
} /* End of do_header */

#if defined (PROTOTYPE)
void set_portrait (void)
#else
void set_portrait ()
#endif
{
#if !defined (PROTOTYPE)
  void logput(), ps_portrait(), hp_portrait(), tk_portrait ();
#endif

  logput ("Portrait orientation set");
  if (device == POSTSCRIPT)
    ps_portrait ();
  else if (device == HP7550 || device == HP7470)
    hp_portrait ();
  else if (device == TEK)
    tk_portrait ();
} /* End of set_portrait */

#if defined (PROTOTYPE)
void set_landscape (void)
#else
void set_landscape ()
#endif
{
#if !defined (PROTOTYPE)
  void logput(), ps_landscape(), hp_landscape(), tk_landscape ();
#endif

  logput ("Landscape orientation set");
  if (device == POSTSCRIPT)
    ps_landscape ();
  else if (device == HP7550 || device == HP7470)
    hp_landscape ();
  else if (device == TEK)
    tk_landscape ();
  landscape = TRUE;
} /* End of set_landscape */

#if defined (PROTOTYPE)
void prepare (void)
#else
void prepare ()
#endif
{
#if !defined (PROTOTYPE)
  void ps_prepare(), hp_prepare(), tk_prepare ();
#endif
  if (device == POSTSCRIPT)
    ps_prepare ();
  else if (device == HP7550 || device == HP7470)
    hp_prepare ();
  else if (device == TEK)
    tk_prepare ();
  path_started = TRUE;
} /* End of prepare */

#if defined (PROTOTYPE)
boolean put_point (float x, float y)
#else
boolean put_point (x, y)
float x;
float y;
#endif
{
  /* Put point always returns FALSE to switch off point plot mode in caller */
  /* To generate the point we add a fixed amount and lineto it */
#if !defined (PROTOTYPE)
  void put_line(),move_to();
#endif

  move_to (x,y);
  if (device == POSTSCRIPT)
    put_line (x+pwtstart,y+pwtstart);
  else if (device == HP7550 || device == HP7470) {
    CHKPOS(fprintf (ps,"PD; CI%d; PU; ",(int) pwtstart)); }
  else if (device == TEK)
    put_line (x+pwtstart,y+pwtstart);
  return (FALSE);
} /* End of put_point */

#if defined (PROTOTYPE)
void line_weight (short int weight)
#else
void line_weight (weight)
short int weight;
#endif
{
  if (path_started)
    {
      if (device == POSTSCRIPT) {
        CHKPOS(fprintf (ps,"S\n")); }
      else if (device == HP7550 || device == HP7470) {
        CHKPOS(fprintf (ps,"PU; \n")); }
      else if (device == TEK)
        fprintf (stdout,"%c\n",(int) 31);
      path_started = FALSE;
    }
  lwt = (lwtinc * weight) + lwtstart;
  if (device == POSTSCRIPT) CHKPOS(fprintf (ps,"%3.1f setlinewidth\n",lwt));
} /* End of line_weight */

#if defined (PROTOTYPE)
void newpen (short int pen)
#else
void newpen (pen)
short int pen;
#endif
{
#if !defined (PROTOTYPE)
  void ps_newpen(),hp_newpen(),tk_newpen();
#endif
  if (device == POSTSCRIPT)
    ps_newpen (pen);
  else if (device == HP7550 || device == HP7470)
    hp_newpen (pen);
  else if (device == TEK)
    tk_newpen (pen);
} /* End of newpen */

#if defined (PROTOTYPE)
void blanklines (int number)
#else
void blanklines (number)
int number;
#endif
{
#if !defined (PROTOTYPE)
  void logputd();
#endif

  /* number indicates the number of rows to skip, 100 rows per inch */
  logputd ("Number of blank lines ",number);
} /* End of blanklines */

#if defined (PROTOTYPE)
void put_line (float x, float y)
#else
void put_line (x, y)
float x;
float y;
#endif
{
  if (device == POSTSCRIPT) {
    CHKPOS(fprintf (ps,"%3.1f %3.1f L\n",x,y)); }
  else if (device == HP7550 || device == HP7470) {
    CHKPOS(fprintf (ps,"PD%d,%d; PU; \n",(int) x,(int) y)); }
  else if (device == TEK)
    {
      int HiY, LoY, HiX, LoX;

      CHKPOS(fprintf (stdout,"%c",(int) 29));
      HiY = ((int) Yold) / 32  +  32;
      LoY = ((int) Yold) % 32  +  96;
      HiX = ((int) Xold) / 32  +  32;
      LoX = ((int) Xold) % 32  +  64;
      CHKPOS(fprintf (stdout,"%c%c%c%c",HiY, LoY, HiX, LoX));
      HiY = ((int) y) / 32  +  32;
      LoY = ((int) y) % 32  +  96;
      HiX = ((int) x) / 32  +  32;
      LoX = ((int) x) % 32  +  64;
      CHKPOS(fprintf (stdout,"%c%c%c%c\n",HiY, LoY, HiX, LoX));
      Xold = x; 
      Yold = y;
    }
} /* End of put_line */

#if defined (PROTOTYPE)
void move_to (float x, float y)
#else
void move_to (x, y)
float x;
float y;
#endif
{
  if (device == POSTSCRIPT) {
    CHKPOS(fprintf (ps,"S N %3.1f %3.1f M\n",x,y)); }
  else if (device == HP7550 || device == HP7470) {
    CHKPOS(fprintf (ps,"PU%d,%d; \n",(int) x,(int) y)); }
  else if (device == TEK)
    {
       Xold = x;
       Yold = y;
    }
  path_started = TRUE;
} /* End of move_to */

#if defined (PROTOTYPE)
void finish (void)
#else
void finish ()
#endif
{
  if (device == POSTSCRIPT)
    {
      CHKPOS(fprintf (ps,"S\n"));
      if (STEREO == FALSE) CHKPOS(fprintf (ps,"showpage\n"));
    }
  else if (device == HP7550)
    { 
      CHKPOS(fprintf (ps,"PU; "));
      if (STEREO == FALSE) CHKPOS(fprintf (ps,"PG; \n"));
    }
  else if (device == HP7470)
    { 
      CHKPOS(fprintf (ps,"PU; "));
      if (STEREO == FALSE) fprintf (ps,"\n\n****** Cut Here ******\n\n"); 
    }
  else if (device == TEK)
    {
      char key[80];

      if (STEREO == FALSE) 
        {
          CHKPOS(fprintf (stdout,"%c Press RETURN to continue\n",(int) 31));
          fscanf (stdin,"%c",key);
          CHKPOS(fprintf (stdout,"%c%c\n",(int) 27,(int) 12));
        }
    }
  path_started = FALSE;
} /* End of finish */

#if defined (PROTOTYPE)
void maybeswap (float *a, float *b)		/* ensure *a, *b are ordered */
#else
void maybeswap (a, b)
float *a;
float *b;
#endif
{
  float foo;
  if (*a>*b) 
    { 
      foo = *a; 
      *a = *b; 
      *b = foo; 
    }
}

#if defined (PROTOTYPE)
void prologue (void)
#else
void prologue ()
#endif
{
#if !defined (PROTOTYPE)
  void ps_prologue();
#endif
  if (device == POSTSCRIPT) ps_prologue ();
}

#if defined (PROTOTYPE)
void epilogue (void)
#else
void epilogue ()
#endif
{
#if !defined (PROTOTYPE)
  void error (),ps_epilogue();
#endif
  if (device == POSTSCRIPT) ps_epilogue ();
  if (fclose (ps))
    error ("Can't close output file","",1,-1);
}

/****************************************************************************
 * Toolkit                                                                 *
 ****************************************************************************/

#if defined (PROTOTYPE)
char *pltdev_itoa (int i)			/* change an int to an ascii string */
			                /* i is integer to be converted     */
#else
char *pltdev_itoa (i)
int i;
#endif
{
  char *ival;

  ival = malloc (20); 			/* allocate 20 bytes of storage     */
  sprintf (ival,"%d",i);		/* do the conversion		    */
  while (*ival == ' ') ival++;		/* remove leading blanks	    */
  return (ival); 			/* return the result		    */
} /* End of pltdev_itoa */

#if defined (PROTOTYPE)
char *pltdev_ftoa (float f, int d)            /* change a float to an ascii string */
				       /* f is float to be converted        */
				       /* d is number of decimal places     */
#else
char *pltdev_ftoa (f, d)
float f;
int d;
#endif
{
  char *fval;

  fval = malloc (255); 		       /* allocate 255 bytes of storage     */
  sprintf (fval,"%.*f",d,f);           /* do the conversion	            */
  while (*fval == ' ') fval++;	       /* remove leading blanks		     */
  return (fval); 		       /* return the result		     */
} /* End of pltdev_ftoa */

#if defined (PROTOTYPE)
void logput (char *message) 
#else
void logput (message)
char *message;
#endif
{
  if (LOG) CHKPOS(printf ("%s: %s\n",arg0,message));
} /* End of logput */

#if defined (PROTOTYPE)
void logputd (char *message, int arg) 
#else
void logputd (message, arg) 
char *message;
int arg;
#endif
{
  if (LOG) CHKPOS(printf ("%s: %s %d\n",arg0,message,arg));
} /* End of logputd */

#if defined (PROTOTYPE)
void logputf (char *message, float arg) 
#else
void logputf (message, arg) 
char *message;
float arg;
#endif
{
  if (LOG) CHKPOS(printf ("%s: %s %12.8f\n",arg0,message,arg));
} /* End of logputf */

#if defined (PROTOTYPE)
void logputs (char *message, char *arg) 
#else
void logputs (message, arg) 
char *message;
char *arg;
#endif
{
  if (LOG) CHKPOS(printf ("%s: %s %s\n",arg0,message,arg));
} /* End of logputs */

#if defined (PROTOTYPE)
int print_file (char *fname, char *pname)  /* returns status of print command */
                                           /* fname name of file to print */
                                           /* pname printer name for lpr command */
#else
int print_file (fname, pname) 
char *fname;
char *pname;
#endif
{
  char *command;
  size_t space;
  int ret_val, ex_ok = -1;

  space = 20 + strlen (pname) + strlen (fname);
  command = malloc (space);
  (void) strcpy (command, print_command);
  (void) strcat (command, pname);
  (void) strcat (command, " ");
  (void) strcat (command, fname);
  logput ("Printing ... ");
  ret_val = system (command);
#ifdef VMS
  if (ret_val != ex_ok) ret_val = 0;  /* VMS returns value > 0 for success */
#endif
  return (ret_val);
} /* End of print_file */

#if defined (PROTOTYPE)
int delete_file (char *fname)                /* returns status of delete command */
                                             /* fname name of file to delete */
#else
int delete_file (fname)
char *fname;
#endif
{
  char *command;
  size_t space;
  int ret_val, ex_ok = -1;

  space = 20 + strlen (fname);
  command = malloc (space);
  (void) strcpy (command, delete_command);
  (void) strcat (command, fname);
  logput ("Deleting ... ");
#ifdef VMS
  (void) strcat (command, ";*");            /* VMS requires version numbers */
#endif
  ret_val = system (command);
#ifdef VMS
  if (ret_val != ex_ok) ret_val = 0;  /* VMS returns value > 0 for success */
#endif
  return (ret_val);
} /* End of delete_file */

/****************************************************************************
 * Machine Specific Routines                                                *
 ****************************************************************************/

#if defined (PROTOTYPE)
char *date (void)		/* Produces an ASCII character time string */
#else                           /* of the form:   Mon Mar 4 10:21:45 1978  */
char *date ()
#endif
{				
  time_t clock;
  struct tm *ptm;
 
  clock = time(&clock);
  ptm = localtime(&clock);
  return (asctime(ptm));
} /* End of date */

/***************************************************************************
 * Device driver routines here - all use first two letter to signal device *
 ***************************************************************************/

#if defined (PROTOTYPE)
void ps_header (float scale_factor, char my_time[26])
#else
void ps_header (scale_factor, my_time)
float scale_factor;
char my_time[26];
#endif
{

  CHKPOS(fprintf (ps,"/Times-Roman findfont\n"));
  CHKPOS(fprintf (ps,"10 scalefont\n"));
  CHKPOS(fprintf (ps,"setfont\n"));
  CHKPOS(fprintf (ps,"24 %3.1f M\n",A4YD-13));
  CHKPOS(fprintf (ps,"( User: %s  Date: %s ) show\n",getenv("USER"),my_time));
  if (STEREO == FALSE)
    {
      CHKPOS(fprintf (ps,"( Scale 1:%5.2f ) show\n",scale_factor));
      CHKPOS(fprintf (ps,"( Picture: %d of %d ) show\n",MPIC,NPICS));
    }
  else
    {
      CHKPOS(fprintf (ps,"( Stereo Picture ) show\n"));
      CHKPOS(fprintf (ps,"( Left: %d ) show\n",start_picture));
      CHKPOS(fprintf (ps,"( Right: %d ) show\n",num_pictures));
    }
  CHKPOS(fprintf (ps,"( File: %s %s ) show\n",OUT_FILE.value,qual[27].value));
  CHKPOS(fprintf (ps,"0 0 M\n"));
}

#if defined (PROTOTYPE)
void ps_prologue (void)
#else
void ps_prologue ()
#endif
{
  float xmin, xmax, ymin, ymax;
  
  p842ps (IXMIN, IYMIN, &xmin, &ymin);
  p842ps (IXMAX, IYMAX, &xmax, &ymax);
  maybeswap (&xmin, &xmax);
  maybeswap (&ymin, &ymax);
  CHKPOS(fprintf (ps, "%%!PS-Adobe-3.0\n\
%%%%Creator: pltdev\n\
%%%%Pages: %d\n", num_pictures));
  CHKPOS(fprintf (ps, "%%%%BoundingBox: %d %d %d %d\n", (int)xmin,
		  (int)ymin, (int)xmax, (int)ymax));
  if (landscape)
    CHKPOS(fprintf (ps, "%%%%Orientation: Landscape\n"));
  if (HEADER)
    CHKPOS(fprintf (ps, "%%%%DocumentNeededResources: font Times-Roman\n"));
  CHKPOS(fprintf (ps, "%%%%EndComments\n"));
  if (HEADER)
    CHKPOS(fprintf (ps, "%%%%BeginDefaults\n\
%%%%PageResources: font Times-Roman\n\
%%%%EndDefaults\n"));
  CHKPOS(fprintf (ps, "%%%%BeginProlog\n\
/L {lineto} bind def\n\
/M {moveto} bind def\n\
/S {stroke} bind def\n\
/N {newpath} bind def\n\
%%%%EndProlog\n"));
}

#if defined (PROTOTYPE)
void ps_epilogue (void)
#else
void ps_epilogue ()
#endif
{
  CHKPOS(fprintf (ps, "%%%%EOF\n"));
}

#if defined (PROTOTYPE)
void hp_header (float scale_factor, char my_time[26])
#else
void hp_header (scale_factor, my_time)
float scale_factor;
char my_time[26];
#endif
{

  CHKPOS(fprintf (ps,"DF; SP1; CS0; "));
  CHKPOS(fprintf (ps,"DI0,1; SI0.13,0.19; "));
  CHKPOS(fprintf (ps,"PU%d,0; PD; \n",(int) 125));
  CHKPOS(fprintf (ps,"LBUser: %s  Date: %s \003; \n",getenv("USER"),my_time));
  if (STEREO == FALSE)
    {
      CHKPOS(fprintf (ps,"LBScale 1:%5.2f \003; \n",scale_factor));
      CHKPOS(fprintf (ps,"LBPicture: %d of %d \003; \n",MPIC,NPICS));
    }
  else
    {
      CHKPOS(fprintf (ps,"LBStereo Picture \003; \n"));
      CHKPOS(fprintf (ps,"LBLeft: %d \003; \n",start_picture));
      CHKPOS(fprintf (ps,"LBRight: %d \003; \n",num_pictures));
    }
  CHKPOS(fprintf (ps,"LBFile: %s %s\003; \n",OUT_FILE.value,qual[27].value));
  CHKPOS(fprintf (ps,"PU0,0; "));
}

#if defined (PROTOTYPE)
void tk_header (float scale_factor,char my_time[26])
#else
void tk_header (scale_factor, my_time)
float scale_factor;
char my_time[26];
#endif
{

  CHKPOS(fprintf (stdout,"%c",(int) 31));
  CHKPOS(fprintf (stdout,"User: %s  Date: %s",getenv("USER"),my_time));
  if (STEREO == FALSE)
    {
      CHKPOS(fprintf (stdout,"Scale 1:%5.2f ",scale_factor));
      CHKPOS(fprintf (stdout,"Picture: %d of %d ",MPIC,NPICS));
    }
  else
    {
      CHKPOS(fprintf (stdout,"Stereo Picture "));
      CHKPOS(fprintf (stdout,"Left: %d ",start_picture));
      CHKPOS(fprintf (stdout,"Right: %d ",num_pictures));
    }
  CHKPOS(fprintf (stdout,"File: %s %s",OUT_FILE.value,qual[27].value));
}

#if defined (PROTOTYPE)
void ps_portrait (void)
#else
void ps_portrait ()
#endif
{
  theta = ZERO; sintheta = 0.0; costheta = 1.0;
  Xt = ZERO;
  Yt = ZERO;
}

#if defined (PROTOTYPE)
void hp_portrait (void)
#else
void hp_portrait ()
#endif
{
  theta = PI/2;
  Xt = A4X;
  Yt = ZERO;
}

#if defined (PROTOTYPE)
void tk_portrait (void)
#else
void tk_portrait ()
#endif
{
  theta = ZERO;
  Xt = ZERO;
  Yt = ZERO;
}

#if defined (PROTOTYPE)
void ps_landscape (void)
#else
void ps_landscape ()
#endif
{
  theta = PI/2; sintheta = 1.0; costheta = 0.0;
  Xt = A4X;
  Yt = ZERO;
}

#if defined (PROTOTYPE)
void hp_landscape (void)
#else
void hp_landscape ()
#endif
{
  theta = PI;
  Xt = A4X;
  Yt = A4Y;
}

#if defined (PROTOTYPE)
void tk_landscape (void)
#else
void tk_landscape ()
#endif
{
  theta = PI/2;
  Xt = A4X;
  Yt = ZERO;
}

#if defined (PROTOTYPE)
void ps_prepare (void)
#else
void ps_prepare ()
#endif
{
  float xmin, xmax, ymin, ymax;

  CHKPOS(fprintf (ps, "%%%%Page: %d %d\n", plots, plots));
  p842ps (IXMIN, IYMIN, &xmin, &ymin);
  p842ps (IXMAX, IYMAX, &xmax, &ymax);
  maybeswap (&xmin, &xmax);
  maybeswap (&ymin, &ymax);
  CHKPOS(fprintf (ps, "%%%%PageBoundingBox: %d %d %d %d\n", (int)xmin,
		    (int)ymin, (int)xmax, (int)ymax));
  CHKPOS(fprintf (ps, "%3.1f setlinewidth 1 setlinejoin N 0 0 M\n",
		  lwt));
  Xt += xoff;
  Yt += yoff;
}

#if defined (PROTOTYPE)
void hp_prepare (void)
#else
void hp_prepare ()
#endif
{
  CHKPOS(fprintf (ps,"DF; "));
  CHKPOS(fprintf (ps,"IN; "));
  CHKPOS(fprintf (ps,"SP1; "));
  Xt -= yoff;
  Yt += xoff;
  CHKPOS(fprintf (ps,"IP0,0,%d,%d; ",(int) A4XD,(int) A4YD));
  CHKPOS(fprintf (ps,"PU0,0; SC0,0,%d,%d; ",(int) IXMAX,(int) IYMAX));
}

#if defined (PROTOTYPE)
void tk_prepare (void)
#else
void tk_prepare ()
#endif
{
  CHKPOS(fprintf (stdout,"%c[2J",(int) 27));
  Xt += xoff;
  Yt += yoff;
  CHKPOS(fprintf (stdout,"%c1",(int) 27));
  CHKPOS(fprintf (stdout,"%c",(int) 31));
}

#if defined (PROTOTYPE)
void ps_newpen (short int pen)
#else
void ps_newpen (pen)
short int pen;
#endif
{
  if (path_started)
    {
      CHKPOS(fprintf (ps,"S\n"));
      path_started = FALSE;
    }
  if (pen < 1 || pen > MAXCOLOUR) pen = 0;
  if (COLOUR.present  && *COLOUR.value == 'g') {    /* colour by greyscale */
    CHKPOS(fprintf (ps,"%6.3f setgray\n",colour_table[pen].grey_level));}
  else if (COLOUR.present  && *COLOUR.value == 'd') {  /* colour by dashes */
    CHKPOS(fprintf (ps,"%s 0 setdash\n",colour_table[pen].dash_length));}
  else if (COLOUR.present  && *COLOUR.value == 'c') {     /* colour by RGB */
    CHKPOS(fprintf (ps,"%6.3f %6.3f %6.3f setrgbcolor\n",colour_table[pen].red,
                    colour_table[pen].green,colour_table[pen].blue));}
  else 					         /* colour by line widths */
    {
      lwt = (lwtinc * pen) + lwtstart;
      CHKPOS(fprintf (ps,"%3.1f setlinewidth\n",lwt));
    }
}

#if defined (PROTOTYPE)
void hp_newpen (short int pen)
#else
void hp_newpen (pen)
short int pen;
#endif
{
#if !defined (PROTOTYPE)
  void error ();
#endif
  if (path_started)
    {
      CHKPOS(fprintf (ps,"PU; ")); 
      path_started = FALSE;
    }
  if (pen < 1 || pen > MAXCOLOUR) pen = 0;
  if (COLOUR.present  && *COLOUR.value == 'g')     /* colour by greyscale */
    error (COLOUR.value,"not allowed on this device",-1,220);
  else if (COLOUR.present  && *COLOUR.value == 'd') {  /* colour by dashes */
    CHKPOS(fprintf (ps,"LT%d; \n",pen)); }
  else if (COLOUR.present  && *COLOUR.value == 'l') /* colour by line widths */
    error (COLOUR.value,"not allowed on this device",-1,220);
  else                                                   /* colour by RGB */
    CHKPOS(fprintf (ps,"SP%d; \n",pen));
}

#if defined (PROTOTYPE)
void tk_newpen (short int pen)
#else
void tk_newpen (pen)
short int pen;
#endif
{
#if !defined (PROTOTYPE)
  void error ();
#endif
  if (path_started)
    {
      CHKPOS(fprintf (stdout,"%c",(int) 31)); 
      path_started = FALSE;
    }
  if (pen < 1 || pen > MAXCOLOUR) pen = 0;
  if (COLOUR.present  && *COLOUR.value == 'g')     /* colour by greyscale */
    error (COLOUR.value,"not allowed on this device",-1,220);
  else if (COLOUR.present  && *COLOUR.value == 'c')      /* colour by RGB */
    error (COLOUR.value,"not allowed on this device",-1,220);
  else if (COLOUR.present  && *COLOUR.value == 'l') { /* colour by line widths */
      CHKPOS(fprintf (stdout,"%c%c\n",(int) 27,(int) 92)); }
  else                                                /* colour by dashes */
    switch (pen) {
    case 1: CHKPOS(fprintf (stdout,"%c%c\n",(int) 27,(int) 92));
            break;
    case 2: CHKPOS(fprintf (stdout,"%ca\n",(int) 27));
            break;
    case 3: CHKPOS(fprintf (stdout,"%cb\n",(int) 27));
            break;
    case 4: CHKPOS(fprintf (stdout,"%cc\n",(int) 27));
            break;
    case 5: CHKPOS(fprintf (stdout,"%cd\n",(int) 27));
            break;
   default: CHKPOS(fprintf (stdout,"%c%c\n",(int) 27,(int) 92));
            break;
    }
}
