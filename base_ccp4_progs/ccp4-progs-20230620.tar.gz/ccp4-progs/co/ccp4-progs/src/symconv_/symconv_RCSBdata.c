/* This file has been automatically from the data file
   "space_group.cif" by the script make_GetRCSBSpacegroup.py.
   It hard-codes spacegroup data used by the RCSB in order
   to make it accessible to the symconv program */


#include "symconv_lib.h"

CCP4SPG *GetRCSBSpacegroup(char *name) {

  /* This function was automatically generated
     from spacegroup data provided by the RSCB
     using make_GetRCSBSpacegroup.py */

  CCP4SPG *spgrp=NULL;
  int nsym=0;
  float rsym[4][4];

  if (strcmp(name,"A 1") == 0) {
    /* Spacegroup 'A 1' */
    printf(" Located RCSB data for spacegroup 'A 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"A 1 2 1") == 0) {
    /* Spacegroup 'A 1 2 1' */
    printf(" Located RCSB data for spacegroup 'A 1 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"A 2") == 0) {
    /* Spacegroup 'A 2' */
    printf(" Located RCSB data for spacegroup 'A 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"B 1 1 2") == 0) {
    /* Spacegroup 'B 1 1 2' */
    printf(" Located RCSB data for spacegroup 'B 1 1 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"B 2") == 0) {
    /* Spacegroup 'B 2' */
    printf(" Located RCSB data for spacegroup 'B 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"B 2 21 2") == 0) {
    /* Spacegroup 'B 2 21 2' */
    printf(" Located RCSB data for spacegroup 'B 2 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    AddSymopFromString(spgrp,"x,-y+1/2,-z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"C 2") == 0) {
    /* Spacegroup 'C 2' */
    printf(" Located RCSB data for spacegroup 'C 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"C 1 2 1") == 0) {
    /* Spacegroup 'C 1 2 1' */
    printf(" Located RCSB data for spacegroup 'C 1 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"C 21") == 0) {
    /* Spacegroup 'C 21' */
    printf(" Located RCSB data for spacegroup 'C 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y,-z");
    return spgrp;
  }
  if (strcmp(name,"C 1 21 1") == 0) {
    /* Spacegroup 'C 1 21 1' */
    printf(" Located RCSB data for spacegroup 'C 1 21 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y,-z");
    return spgrp;
  }
  if (strcmp(name,"C 2(A 112)") == 0) {
    /* Spacegroup 'C 2(A 112)' */
    printf(" Located RCSB data for spacegroup 'C 2(A 112)'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"C 2 2 2") == 0) {
    /* Spacegroup 'C 2 2 2' */
    printf(" Located RCSB data for spacegroup 'C 2 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"C 2 2 21") == 0) {
    /* Spacegroup 'C 2 2 21' */
    printf(" Located RCSB data for spacegroup 'C 2 2 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y,-z+1/2");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"C 4 21 2") == 0) {
    /* Spacegroup 'C 4 21 2' */
    printf(" Located RCSB data for spacegroup 'C 4 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"F 2 2 2") == 0) {
    /* Spacegroup 'F 2 2 2' */
    printf(" Located RCSB data for spacegroup 'F 2 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"F 2 3") == 0) {
    /* Spacegroup 'F 2 3' */
    printf(" Located RCSB data for spacegroup 'F 2 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"z,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z,-x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-z,-x+1/2,y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y,-z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-y,-z+1/2,x+1/2");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y,-z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,-x,-y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,x,-y+1/2");
    AddSymopFromString(spgrp,"y+1/2,z,x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z,-x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x+1/2,y");
    AddSymopFromString(spgrp,"-z+1/2,x+1/2,-y");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x");
    AddSymopFromString(spgrp,"-y+1/2,z+1/2,-x");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z+1/2,x");
    return spgrp;
  }
  if (strcmp(name,"F 4 2 2") == 0) {
    /* Spacegroup 'F 4 2 2' */
    printf(" Located RCSB data for spacegroup 'F 4 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"y,-x+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"y,x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-y,-x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y,-z+1/2");
    AddSymopFromString(spgrp,"y+1/2,x,-z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-x,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"F 4 3 2") == 0) {
    /* Spacegroup 'F 4 3 2' */
    printf(" Located RCSB data for spacegroup 'F 4 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"-x,-z,-y");
    AddSymopFromString(spgrp,"-x,z,y");
    AddSymopFromString(spgrp,"x,-z,y");
    AddSymopFromString(spgrp,"x,z,-y");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-z,-y,-x");
    AddSymopFromString(spgrp,"-z,y,x");
    AddSymopFromString(spgrp,"z,-y,x");
    AddSymopFromString(spgrp,"z,y,-x");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"x,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"z,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z,-x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-z,-x+1/2,y+1/2");
    AddSymopFromString(spgrp,"y,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"y,-z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-y,-z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-x,-z+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-x,z+1/2,y+1/2");
    AddSymopFromString(spgrp,"x,-z+1/2,y+1/2");
    AddSymopFromString(spgrp,"x,z+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-y,-x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-y,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"y,-x+1/2,z+1/2");
    AddSymopFromString(spgrp,"y,x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-z,-y+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-z,y+1/2,x+1/2");
    AddSymopFromString(spgrp,"z,-y+1/2,x+1/2");
    AddSymopFromString(spgrp,"z,y+1/2,-x+1/2");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y,-z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,-x,-y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,x,-y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"y+1/2,z,x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z,-x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z,-x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-z,-y+1/2");
    AddSymopFromString(spgrp,"-x+1/2,z,y+1/2");
    AddSymopFromString(spgrp,"x+1/2,-z,y+1/2");
    AddSymopFromString(spgrp,"x+1/2,z,-y+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-x,-z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,x,-z+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-y,-x+1/2");
    AddSymopFromString(spgrp,"-z+1/2,y,x+1/2");
    AddSymopFromString(spgrp,"z+1/2,-y,x+1/2");
    AddSymopFromString(spgrp,"z+1/2,y,-x+1/2");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x+1/2,y");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z+1/2,x");
    AddSymopFromString(spgrp,"-x+1/2,-z+1/2,-y");
    AddSymopFromString(spgrp,"-x+1/2,z+1/2,y");
    AddSymopFromString(spgrp,"x+1/2,-z+1/2,y");
    AddSymopFromString(spgrp,"x+1/2,z+1/2,-y");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z");
    AddSymopFromString(spgrp,"-z+1/2,-y+1/2,-x");
    AddSymopFromString(spgrp,"-z+1/2,y+1/2,x");
    AddSymopFromString(spgrp,"z+1/2,-y+1/2,x");
    AddSymopFromString(spgrp,"z+1/2,y+1/2,-x");
    return spgrp;
  }
  if (strcmp(name,"F 41 3 2") == 0) {
    /* Spacegroup 'F 41 3 2' */
    printf(" Located RCSB data for spacegroup 'F 41 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y,-z+1/2");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z+1/2,-x,-y+1/2");
    AddSymopFromString(spgrp,"-z,-x+1/2,y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,x+1/2,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y+1/2,z+1/2,-x");
    AddSymopFromString(spgrp,"y+1/2,-z,-x+1/2");
    AddSymopFromString(spgrp,"-y,-z+1/2,x+1/2");
    AddSymopFromString(spgrp,"y+3/4,x+1/4,-z+3/4");
    AddSymopFromString(spgrp,"-y+1/4,-x+1/4,-z+1/4");
    AddSymopFromString(spgrp,"y+1/4,-x+3/4,z+3/4");
    AddSymopFromString(spgrp,"-y+3/4,x+3/4,z+1/4");
    AddSymopFromString(spgrp,"x+3/4,z+1/4,-y+3/4");
    AddSymopFromString(spgrp,"-x+3/4,z+3/4,y+1/4");
    AddSymopFromString(spgrp,"-x+1/4,-z+1/4,-y+1/4");
    AddSymopFromString(spgrp,"x+1/4,-z+3/4,y+3/4");
    AddSymopFromString(spgrp,"z+3/4,y+1/4,-x+3/4");
    AddSymopFromString(spgrp,"z+1/4,-y+3/4,x+3/4");
    AddSymopFromString(spgrp,"-z+3/4,y+3/4,x+1/4");
    AddSymopFromString(spgrp,"-z+1/4,-y+1/4,-x+1/4");
    AddSymopFromString(spgrp,"x,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z+1/2,x,-y+1/2");
    AddSymopFromString(spgrp,"y,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"y+3/4,x+3/4,-z+1/4");
    AddSymopFromString(spgrp,"-y+1/4,-x+3/4,-z+3/4");
    AddSymopFromString(spgrp,"y+1/4,-x+1/4,z+1/4");
    AddSymopFromString(spgrp,"-y+3/4,x+1/4,z+3/4");
    AddSymopFromString(spgrp,"x+3/4,z+3/4,-y+1/4");
    AddSymopFromString(spgrp,"-x+3/4,z+1/4,y+3/4");
    AddSymopFromString(spgrp,"-x+1/4,-z+3/4,-y+3/4");
    AddSymopFromString(spgrp,"x+1/4,-z+1/4,y+1/4");
    AddSymopFromString(spgrp,"z+3/4,y+3/4,-x+1/4");
    AddSymopFromString(spgrp,"z+1/4,-y+1/4,x+1/4");
    AddSymopFromString(spgrp,"-z+3/4,y+1/4,x+3/4");
    AddSymopFromString(spgrp,"-z+1/4,-y+3/4,-x+3/4");
    AddSymopFromString(spgrp,"x+1/2,y,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z+1/2,x,y+1/2");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x+1/2,y");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y+1/2,z,x+1/2");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z+1/2,x");
    AddSymopFromString(spgrp,"y+1/4,x+1/4,-z+1/4");
    AddSymopFromString(spgrp,"-y+3/4,-x+1/4,-z+3/4");
    AddSymopFromString(spgrp,"y+3/4,-x+3/4,z+1/4");
    AddSymopFromString(spgrp,"-y+1/4,x+3/4,z+3/4");
    AddSymopFromString(spgrp,"x+1/4,z+1/4,-y+1/4");
    AddSymopFromString(spgrp,"-x+1/4,z+3/4,y+3/4");
    AddSymopFromString(spgrp,"-x+3/4,-z+1/4,-y+3/4");
    AddSymopFromString(spgrp,"x+3/4,-z+3/4,y+1/4");
    AddSymopFromString(spgrp,"z+1/4,y+1/4,-x+1/4");
    AddSymopFromString(spgrp,"z+3/4,-y+3/4,x+1/4");
    AddSymopFromString(spgrp,"-z+1/4,y+3/4,x+3/4");
    AddSymopFromString(spgrp,"-z+3/4,-y+1/4,-x+3/4");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y");
    AddSymopFromString(spgrp,"z,-x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"y+1/4,x+3/4,-z+3/4");
    AddSymopFromString(spgrp,"-y+3/4,-x+3/4,-z+1/4");
    AddSymopFromString(spgrp,"y+3/4,-x+1/4,z+3/4");
    AddSymopFromString(spgrp,"-y+1/4,x+1/4,z+1/4");
    AddSymopFromString(spgrp,"x+1/4,z+3/4,-y+3/4");
    AddSymopFromString(spgrp,"-x+1/4,z+1/4,y+1/4");
    AddSymopFromString(spgrp,"-x+3/4,-z+3/4,-y+1/4");
    AddSymopFromString(spgrp,"x+3/4,-z+1/4,y+3/4");
    AddSymopFromString(spgrp,"z+1/4,y+3/4,-x+3/4");
    AddSymopFromString(spgrp,"z+3/4,-y+1/4,x+3/4");
    AddSymopFromString(spgrp,"-z+1/4,y+1/4,x+1/4");
    AddSymopFromString(spgrp,"-z+3/4,-y+3/4,-x+1/4");
    return spgrp;
  }
  if (strcmp(name,"I 1 2 1") == 0) {
    /* Spacegroup 'I 1 2 1' */
    printf(" Located RCSB data for spacegroup 'I 1 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 1 21 1") == 0) {
    /* Spacegroup 'I 1 21 1' */
    printf(" Located RCSB data for spacegroup 'I 1 21 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 2") == 0) {
    /* Spacegroup 'I 2' */
    printf(" Located RCSB data for spacegroup 'I 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 2 2 2") == 0) {
    /* Spacegroup 'I 2 2 2' */
    printf(" Located RCSB data for spacegroup 'I 2 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 2 3") == 0) {
    /* Spacegroup 'I 2 3' */
    printf(" Located RCSB data for spacegroup 'I 2 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-x+1/2,y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-z+1/2,x+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 21") == 0) {
    /* Spacegroup 'I 21' */
    printf(" Located RCSB data for spacegroup 'I 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 21 3") == 0) {
    /* Spacegroup 'I 21 3' */
    printf(" Located RCSB data for spacegroup 'I 21 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z,-x,-y+1/2");
    AddSymopFromString(spgrp,"-z,-x+1/2,y");
    AddSymopFromString(spgrp,"-z+1/2,x,-y");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x+1/2");
    AddSymopFromString(spgrp,"-y,-z+1/2,x");
    return spgrp;
  }
  if (strcmp(name,"I 21 21 21") == 0) {
    /* Spacegroup 'I 21 21 21' */
    printf(" Located RCSB data for spacegroup 'I 21 21 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 4") == 0) {
    /* Spacegroup 'I 4' */
    printf(" Located RCSB data for spacegroup 'I 4'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 4 2 2") == 0) {
    /* Spacegroup 'I 4 2 2' */
    printf(" Located RCSB data for spacegroup 'I 4 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 4 3 2") == 0) {
    /* Spacegroup 'I 4 3 2' */
    printf(" Located RCSB data for spacegroup 'I 4 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"x,z,-y");
    AddSymopFromString(spgrp,"-x,z,y");
    AddSymopFromString(spgrp,"-x,-z,-y");
    AddSymopFromString(spgrp,"x,-z,y");
    AddSymopFromString(spgrp,"z,y,-x");
    AddSymopFromString(spgrp,"z,-y,x");
    AddSymopFromString(spgrp,"-z,y,x");
    AddSymopFromString(spgrp,"-z,-y,-x");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-x+1/2,y+1/2");
    AddSymopFromString(spgrp,"-z+1/2,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-z+1/2,x+1/2");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"x+1/2,z+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-x+1/2,z+1/2,y+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-z+1/2,-y+1/2");
    AddSymopFromString(spgrp,"x+1/2,-z+1/2,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,y+1/2,-x+1/2");
    AddSymopFromString(spgrp,"z+1/2,-y+1/2,x+1/2");
    AddSymopFromString(spgrp,"-z+1/2,y+1/2,x+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-y+1/2,-x+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 41") == 0) {
    /* Spacegroup 'I 41' */
    printf(" Located RCSB data for spacegroup 'I 41'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x+1/2,z+1/4");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x,z+3/4");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/1,z+3/4");
    AddSymopFromString(spgrp,"-x+1/1,-y+1/1,z+1/1");
    AddSymopFromString(spgrp,"y+1/1,-x+1/2,z+5/4");
    return spgrp;
  }
  if (strcmp(name,"I 41 2 2") == 0) {
    /* Spacegroup 'I 41 2 2' */
    printf(" Located RCSB data for spacegroup 'I 41 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y,x+1/2,z+1/4");
    AddSymopFromString(spgrp,"y+1/2,-x,z+3/4");
    AddSymopFromString(spgrp,"-x+1/2,y,-z+3/4");
    AddSymopFromString(spgrp,"x,-y+1/2,-z+1/4");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/1,-y+1/1,z+1/1");
    AddSymopFromString(spgrp,"-y+1/2,x+1/1,z+3/4");
    AddSymopFromString(spgrp,"y+1/1,-x+1/2,z+5/4");
    AddSymopFromString(spgrp,"-x+1/1,y+1/2,-z+5/4");
    AddSymopFromString(spgrp,"x+1/2,-y+1/1,-z+3/4");
    AddSymopFromString(spgrp,"y+1/1,x+1/1,-z+1/1");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"I 41 3 2") == 0) {
    /* Spacegroup 'I 41 3 2' */
    printf(" Located RCSB data for spacegroup 'I 41 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"y+3/4,x+1/4,-z+1/4");
    AddSymopFromString(spgrp,"-y+3/4,-x+3/4,-z+3/4");
    AddSymopFromString(spgrp,"y+1/4,-x+1/4,z+3/4");
    AddSymopFromString(spgrp,"-y+1/4,x+3/4,z+1/4");
    AddSymopFromString(spgrp,"x+3/4,z+1/4,-y+1/4");
    AddSymopFromString(spgrp,"-x+1/4,z+3/4,y+1/4");
    AddSymopFromString(spgrp,"-x+3/4,-z+3/4,-y+3/4");
    AddSymopFromString(spgrp,"x+1/4,-z+1/4,y+3/4");
    AddSymopFromString(spgrp,"z+3/4,y+1/4,-x+1/4");
    AddSymopFromString(spgrp,"z+1/4,-y+1/4,x+3/4");
    AddSymopFromString(spgrp,"-z+1/4,y+3/4,x+1/4");
    AddSymopFromString(spgrp,"-z+3/4,-y+3/4,-x+3/4");
    AddSymopFromString(spgrp,"x+1/2,y+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z+1/2");
    AddSymopFromString(spgrp,"z+1/2,x+1/2,y+1/2");
    AddSymopFromString(spgrp,"z,-x,-y+1/2");
    AddSymopFromString(spgrp,"-z,-x+1/2,y");
    AddSymopFromString(spgrp,"-z+1/2,x,-y");
    AddSymopFromString(spgrp,"y+1/2,z+1/2,x+1/2");
    AddSymopFromString(spgrp,"-y+1/2,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x+1/2");
    AddSymopFromString(spgrp,"-y,-z+1/2,x");
    AddSymopFromString(spgrp,"y+1/4,x+3/4,-z+3/4");
    AddSymopFromString(spgrp,"-y+1/4,-x+1/4,-z+1/4");
    AddSymopFromString(spgrp,"y+3/4,-x+3/4,z+1/4");
    AddSymopFromString(spgrp,"-y+3/4,x+1/4,z+3/4");
    AddSymopFromString(spgrp,"x+1/4,z+3/4,-y+3/4");
    AddSymopFromString(spgrp,"-x+3/4,z+1/4,y+3/4");
    AddSymopFromString(spgrp,"-x+1/4,-z+1/4,-y+1/4");
    AddSymopFromString(spgrp,"x+3/4,-z+3/4,y+1/4");
    AddSymopFromString(spgrp,"z+1/4,y+3/4,-x+3/4");
    AddSymopFromString(spgrp,"z+3/4,-y+3/4,x+1/4");
    AddSymopFromString(spgrp,"-z+3/4,y+1/4,x+3/4");
    AddSymopFromString(spgrp,"-z+1/4,-y+1/4,-x+1/4");
    return spgrp;
  }
  if (strcmp(name,"P 1") == 0) {
    /* Spacegroup 'P 1' */
    printf(" Located RCSB data for spacegroup 'P 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    return spgrp;
  }
  if (strcmp(name,"P 1-") == 0) {
    /* Spacegroup 'P 1-' */
    printf(" Located RCSB data for spacegroup 'P 1-'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 2") == 0) {
    /* Spacegroup 'P 2' */
    printf(" Located RCSB data for spacegroup 'P 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 1 2 1") == 0) {
    /* Spacegroup 'P 1 2 1' */
    printf(" Located RCSB data for spacegroup 'P 1 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 1 1 2") == 0) {
    /* Spacegroup 'P 1 1 2' */
    printf(" Located RCSB data for spacegroup 'P 1 1 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    return spgrp;
  }
  if (strcmp(name,"P 2 2 2") == 0) {
    /* Spacegroup 'P 2 2 2' */
    printf(" Located RCSB data for spacegroup 'P 2 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 2 3") == 0) {
    /* Spacegroup 'P 2 3' */
    printf(" Located RCSB data for spacegroup 'P 2 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    return spgrp;
  }
  if (strcmp(name,"P 2 2 21") == 0) {
    /* Spacegroup 'P 2 2 21' */
    printf(" Located RCSB data for spacegroup 'P 2 2 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y,-z+1/2");
    AddSymopFromString(spgrp,"x,-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 2 21 21") == 0) {
    /* Spacegroup 'P 2 21 21' */
    printf(" Located RCSB data for spacegroup 'P 2 21 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-x,-y+1/2,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 21") == 0) {
    /* Spacegroup 'P 21' */
    printf(" Located RCSB data for spacegroup 'P 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"P 1 21 1") == 0) {
    /* Spacegroup 'P 1 21 1' */
    printf(" Located RCSB data for spacegroup 'P 1 21 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"P 1 1 21") == 0) {
    /* Spacegroup 'P 1 1 21' */
    printf(" Located RCSB data for spacegroup 'P 1 1 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 21(C)") == 0) {
    /* Spacegroup 'P 21(C)' */
    printf(" Located RCSB data for spacegroup 'P 21(C)'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 21 2 21") == 0) {
    /* Spacegroup 'P 21 2 21' */
    printf(" Located RCSB data for spacegroup 'P 21 2 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 21 3") == 0) {
    /* Spacegroup 'P 21 3' */
    printf(" Located RCSB data for spacegroup 'P 21 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 21 21 2") == 0) {
    /* Spacegroup 'P 21 21 2' */
    printf(" Located RCSB data for spacegroup 'P 21 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"P 21 21 2 A") == 0) {
    /* Spacegroup 'P 21 21 2 A' */
    printf(" Located RCSB data for spacegroup 'P 21 21 2 A'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y+1/2,z");
    AddSymopFromString(spgrp,"-x,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 21 21 21") == 0) {
    /* Spacegroup 'P 21 21 21' */
    printf(" Located RCSB data for spacegroup 'P 21 21 21'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    return spgrp;
  }
  if (strcmp(name,"P 3") == 0) {
    /* Spacegroup 'P 3' */
    printf(" Located RCSB data for spacegroup 'P 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    return spgrp;
  }
  if (strcmp(name,"P 3 1 2") == 0) {
    /* Spacegroup 'P 3 1 2' */
    printf(" Located RCSB data for spacegroup 'P 3 1 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"-x+y,y,-z");
    AddSymopFromString(spgrp,"x,x-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 3 2 1") == 0) {
    /* Spacegroup 'P 3 2 1' */
    printf(" Located RCSB data for spacegroup 'P 3 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 31") == 0) {
    /* Spacegroup 'P 31' */
    printf(" Located RCSB data for spacegroup 'P 31'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    return spgrp;
  }
  if (strcmp(name,"P 31 1 2") == 0) {
    /* Spacegroup 'P 31 1 2' */
    printf(" Located RCSB data for spacegroup 'P 31 1 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    AddSymopFromString(spgrp,"-y,-x,-z+2/3");
    AddSymopFromString(spgrp,"-x+y,y,-z+1/3");
    AddSymopFromString(spgrp,"x,x-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 31 2 1") == 0) {
    /* Spacegroup 'P 31 2 1' */
    printf(" Located RCSB data for spacegroup 'P 31 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"x-y,-y,-z+2/3");
    AddSymopFromString(spgrp,"-x,-x+y,-z+1/3");
    return spgrp;
  }
  if (strcmp(name,"P 32") == 0) {
    /* Spacegroup 'P 32' */
    printf(" Located RCSB data for spacegroup 'P 32'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    return spgrp;
  }
  if (strcmp(name,"P 32 1 2") == 0) {
    /* Spacegroup 'P 32 1 2' */
    printf(" Located RCSB data for spacegroup 'P 32 1 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    AddSymopFromString(spgrp,"-y,-x,-z+1/3");
    AddSymopFromString(spgrp,"-x+y,y,-z+2/3");
    AddSymopFromString(spgrp,"x,x-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 32 2 1") == 0) {
    /* Spacegroup 'P 32 2 1' */
    printf(" Located RCSB data for spacegroup 'P 32 2 1'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"x-y,-y,-z+1/3");
    AddSymopFromString(spgrp,"-x,-x+y,-z+2/3");
    return spgrp;
  }
  if (strcmp(name,"P 4") == 0) {
    /* Spacegroup 'P 4' */
    printf(" Located RCSB data for spacegroup 'P 4'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    return spgrp;
  }
  if (strcmp(name,"P 4 2 2") == 0) {
    /* Spacegroup 'P 4 2 2' */
    printf(" Located RCSB data for spacegroup 'P 4 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    return spgrp;
  }
  if (strcmp(name,"P 4 3 2") == 0) {
    /* Spacegroup 'P 4 3 2' */
    printf(" Located RCSB data for spacegroup 'P 4 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"y,-x,z");
    AddSymopFromString(spgrp,"-y,x,z");
    AddSymopFromString(spgrp,"x,z,-y");
    AddSymopFromString(spgrp,"-x,z,y");
    AddSymopFromString(spgrp,"-x,-z,-y");
    AddSymopFromString(spgrp,"x,-z,y");
    AddSymopFromString(spgrp,"z,y,-x");
    AddSymopFromString(spgrp,"z,-y,x");
    AddSymopFromString(spgrp,"-z,y,x");
    AddSymopFromString(spgrp,"-z,-y,-x");
    return spgrp;
  }
  if (strcmp(name,"P 4 21 2") == 0) {
    /* Spacegroup 'P 4 21 2' */
    printf(" Located RCSB data for spacegroup 'P 4 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    return spgrp;
  }
  if (strcmp(name,"P 41") == 0) {
    /* Spacegroup 'P 41' */
    printf(" Located RCSB data for spacegroup 'P 41'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-y,x,z+1/4");
    AddSymopFromString(spgrp,"y,-x,z+3/4");
    return spgrp;
  }
  if (strcmp(name,"P 41 2 2") == 0) {
    /* Spacegroup 'P 41 2 2' */
    printf(" Located RCSB data for spacegroup 'P 41 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-y,x,z+1/4");
    AddSymopFromString(spgrp,"y,-x,z+3/4");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z+1/2");
    AddSymopFromString(spgrp,"y,x,-z+3/4");
    AddSymopFromString(spgrp,"-y,-x,-z+1/4");
    return spgrp;
  }
  if (strcmp(name,"P 41 3 2") == 0) {
    /* Spacegroup 'P 41 3 2' */
    printf(" Located RCSB data for spacegroup 'P 41 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"y+3/4,x+1/4,-z+1/4");
    AddSymopFromString(spgrp,"-y+3/4,-x+3/4,-z+3/4");
    AddSymopFromString(spgrp,"y+1/4,-x+1/4,z+3/4");
    AddSymopFromString(spgrp,"-y+1/4,x+3/4,z+1/4");
    AddSymopFromString(spgrp,"x+3/4,z+1/4,-y+1/4");
    AddSymopFromString(spgrp,"-x+1/4,z+3/4,y+1/4");
    AddSymopFromString(spgrp,"-x+3/4,-z+3/4,-y+3/4");
    AddSymopFromString(spgrp,"x+1/4,-z+1/4,y+3/4");
    AddSymopFromString(spgrp,"z+3/4,y+1/4,-x+1/4");
    AddSymopFromString(spgrp,"z+1/4,-y+1/4,x+3/4");
    AddSymopFromString(spgrp,"-z+1/4,y+3/4,x+1/4");
    AddSymopFromString(spgrp,"-z+3/4,-y+3/4,-x+3/4");
    return spgrp;
  }
  if (strcmp(name,"P 41 21 2") == 0) {
    /* Spacegroup 'P 41 21 2' */
    printf(" Located RCSB data for spacegroup 'P 41 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+1/4");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+3/4");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/4");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+3/4");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 42") == 0) {
    /* Spacegroup 'P 42' */
    printf(" Located RCSB data for spacegroup 'P 42'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z+1/2");
    AddSymopFromString(spgrp,"y,-x,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 42 2 2") == 0) {
    /* Spacegroup 'P 42 2 2' */
    printf(" Located RCSB data for spacegroup 'P 42 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y,x,z+1/2");
    AddSymopFromString(spgrp,"y,-x,z+1/2");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"y,x,-z+1/2");
    AddSymopFromString(spgrp,"-y,-x,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 42 3 2") == 0) {
    /* Spacegroup 'P 42 3 2' */
    printf(" Located RCSB data for spacegroup 'P 42 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z,-x,-y");
    AddSymopFromString(spgrp,"-z,-x,y");
    AddSymopFromString(spgrp,"-z,x,-y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z,-x");
    AddSymopFromString(spgrp,"y,-z,-x");
    AddSymopFromString(spgrp,"-y,-z,x");
    AddSymopFromString(spgrp,"y+1/2,x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,-x+1/2,-z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"x+1/2,z+1/2,-y+1/2");
    AddSymopFromString(spgrp,"-x+1/2,z+1/2,y+1/2");
    AddSymopFromString(spgrp,"-x+1/2,-z+1/2,-y+1/2");
    AddSymopFromString(spgrp,"x+1/2,-z+1/2,y+1/2");
    AddSymopFromString(spgrp,"z+1/2,y+1/2,-x+1/2");
    AddSymopFromString(spgrp,"z+1/2,-y+1/2,x+1/2");
    AddSymopFromString(spgrp,"-z+1/2,y+1/2,x+1/2");
    AddSymopFromString(spgrp,"-z+1/2,-y+1/2,-x+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 42 21 2") == 0) {
    /* Spacegroup 'P 42 21 2' */
    printf(" Located RCSB data for spacegroup 'P 42 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+1/2");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+1/2");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    return spgrp;
  }
  if (strcmp(name,"P 43") == 0) {
    /* Spacegroup 'P 43' */
    printf(" Located RCSB data for spacegroup 'P 43'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-y,x,z+3/4");
    AddSymopFromString(spgrp,"y,-x,z+1/4");
    return spgrp;
  }
  if (strcmp(name,"P 43 2 2") == 0) {
    /* Spacegroup 'P 43 2 2' */
    printf(" Located RCSB data for spacegroup 'P 43 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-y,x,z+3/4");
    AddSymopFromString(spgrp,"y,-x,z+1/4");
    AddSymopFromString(spgrp,"-x,y,-z");
    AddSymopFromString(spgrp,"x,-y,-z+1/2");
    AddSymopFromString(spgrp,"y,x,-z+1/4");
    AddSymopFromString(spgrp,"-y,-x,-z+3/4");
    return spgrp;
  }
  if (strcmp(name,"P 43 3 2") == 0) {
    /* Spacegroup 'P 43 3 2' */
    printf(" Located RCSB data for spacegroup 'P 43 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x+1/2,-y,z+1/2");
    AddSymopFromString(spgrp,"-x,y+1/2,-z+1/2");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"z+1/2,-x+1/2,-y");
    AddSymopFromString(spgrp,"-z+1/2,-x,y+1/2");
    AddSymopFromString(spgrp,"-z,x+1/2,-y+1/2");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,z+1/2,-x+1/2");
    AddSymopFromString(spgrp,"y+1/2,-z+1/2,-x");
    AddSymopFromString(spgrp,"-y+1/2,-z,x+1/2");
    AddSymopFromString(spgrp,"y+1/4,x+3/4,-z+3/4");
    AddSymopFromString(spgrp,"-y+1/4,-x+1/4,-z+1/4");
    AddSymopFromString(spgrp,"y+3/4,-x+3/4,z+1/4");
    AddSymopFromString(spgrp,"-y+3/4,x+1/4,z+3/4");
    AddSymopFromString(spgrp,"x+1/4,z+3/4,-y+3/4");
    AddSymopFromString(spgrp,"-x+3/4,z+1/4,y+3/4");
    AddSymopFromString(spgrp,"-x+1/4,-z+1/4,-y+1/4");
    AddSymopFromString(spgrp,"x+3/4,-z+3/4,y+1/4");
    AddSymopFromString(spgrp,"z+1/4,y+3/4,-x+3/4");
    AddSymopFromString(spgrp,"z+3/4,-y+3/4,x+1/4");
    AddSymopFromString(spgrp,"-z+3/4,y+1/4,x+3/4");
    AddSymopFromString(spgrp,"-z+1/4,-y+1/4,-x+1/4");
    return spgrp;
  }
  if (strcmp(name,"P 43 21 2") == 0) {
    /* Spacegroup 'P 43 21 2' */
    printf(" Located RCSB data for spacegroup 'P 43 21 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-y+1/2,x+1/2,z+3/4");
    AddSymopFromString(spgrp,"y+1/2,-x+1/2,z+1/4");
    AddSymopFromString(spgrp,"-x+1/2,y+1/2,-z+3/4");
    AddSymopFromString(spgrp,"x+1/2,-y+1/2,-z+1/4");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"-y,-x,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 6") == 0) {
    /* Spacegroup 'P 6' */
    printf(" Located RCSB data for spacegroup 'P 6'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"y,-x+y,z");
    AddSymopFromString(spgrp,"x-y,x,z");
    return spgrp;
  }
  if (strcmp(name,"P 6 2 2") == 0) {
    /* Spacegroup 'P 6 2 2' */
    printf(" Located RCSB data for spacegroup 'P 6 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"y,-x+y,z");
    AddSymopFromString(spgrp,"x-y,x,z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"-x+y,y,-z");
    AddSymopFromString(spgrp,"x,x-y,-z");
    return spgrp;
  }
  if (strcmp(name,"P 61") == 0) {
    /* Spacegroup 'P 61' */
    printf(" Located RCSB data for spacegroup 'P 61'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"y,-x+y,z+5/6");
    AddSymopFromString(spgrp,"x-y,x,z+1/6");
    return spgrp;
  }
  if (strcmp(name,"P 61 2 2") == 0) {
    /* Spacegroup 'P 61 2 2' */
    printf(" Located RCSB data for spacegroup 'P 61 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"y,-x+y,z+5/6");
    AddSymopFromString(spgrp,"x-y,x,z+1/6");
    AddSymopFromString(spgrp,"y,x,-z+1/3");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z+2/3");
    AddSymopFromString(spgrp,"-y,-x,-z+5/6");
    AddSymopFromString(spgrp,"-x+y,y,-z+1/2");
    AddSymopFromString(spgrp,"x,x-y,-z+1/6");
    return spgrp;
  }
  if (strcmp(name,"P 62") == 0) {
    /* Spacegroup 'P 62' */
    printf(" Located RCSB data for spacegroup 'P 62'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"y,-x+y,z+2/3");
    AddSymopFromString(spgrp,"x-y,x,z+1/3");
    return spgrp;
  }
  if (strcmp(name,"P 62 2 2") == 0) {
    /* Spacegroup 'P 62 2 2' */
    printf(" Located RCSB data for spacegroup 'P 62 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"y,-x+y,z+2/3");
    AddSymopFromString(spgrp,"x-y,x,z+1/3");
    AddSymopFromString(spgrp,"y,x,-z+2/3");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z+1/3");
    AddSymopFromString(spgrp,"-y,-x,-z+2/3");
    AddSymopFromString(spgrp,"-x+y,y,-z");
    AddSymopFromString(spgrp,"x,x-y,-z+1/3");
    return spgrp;
  }
  if (strcmp(name,"P 63") == 0) {
    /* Spacegroup 'P 63' */
    printf(" Located RCSB data for spacegroup 'P 63'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"y,-x+y,z+1/2");
    AddSymopFromString(spgrp,"x-y,x,z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 63 2 2") == 0) {
    /* Spacegroup 'P 63 2 2' */
    printf(" Located RCSB data for spacegroup 'P 63 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"x-y,x,z+1/2");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"y,-x+y,z+1/2");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-y,-x,-z+1/2");
    AddSymopFromString(spgrp,"-x,-x+y,-z");
    AddSymopFromString(spgrp,"-x+y,y,-z+1/2");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"x,x-y,-z+1/2");
    return spgrp;
  }
  if (strcmp(name,"P 64") == 0) {
    /* Spacegroup 'P 64' */
    printf(" Located RCSB data for spacegroup 'P 64'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"y,-x+y,z+1/3");
    AddSymopFromString(spgrp,"x-y,x,z+2/3");
    return spgrp;
  }
  if (strcmp(name,"P 64 2 2") == 0) {
    /* Spacegroup 'P 64 2 2' */
    printf(" Located RCSB data for spacegroup 'P 64 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+1/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+2/3");
    AddSymopFromString(spgrp,"-x,-y,z");
    AddSymopFromString(spgrp,"y,-x+y,z+1/3");
    AddSymopFromString(spgrp,"x-y,x,z+2/3");
    AddSymopFromString(spgrp,"y,x,-z+1/3");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z+2/3");
    AddSymopFromString(spgrp,"-y,-x,-z+1/3");
    AddSymopFromString(spgrp,"-x+y,y,-z");
    AddSymopFromString(spgrp,"x,x-y,-z+2/3");
    return spgrp;
  }
  if (strcmp(name,"P 65") == 0) {
    /* Spacegroup 'P 65' */
    printf(" Located RCSB data for spacegroup 'P 65'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"x-y,x,z+5/6");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    AddSymopFromString(spgrp,"y,-x+y,z+1/6");
    return spgrp;
  }
  if (strcmp(name,"P 65 2 2") == 0) {
    /* Spacegroup 'P 65 2 2' */
    printf(" Located RCSB data for spacegroup 'P 65 2 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z+2/3");
    AddSymopFromString(spgrp,"-x+y,-x,z+1/3");
    AddSymopFromString(spgrp,"-x,-y,z+1/2");
    AddSymopFromString(spgrp,"y,-x+y,z+1/6");
    AddSymopFromString(spgrp,"x-y,x,z+5/6");
    AddSymopFromString(spgrp,"y,x,-z+2/3");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z+1/3");
    AddSymopFromString(spgrp,"-y,-x,-z+1/6");
    AddSymopFromString(spgrp,"-x+y,y,-z+1/2");
    AddSymopFromString(spgrp,"x,x-y,-z+5/6");
    return spgrp;
  }
  if (strcmp(name,"H 3") == 0) {
    /* Spacegroup 'H 3' */
    printf(" Located RCSB data for spacegroup 'H 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"x+2/3,y+1/3,z+1/3");
    AddSymopFromString(spgrp,"-y+2/3,x-y+1/3,z+1/3");
    AddSymopFromString(spgrp,"-x+y+2/3,-x+1/3,z+1/3");
    AddSymopFromString(spgrp,"x+1/3,y+2/3,z+2/3");
    AddSymopFromString(spgrp,"-y+1/3,x-y+2/3,z+2/3");
    AddSymopFromString(spgrp,"-x+y+1/3,-x+2/3,z+2/3");
    return spgrp;
  }
  if (strcmp(name,"R 3") == 0) {
    /* Spacegroup 'R 3' */
    printf(" Located RCSB data for spacegroup 'R 3'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"y,z,x");
    return spgrp;
  }
  if (strcmp(name,"H 3 2") == 0) {
    /* Spacegroup 'H 3 2' */
    printf(" Located RCSB data for spacegroup 'H 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"-y,x-y,z");
    AddSymopFromString(spgrp,"-x+y,-x,z");
    AddSymopFromString(spgrp,"y,x,-z");
    AddSymopFromString(spgrp,"x-y,-y,-z");
    AddSymopFromString(spgrp,"-x,-x+y,-z");
    AddSymopFromString(spgrp,"x+2/3,y+1/3,z+1/3");
    AddSymopFromString(spgrp,"-y+2/3,x-y+1/3,z+1/3");
    AddSymopFromString(spgrp,"-x+y+2/3,-x+1/3,z+1/3");
    AddSymopFromString(spgrp,"y+2/3,x+1/3,-z+1/3");
    AddSymopFromString(spgrp,"x-y+2/3,-y+1/3,-z+1/3");
    AddSymopFromString(spgrp,"-x+2/3,-x+y+1/3,-z+1/3");
    AddSymopFromString(spgrp,"x+1/3,y+2/3,z+2/3");
    AddSymopFromString(spgrp,"-y+1/3,x-y+2/3,z+2/3");
    AddSymopFromString(spgrp,"-x+y+1/3,-x+2/3,z+2/3");
    AddSymopFromString(spgrp,"y+1/3,x+2/3,-z+2/3");
    AddSymopFromString(spgrp,"x-y+1/3,-y+2/3,-z+2/3");
    AddSymopFromString(spgrp,"-x+1/3,-x+y+2/3,-z+2/3");
    return spgrp;
  }
  if (strcmp(name,"R 3 2") == 0) {
    /* Spacegroup 'R 3 2' */
    printf(" Located RCSB data for spacegroup 'R 3 2'\n\n");
    spgrp = ccp4spg_new();
    strncpy(spgrp->symbol_xHM,name,20);
    /* Populate the symmetry operator data */
    AddSymopFromString(spgrp,"x,y,z");
    AddSymopFromString(spgrp,"z,x,y");
    AddSymopFromString(spgrp,"y,z,x");
    AddSymopFromString(spgrp,"-y,-x,-z");
    AddSymopFromString(spgrp,"-x,-z,-y");
    AddSymopFromString(spgrp,"-z,-y,-x");
    return spgrp;
  }
  /* Spacegroup not found */
  return NULL;
}

