/*
  symconv_lib.c

  Library-like functions for dealing with symmetry representations
  etc used in the symconv program.

  CVS ID: $Id$
*/

#include "symconv_lib.h"
#include "symconv_utils.h"

/* Return a new (empty) CCP4SPG struct
   Free the memory using ccp4spg_free when finished */
CCP4SPG *ccp4spg_new() {
  CCP4SPG *ccp4_spg;
  ccp4_spg = (CCP4SPG *) ccp4_utils_malloc(sizeof(CCP4SPG));
  ccp4_spg->nsymop = 0;
  ccp4_spg->symop = NULL;
  ccp4_spg->invsymop = NULL;
  return ccp4_spg;
}

/* Add a symmetry operation to a CCP4SPG struct
   given the symop in string format */
int AddSymopFromString(CCP4SPG *ccp4_spg, char *symop) {
  /* Declarations*/
  int i,j,k;
  float rsym[4][4];
  /* Get the matrix representation of the
     operation from the string */
  if (GetMatrixFromSymop(symop,rsym)) {
    /* Current symop number */
    k = ccp4_spg->nsymop;
    /* Make a new symop */
    ccp4_spg->symop = (ccp4_symop *)
      ccp4_utils_realloc(ccp4_spg->symop,(k+1)*sizeof(ccp4_symop));
    /* Transfer rotational part */
    for (i=0; i<3; i++)
      for (j=0; j<3; j++)
	ccp4_spg->symop[k].rot[i][j] = rsym[i][j];
    /* Transfer translational part */ 
    for (i=0; i<3; i++)
      ccp4_spg->symop[k].trn[i] = rsym[i][3];
  }
  /* Increment number of symmetry operations and return */
  ccp4_spg->nsymop = ++k;
  return ccp4_spg->nsymop;
}

/* Return number of symops */
int GetNSymops(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->nsymop;
  else
    return 0;
}

/* Return number of primitive symops */
int GetNPrimitiveSymops(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->nsymop_prim;
  else
    return 0;
}

/* Get extended Hermann-Mauguin symbol for spacegroup */
char *GetxHMSymbol(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->symbol_xHM;
  else
    return NULL;
}

/* Get standard spacegroup number */
int GetSpgrpNumber(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->spg_num;
  else
    return 0;
}

/* Get CCP4 spacegroup number */
int GetCCP4SpgrpNumber(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->spg_ccp4_num;
  else
    return 0;
}

/* Get Laue class number */
int GetLaueClassNumber(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->nlaue;
  else
    return 0;
}

/* Get Laue class name */
char *GetLaueClassName(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->laue_name;
  else
    return 0;
}

/* Get Patterson spacegroup number */
int GetPattersonNumber(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->npatt;
  else
    return 0;
}

/* Get Patterson spacegroup name */
char *GetPattersonName(CCP4SPG *ccp4_spg) {
  if (ccp4_spg)
    return ccp4_spg->patt_name;
  else
    return 0;
}

/* Return symmetry matrix (4x4) */
int GetRsymMatrix(CCP4SPG *ccp4_spg, int i, float rsym[4][4]) {
  int j,k;
  for ( j=0 ; j < 3 ; j++ ) {
    for ( k=0 ; k < 3; k++ ) {
      rsym[j][k] = ccp4_spg->symop[i].rot[j][k];
    }
    rsym[3][j] = ccp4_spg->symop[i].trn[j];
    rsym[j][3] = ccp4_spg->symop[i].trn[j];
  }
  rsym[3][3] = 1.0;
  return 1;
}

/* Return symop string from symmetry matrix */
/* Ripped off from mat4_to_symop in ccp4_parser.c */   
int GetSymopString(float rsm[4][4], char *symop, int n)
{
  static char axiscr[] = {'X','Y','Z'};
  static char numb[] = {'0','1','2','3','4','5','6','7','8','9'};
  static int npntr1[12] = { 0,1,1,1,0,1,0,2,3,5,0,0 };
  static int npntr2[12] = { 0,6,4,3,0,2,0,3,4,6,0,0 };

  int jdo10, jdo20, irsm, itr, ist, ichar;
  int debug=0;
  char symbuf[1000];

  /* Check inputs */
  if (!symop || n<1) return 0;

  if (debug) 
    for (jdo20 = 0; jdo20 < 4; ++jdo20) 
      printf("Input matrix: %f %f %f %f \n",rsm[jdo20][0],rsm[jdo20][1],
          rsm[jdo20][2],rsm[jdo20][3]);
  

  /* Initialised */
  memset(symbuf,' ',1000U);
  symbuf[0]='\0';
  ichar = 0;

  /* Loop over the three "components" of the symop x,y,z */
  for (jdo20 = 0; jdo20 < 3; ++jdo20) {
    symbuf[ichar] = '0';

    ist = 0;    /* ---- Ist is flag for first character of operator */
    for (jdo10 = 0; jdo10 < 4; ++jdo10) {
      
      if (rsm[jdo20][jdo10] != 0.f) {
	irsm = (int) rint(fabs(rsm[jdo20][jdo10]));
	
	if ( rsm[jdo20][jdo10] > 0. && ist) {
	  if (ichar >= n) {
	    return 0;
	  }
	  symbuf[ichar++] = '+';
	} else if ( rsm[jdo20][jdo10] < 0.f ) {
	  if (ichar >= n) {
	    return 0;
	  }
	  if (jdo10 < 3) {
	    symbuf[ichar++] = '-';
	  } else {
	    /* translation part is forced to be positive, see below */
	    symbuf[ichar++] = '+';
	  }
          ist = 1;
	}
      
	if (jdo10 < 3) {
	  /* rotation part */
	  if (ichar+1 >= n) {
	    return 0;
	  }
	  if (irsm != 1) {
	    symbuf[ichar++] = numb[irsm];
	    symbuf[ichar++] = axiscr[jdo10];
	  } else {
	    symbuf[ichar++] = axiscr[jdo10];
	  }
	  ist = 1;
        } else {
	  /* translation part */
	  itr = (int) rint(rsm[jdo20][3]*12.0);
          while (itr < 0) itr += 12;
          itr = (itr - 1) % 12;
          if (npntr1[itr] > 0) {
	   if (ichar+2 >= n) {
	    return -1;
	   }
	   symbuf[ichar++] = numb[npntr1[itr]];
	   symbuf[ichar++] = '/';
           symbuf[ichar++] = numb[npntr2[itr]];
	  } else {
           symbuf[--ichar] = ' ';
	  }
	}
      }
    }
    if (jdo20 != 2) {
      if (symbuf[ichar] == '0')
        ++ichar;
      if (ichar+2 >= n) {
        return -1;
      }
      symbuf[ichar++] = ',';
      symbuf[ichar++] = ' ';
      symbuf[ichar++] = ' ';
    }
  }
  symbuf[ichar]='\0';
  
  /* Copy the buffered string to the output string */
  strncpy(symop,symbuf,n);
  return ichar;
}

/* Return symop string from symmetry matrix in lowercase format
   (also strips spaces).
   Wrapper for GetSymopString which returns e.g. 'X+1/2,  Y+1/2,  -Z+1/2'
   Lowercase format would be 'x+1/2,y+1/2,-z+1/2'

   Should also work for reciprocal space symops
*/  
int GetLCSymopString(float rsym[4][4], char *symop, int n) {
  int i,j;
  char c,symch_upper[120],symch_lower[120];
  /* Get CCP4 format symop */
  GetSymopString(rsym,symch_upper,120);
  /* Convert to lowercase format
     Also remove spaces */
  j = 0;
  for (i=0; i<strlen(symch_upper); i++) {
    c = tolower(symch_upper[i]);
    if (c != ' ') {
      symch_lower[j] = c;
      j++;
    }
  }
  /* End of the string */
  symch_lower[j] = '\0';
  /* Copy the temporary string to the final result */
  strncpy(symop,symch_lower,n);
  return 1;
}

/* Return symop string for reciprocal space operator from symmetry matrix
   Wrapper for GetSymopString which returns e.g. 'X+1/2,  Y+1/2,  -Z+1/2'
   Reciprocal space format would be 'h+1/2,k+1/2,-l+1/2'
*/
int GetRecipSymopString(float rsym[4][4], char *symop, int n) {
  int i,j;
  char c,symch_ccp4[1000],symch_recip[1000];

  /* Get the "X,Y,Z" format symop */
  GetSymopString(rsym,symch_ccp4,n);

  j = 0;

  for (i=0; i<strlen(symch_ccp4); i++) {
    c = symch_ccp4[j];
    if (c == 'X') {
      if (j == 0 || (j > 0 && symch_recip[j-1] != '-' && symch_recip[j-1] != '+')) {
	symch_recip[j++] = '+';
      }
      symch_recip[j++] = 'h';
    } else if (c == 'Y') {
      if (j == 0 || (j > 0 && symch_recip[j-1] != '-' && symch_recip[j-1] != '+')) {
	symch_recip[j++] = '+';
      }
      symch_recip[j++] = 'k';
    } else if (c == 'Z') {
      if (j == 0 || (j > 0 && symch_recip[j-1] != '-' && symch_recip[j-1] != '+')) {
	symch_recip[j++] = '+';
      }
      symch_recip[j++] = 'l'; 
    } else if (c == ' ') {
      /* Skip spaces */
    } else {
      symch_recip[j++] = c;
    }
  }
  /* End of the string */
  symch_recip[j] = '\0';
  /* Copy the temporary string to the final result */
  strncpy(symop,symch_recip,n);
  return 1;
}

/* IsRecipSymop

   Return 1 if the supplied symop string is reciprocal space
   operator, 0 if not.
*/
int IsRecipSymop(char *symop) {
  int i,j,k;
  char recip_chars[]="hHkKlL ,-+";
  for (i=0; i<strlen(symop); i++) {
    k = 0;
    for (j=0; j<strlen(recip_chars); j++) {
      if (symop[i] == recip_chars[j]) {
	k = 1;
	break;
      }
    }
    if (!k) {
      return 0;
    }
  }
  return 1;
}

/* GetMatrixFromSymop

   Translates a single symmetry operator string into a 4x4 quine
   matrix representation

   Syntax of possible symop strings:

   real space symmetry operations, e.g. X+1/2,Y-X,Z
   reciprocal space operations,    e.g. h,l-h,-k
   reciprocal axis vectors,        e.g. a*+c*,c*,-b*
   real space axis vectors,        e.g. a,c-a,-b

   The strings can contain spaces, and the coordinate and translation
   parts may be in either order.

   The function returns 1 on success, 0 if there was a failure to
   generate a matrix representation.
*/
int GetMatrixFromSymop(char *symop, float rsym[4][4])
{
  int no_real =0, no_recip = 0, no_axis = 0;          /* counters */
  int col = 3, nops = 0;
  float sign = 1.0f, value = 0.0f, value2;
  char *cp, ch;
  int i,j,k;                                 /* loop variables */
  int Isep = 0;                             /* parsed seperator? */

  /* initialise the relevant array */
  for (j = 0 ; j < 4 ; ++j)
    for (k = 0; k < 4 ; ++k)
      rsym[j][k] = 0.0f;
  rsym[3][3] = 1.0f;

  i = 0;
  while (i<strlen(symop)) {
    ch = tolower(symop[i]);

    /* Parse symop */
    if (isspace(ch)) {
      /* Have to allow symop strings to contain spaces for
	 compatibility with older MTZ files
	 Ignore and step on to next character */
      ++i;
      continue;
    } else if (ch == ',' || ch == '*') {           
      ++i;
      if (value == 0.0f && col == 3) {
        /* nothing set, this is a problem */
        return 0;
      } else {
        Isep = 1;     /* drop through to evaluation*/
      }
    } else if (ch == 'x') {
      no_real++, col = 0;
      if (value == 0.0f) value = sign * 1.0f;
      ++i;
      continue;
    } else if (ch == 'y') {
      no_real++, col = 1;
      if (value == 0.0f) value = sign * 1.0f;
      ++i;
      continue;
    } else if (ch == 'z') {
      no_real++, col = 2;
      if (value == 0.0f) value = sign * 1.0f;
      ++i;
      continue;
    } else if (ch == 'h') {
      no_recip++, col = 0;
      if (value == 0.0f) value = sign * 1.0f;
      ++i;
      continue;
    } else if (ch == 'k') {
      no_recip++, col = 1;
      if (value == 0.0f) value = sign * 1.0f;
      ++i;
      continue;
    } else if (ch == 'l') {
      no_recip++, col = 2;
      if (value == 0.0f) value = sign * 1.0f;
      ++i;
      continue;
    } else if (ch == 'a') {
      no_axis++, col = 0;
      if (value == 0.0f) value = sign * 1.0f;
      if (symop[++i] == '*' && ( no_axis != 3 || no_recip )) ++i;
      continue;
    } else if (ch == 'b') {
      no_axis++, col = 1;
      if (value == 0.0f) value = sign * 1.0f;
      if (symop[++i] == '*' && ( no_axis != 3 || no_recip )) ++i;
      continue;
    } else if (ch == 'c') {
      no_axis++, col = 2;
      if (value == 0.0f) value = sign * 1.0f;
      if (symop[++i] == '*' && ( no_axis != 3 || no_recip )) ++i;
      continue;
    } else if (ch == '+' || ch == '-') {
      sign = ((ch == '+')? 1.0f : -1.0f) ;
      ++i;
      if (value == 0.0f && col == 3) 
	continue;
      /* drop through to evaluation */
    } else if ( ch == '/') {
      ++i;
      if (value == 0.0f) {
	/* error */
	return 0;
      }
      value2 = strtod(&symop[i], &cp);
      if (!value2) {
	/* error */
	return 0;
      }
      /* Nb don't apply the sign to value here
	 It will already have been applied in the previous round */
      value = (float) value/value2;
      i = cp - &symop[0];
      continue;
    } else if ( isdigit(ch) || ch == '.') {
      value = sign*strtod(&symop[i], &cp);
      i = cp - &symop[0];
      continue;
    } else {
      ++i;
      continue;
    }
 
    /* value to be entered in rsym */
    rsym[nops][col] = rsym[nops][col] + value;
  
    /* have we passed a operator seperator */
    if (Isep) {
      Isep = 0;
      ++nops;
      sign = 1.0f;
      if (nops == 3) {
	/* More than 3 elements encountered */
	return 0;
      }
    }
  
    /* reset for next cycle */
    col = 3;
    value = 0.0f;
    no_recip = 0, no_axis = 0, no_real = 0;
  }
  
  /* Tidy up last value */
  if (value) rsym[nops][col] = rsym[nops][col]+value;
  
  if (nops<2) {
    /* Processed fewer than 3 operators, raise an error */
    return 0;
  }
  /* Return with success */
  return 1;
}


/* Determine whether the elements of two 4x4 symmetry matrices are
   identical within the specified tolerance.
   Return 1 if they are the same, and 0 if there is a difference.
*/
int SymMatricesAreEquiv(float m1[4][4], float m2[4][4], float tol) {
  int i,j,diag=0;
  if (diag) {
    print_float_matrix4("Matrix m1",m1);
    print_float_matrix4("Matrix m2",m2);
  }
  for (i=0; i<3; i++)
    for (j=0; j<4; j++)
      if (fabs(m1[i][j]-m2[i][j])>tol) {
	/* Element doesn't match within specified tolerance */
	if (diag)
	  printf("Match failed for %d %d: %f %f\n",i,j,m1[i][j],m2[i][j]);
	return 0;
      }
  /* Appears to match */
  return 1;
}


/* Given a 4x4 symmetry matrix and a CCP4 spacegroup
   object, look up the operator in the spacegroup

   Return the symmetry operation in string form
   (symop) plus the operator number (i.e. position
   in the list of operators), sym.id string (symid)
   consisting of operator number and a translation
   identifier, plus any unit cell translations that
   have been applied (as a 3-vector) to produce
   the supplied symmetry operator from the standard
   one.
   
   Returns the operator number, or zero if the symmetry
   operation is not found in the spacegroup.
*/
int LookupSymMatInSpgrp(CCP4SPG *spgrp, float rsym[4][4],
			char *symop, int *number, char *symid,
			int *itrn, float trn[3]) {
  int nsym,i,j,nop,itrans,diag=0;
  float rsymi[4][4],t[3];
  char symch[80];
  if (diag) printf("Starting LookupSymMatInSpgrp\n");
  nsym = GetNSymops(spgrp);
  if (nsym < 1) {
    return 0;
  }
  if (diag) print_float_matrix4("Input matrix",rsym);
  /* Make a copy of the original matrix */
  for (i=0; i<4; i++)
    for (j=0; j<4; j++)
      rsymi[i][j] = rsym[i][j];
  if (diag) print_float_matrix4("Copy",rsymi);
  /* Translate symop into the unit cell if necessary
     Do this by checking the translational part of
     the 4x4 symmetry matrix */
  if (diag) printf("Putting into unit cell...\n");
  itrans = 0;
  for (i=0; i<3; i++) {
    trn[i] = 0.0;
    if (diag) printf("fabs(rsymi[%d][3]) = %f\n",i,fabs(rsymi[i][3]));
    if (fabs(rsymi[i][3]) >= 1.0) {
      #if defined _MSC_VER
      rsymi[i][3] = modf(rsymi[i][3],&trn[i]);  
      #else
      rsymi[i][3] = modff(rsymi[i][3],&trn[i]);  
      #endif
      itrans = 1;
    }
    if (rsymi[i][3] < 0.0) {
      rsymi[i][3] = rsymi[i][3] + 1.0;
      itrans = 1;
      trn[i] = trn[i] - 1.0;
    }
  }
  if (diag) {
    print_float_matrix4("After shifting to unit cell",rsymi);
    printf("itrans = %d trn = %f %f %f\n",itrans,trn[0],trn[1],trn[2]);
  }
  /* Lookup the symmetry operation */
  if ((nop = LookupSymId(spgrp,rsymi)) == 0) {
    /* Failed to find symmetry operation */
    if (diag) printf("LookupSymMatInSpgrp: failed to return a symid\n");
    return 0;
  }
  *number = nop;
  *itrn = itrans;
  if (diag) printf("Symid number returned as %d\n",nop);
  /* Fetch the symop string */
  /* FIXME last argument of the call below is a guess */
  GetLCSymopString(rsymi,symop,30);
  if (diag) printf("Symop string returned as \"%s\"\n",symop);
  /* Construct symid string */
  sprintf(symid,"%d_%d%d%d",nop,(5 + (int) trn[0]),
	  (5 + (int) trn[1]), (5 + (int) trn[2]));
  if (diag) printf("Symid code: %s\n",symid);
  if (diag) printf("Finished LookupSymMatInSpgrp\n\n");
  return nop;
}

int LookupSymId(CCP4SPG *spgrp, float rsym[4][4]) {
  /* Return the sym id for a symmetry operation
     given the 4x4 Rsymm representation and the
     spacegroup data */
  int i,nsym;
  int j,k;
  float rsymi[4][4];
  nsym = GetNSymops(spgrp);
  if (nsym < 1) {
    return 0;
  }
  for (i=0; i<nsym; i++) {
    GetRsymMatrix(spgrp,i,rsymi);
    if (SymMatricesAreEquiv(rsym,rsymi,1.0e-4)) {
      return i+1;
    }
  }
  /* Failed to find a match */
  return 0;
}
