/* 
   symconv_lib.h

   Function prototype declarations for the symconv program

   CVS ID: $Id$
*/
#include <math.h>
#include <ccp4/cmtzlib.h>
#include <ccp4/ccp4_utils.h>
#include <ccp4/ccp4_general.h>
#include <ccp4/csymlib.h>
#include <ccp4/ccp4_spg.h>

/** Returns a new (empty) CCP4SPG struct
 * @return Pointer to spacegroup structure
 */
CCP4SPG *ccp4spg_new();

/** Adds a symmetry operation to an existing spacegroup
 * @param ccp4_spg (I) Pointer to the spacegroup structure
 * @param symop (I) Symmetry operator in string format
 * @return Number of symmetry operations
 */
int AddSymopFromString(CCP4SPG *ccp4_spg, char *symop);

/** Returns the number of symops in a spacegroup
 * @param ccp4_spg (I) Pointer to the spacegroup structure
 * @return Number of symmetry operations
 */
int GetNSymops(CCP4SPG *ccp4_spg);

/** Returns the number of primitive symops in a spacegroup
 * @param ccp4_spg (I) Pointer to the spacegroup structure
 * @return Number of primitive symmetry operations
 */
int GetNPrimitiveSymops(CCP4SPG *ccp4_spg);

/** Returns the extended Hermann-Macguin symbol for the spacegroup
 * @param ccp4_spg (I) Pointer to the spacegroup structure
 * @return Pointer to the xHM symbol string
 */
char *GetxHMSymbol(CCP4SPG *ccp4_spg);

int GetSpgrpNumber(CCP4SPG *ccp4_spg);

int GetCCP4SpgrpNumber(CCP4SPG *ccp4_spg);

int GetLaueClassNumber(CCP4SPG *ccp4_spg);

char *GetLaueClassName(CCP4SPG *ccp4_spg);

int GetPattersonNumber(CCP4SPG *ccp4_spg);

char *GetPattersonName(CCP4SPG *ccp4_spg);

/** Returns the i'th symop in the specified spacegroup, as a
 ** 4x4 symmetry matrix
 * @param ccp4_spg (I) Pointer to spacegroup structure
 * @param i (I) Position of the symop in the list
 * @param rsymm (O) Symmetry matrix (4x4)
 * @return 1 on success, 0 on failure
 */
int GetRsymMatrix(CCP4SPG *ccp4_spg, int i, float rsym[4][4]);

/** Returns the string representation of a symop which is
 ** supplied as a 4x4 symmetry matrix
 * @param rsymm (I) Symmetry matrix (4x4)
 * @param symop (I) Pointer to a string which the symop will be written to
 * @param n (I) Length of symop
 * @return 1 on success, 0 on failure
 */
int GetSymopString(float rsym[4][4], char *symop, int n);

/** Returns the string representation of a symop which is
 ** supplied as a 4x4 symmetry matrix in lowercase-nospace format
 * @param rsymm (I) Symmetry matrix (4x4)
 * @param symop (I) Pointer to a string which the symop will be written to
 * @param n (I) Length of symop
 * @return 1 on success, 0 on failure
 */
int GetLCSymopString(float rsym[4][4], char *symop, int n);

int GetRecipSymopString(float rsym[4][4], char *symop, int n);

int IsRecipSymop(char *symop);

int GetMatrixFromSymop(char *symop, float rsym[4][4]);

int SymMatricesAreEquiv(float m1[4][4], float m2[4][4], float tol);

int LookupSymMatInSpgrp(CCP4SPG *spgrp, float rsym[4][4],
			char *symop, int *number, char *symid,
			int *itrn, float trn[3]);

int PrintSymMatLookup(CCP4SPG *spgrp, float rsym[4][4]);

int LookupSymId(CCP4SPG *spgrp, float rsym[4][4]);
