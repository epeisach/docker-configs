/*
     SYMCONV
     Copyright (C) 2006 CCLRC, Peter Briggs

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK
*/

/* symconv.c

   Jiffy functions for dealing with symmetry libraries etc

   To compile:
   gcc -c -o symconv_lib.o symconv_lib.c -I${CLIBS}
   gcc -c -o symconv.o symconv.c -I${CLIBS}
   gcc -o symconv symconv.o symconv_lib.o -L${CLIB} -lccp4c -lm
   or use the accompanying Makefile

*/

/****************************************************************
 * Headers
 ****************************************************************/

#include <math.h>
#include <ccp4/ccp4_program.h>
#include <ccp4/ccp4_parser.h>
#include <ccp4/ccp4_general.h>
#include <ccp4/ccp4_unitcell.h>
#include <ccp4/csymlib.h>
#include <ccp4/cvecmat.h>
#include "symconv_lib.h"
#include "symconv_utils.h"

/****************************************************************
 * Local function prototypes
 ****************************************************************/

int ApplyCellToSymmat(double rorth[3][3], double rfrac[3][3],
		      float rsym[4][4], float rsymt[4][4]);

CCP4SPG *GetRCSBSpacegroup(char *name);

int PrintSymops(CCP4SPG *spgrp);

int PrintRCSBSymops(CCP4SPG *spgrp, CCP4SPG *rcsb_spgrp);

int PrintSymMatLookup(CCP4SPG *spgrp, float rsym[4][4]);

/****************************************************************
 * Define constants
 ****************************************************************/

/* Define numbers as constants not macros
   Kernighan and Pike, "The Practice of Programming" */

static char SYMCONV_VERSION[] = "0.0.7";

/* Some limits */
enum {
  MAX_LINE_LEN = 1000
};

/****************************************************************
 * Program code
 ****************************************************************/

static char rcsid[] = "$Id$";

/* Main program */

int main(int argc, char **argv) {

  /* Declarations */

  int     i,j,nspgp,nsym,nspgp_first=1,nspgp_last=230;
  int     icell=0,ixds=1,ircsb=1,ncode=1,irecip=0,ispgrpnum=0;
  int     spgrpnum = 0;
  double  cell[6],rorth[3][3],rfrac[3][3];
  float   rsym[4][4],rsymt[4][4];
  char    symch[80],symch_rcsb[80],spgnam[80];
  CCP4SPG *spgrp=NULL,*rcsb_spgrp=NULL;

  /* Operator */
  char          operator[MAX_LINE_LEN];

  /* Spacegroup name */
  char          spacegroup[MAX_LINE_LEN];

  /* CCP4 parser parameters */
  int           ntok=0,cont;
  char          line[MAX_LINE_LEN+1],*key;
  CCP4PARSERARRAY *parser;

  /****************
    PROGRAM START
  *****************/

  /* Perform CCP4 initialisations */
  ccp4ProgramName ("symconv");
  ccp4RCSDate     ("$Date$");
  ccp4_prog_vers(SYMCONV_VERSION);
  ccp4_banner();
  if (ccp4fyp(argc,argv)) {
    ccperror(1,"Error parsing command line (see above)");
  }

  /***************************
    Read the keyworded input
  ****************************/
  
  /* Set up the parser
     This is used to return the tokens and associated info
     Set maximum number of tokens per line to 50 */
  parser = (CCP4PARSERARRAY *) ccp4_parse_start(50);
  if (parser == NULL)
    ccperror (1,"Couldn't create parser array");

  /* Set delimiters to whitespace only */
  ccp4_parse_delimiters(parser," \t\n",NULL);

  /* Set up handy shortcuts */
  key = parser->keyword;

  /* Read lines from stdin until END/end keyword is entered or
     EOF is reached */
  cont = 1;

  while (cont) {
    /* Blank the line before calling ccp4_parser
       to force reading from stdin */
    line[0] = '\0';

    /* Call ccp4_parser to read input line and break into tokens
       Returns the number of tokens, or zero for eof */
    ntok = ccp4_parser(line,MAX_LINE_LEN,parser,1);

    if (ntok < 1) {
      /* End of file encountered */
      cont = 0;
    } else {      
      /* Lookup keywords */

      /* RCSB/NORCSB keywords
	 Usage: RCSB | NORCSB */
      if (ccp4_keymatch("RCSB",key) == 1) {
	/* Turn on the output of RCSB-related symmetry info */
	printf("RCSB-related symmetry info will be written out with symop data\n");
	ircsb = 1;
	/* Reload info for current spacegroup */
	if (spgrp) {
	  rcsb_spgrp = GetRCSBSpacegroup(GetxHMSymbol(spgrp));
	}
	/* Next keyword */
	continue;
      }
      if (ccp4_keymatch("NORCSB",key) == 1) {
	/* Turn off the output of RCSB-related symmetry info */
	printf("Writing of RCSB-related symmetry info is disabled\n");
	ircsb = 0;
	/* Next keyword */
	continue;
      }

      /* XDS/NOXDS keywords
	 Usage: XDS | NOXDS */
      if (ccp4_keymatch("XDS",key) == 1) {
	/* Turn on the output of XDS REIDX line */
	printf("XDS REIDX line will be written out with symop data\n");
	ixds = 1;
	/* Next keyword */
	continue;
      }
      if (ccp4_keymatch("NOXDS",key) == 1) {
	/* Turn off the output of XDS REIDX line */
	printf("Writing of XDS REIDX line with symop data is disabled\n");
	ixds = 0;
	/* Next keyword */
	continue;
      }

      /* CELL/NOCELL keywords
	 Usage: NOCELL | CELL a b c [alpha beta gamma] */
      if (ccp4_keymatch("NOCELL",key) == 1) {
	/* Disable use of cell parameters */
	icell = 0;
	printf("Use of cell parameters disabled\n");
	/* Next keyword */
	continue;
      }
      if (ccp4_keymatch("CELL",key) == 1) {
	/* Get cell parameters */
	for (i=0; i<3; i++) {
	  cell[i] = 0.0;
	  cell[i+3] = 90.0;
	}
	if (ntok < 4 || ntok > 7) {
	  ccperror(2,"Usage: CELL <a> <b> <c> [<alpha> <beta> <gamma>]");
	  continue;
	}
	for (i=1; i<ntok; i++) {
	  if (parser->token[i].isnumber) {
	    cell[i-1] = (double) parser->token[i].value;
	  } else {
	    ccperror(2,"Error: non-numerical value supplied for CELL");
	    continue;
	  }
	}
	/* Set flag and get transformation matrices */
	icell = 1;
	zero_double_matrix3(rorth);
	zero_double_matrix3(rfrac);
	for (i=0; i<3; i++) {
	  for (j=0; j<3; j++) {
	    rorth[i][j] = 0.0;
	    rfrac[i][j] = 0.0;
	  }
	}
	ccp4uc_frac_orth_mat(cell,ncode,rorth,rfrac);
	/* Print the information */
	printf("Use of cell parameters enabled\n");
	printf("Cell: ");
	for (i=0; i<6; i++) printf(" %.2f",cell[i]);
	printf("\n");
	print_double_matrix3("Fractionalising matrix",rfrac);
	print_double_matrix3("Orthogonalising matrix",rorth);
	/* Next keyword */
	continue;
      }

      /* OP keyword
	 Usage: OP <operator> */
      if (ccp4_keymatch("OP",key) == 1) {
	/* Fetch the operator */
	if (ntok == 2) {
	  /* Operator is the second token */
	  strncpy(operator,parser->token[1].fullstring,MAX_LINE_LEN);
	  printf("\nOperator: %s\n\n",operator);
	} else if (ntok > 2) {
	  /* Operator is the remainder of the line */
	  strncpy(operator,&line[parser->token[1].ibeg],MAX_LINE_LEN);
	} else {
	  ccperror(1, "Usage: OP <symmetry_operator>");
	}
	/* Is this a reciprocal space operator? */
	if (IsRecipSymop(operator)) {
	  printf(" %s is a reciprocal space operation\n\n",operator);
	  irecip = 1;
	} else {
	  printf(" %s is a real space operation\n\n",operator);
	  irecip = 0;
	}
	/* Fetch and display the operator in matrix form */
	if (GetMatrixFromSymop(operator,rsym)) {
	  /* Write matrix as 4x4 quine matrix */
	  print_float_matrix4(" The matrix [R,T]",rsym);
	  if (ixds) {
	    if (irecip) {
	      /* Write out XDS REIDX record format
	       for reciprocal space operators*/
	      printf(" In XDS format:\n REIDX=");
	      for (i=0; i<3; i++) {
		for (j=0; j<4; j++) {
		  printf(" %.0f",rsym[i][j]);
		}
	      }
	      printf("\n\n");
	    } else {
	      printf(" XDS REIDX only written for reciprocal space operations\n\n");
	    }
	  }
	  /* Perform transformation for unit cell if supplied */
	  if (icell) {
	    ApplyCellToSymmat(rorth,rfrac,rsym,rsymt);
	    print_float_matrix4(" The matrix with cell applied [R',T']",rsymt);
	  }
	  /* Look up operator in spacegroup if supplied
	     Only for real space operators at the moment */
	  if (!irecip) {
	    if (spgrp) {
	      printf("CCP4 format");
	      PrintSymMatLookup(spgrp,rsym);
	      if (ircsb && rcsb_spgrp) {
		printf("RCSB format");
		PrintSymMatLookup(rcsb_spgrp,rsym);
	      }
	    }
	  }
	} else {
	  ccperror(1,"Failed to decode symmetry operator");
	}
	/* Next keyword */
	continue;
      }

      /* SPACEGROUP|NOSPACEGROUP keyword
	 Usage: SPACEGROUP <name> */
      if (ccp4_keymatch("NOSPACEGROUP",key) ||  ccp4_keymatch("SPACEGROUP",key)) {
	/* In both cases, clear the existing data first */
	if (spgrp) {
	  ccp4spg_free(&spgrp);
	  spgrp = NULL;
	}
	if (rcsb_spgrp) {
	  ccp4spg_free(&rcsb_spgrp);
	  rcsb_spgrp = NULL;
	}
      }
      if (ccp4_keymatch("NOSPACEGROUP",key) == 1) {
	/* Disable use of spacegroup information */
	printf("Use of spacegroup information disabled\n");
	/* Next keyword */
	continue;
      }
      if (ccp4_keymatch("SPACEGROUP",key) == 1) {
	/* Fetch the spacegroup name */
	ispgrpnum = 0;
	if (ntok == 2) {
	  /* Spacegroup is the second token */
	  strncpy(spacegroup,parser->token[1].fullstring,MAX_LINE_LEN);
	  printf("Spacegroup: %s\n",spacegroup);
	  if (parser->token[1].isnumber) {
	    /* Spacegroup "name" is actually a number */
	    ispgrpnum = 1;
	    spgrpnum = (int) parser->token[1].value;
	  }
	} else if (ntok > 2) {
	  /* Spacegroup is the remainder of the line */
	  strncpy(spacegroup,&line[parser->token[1].ibeg],MAX_LINE_LEN);
	} else {
	  ccperror(1, "Usage: SYMMETRY <spacegroup_name>");
	}
	/* Search for specific name or number */
	if (!ispgrpnum) {
	  spgrp = ccp4spg_load_by_ccp4_spgname(spacegroup);
	} else {
	  spgrp = ccp4spg_load_by_ccp4_num(spgrpnum);
	}
	if (!spgrp) {
	  ccperror(1,"Failed to find spacegroup in symmetry library");
	}
	/* Look up RCSB equivalent using xHM symbol */
	if (ircsb &&(rcsb_spgrp = 
		     GetRCSBSpacegroup(GetxHMSymbol(spgrp))) == NULL) {
	  printf("No equivalent RCSB spacegroup was found\n");
	}
	/* Print out the data */
	printf("========================================\n");
	/* Print spacegroup name (extended H-M symbol) */
	if (strlen(GetxHMSymbol(spgrp)) > 0) {
	  printf("Spacegroup name (xH-M): '%s'\n",GetxHMSymbol(spgrp));
	} else {
	  printf("Spacegroup name (xH-M): unknown\n");
	}
	/* Print the spacegroup numbers */
	if (GetSpgrpNumber(spgrp) != 0) {
	  printf("Spacegroup number     : %d\n",GetSpgrpNumber(spgrp));
	} else {
	  printf("Spacegroup number     : unknown\n");
	}
	if (GetCCP4SpgrpNumber(spgrp) != 0) {
	  printf("CCP4 number           : %d\n",GetCCP4SpgrpNumber(spgrp));
	} else {
	  printf("CCP4 number           : unknown\n");
	}
	printf("Patterson spacegroup  : %d (%s)\n",GetPattersonNumber(spgrp),
	       GetPattersonName(spgrp));
	printf("Laue Class            : %d (%s)\n",GetLaueClassNumber(spgrp),
	       GetLaueClassName(spgrp));
	printf("========================================\n");
	/* Print the symops in string notation */
	printf("\n Symmetry operators:\n\n");
	if (ircsb && rcsb_spgrp) {
	  PrintRCSBSymops(spgrp,rcsb_spgrp);
	  printf("\n (* = sym.ids which differ between conventions)\n");
	} else {
	  PrintSymops(spgrp);
	}
	/* Done */
	printf("\n");
	/* Next keyword */
	continue;
      }

      /* END keyword
         Usage: END */
      if (ccp4_keymatch("END",key) && parser->ntokens == 1) {
	printf("END of input\n");
        break;
      }

      /* Keyword not recognised */
      ccperror(1,"Unrecognised input");
    }
      
    /* End of parser loop */
  }

  /* Clean up parser array */
  ccp4_parse_end(parser);

  /* Clean up spacegroup data, if any */
  if (spgrp) {
    ccp4spg_free(&spgrp);
    spgrp = NULL;
  }

  /* Finish */
  ccperror(0, "Normal termination");
}

/****************************************************************
 * Local functions
 ****************************************************************/

/* Generate the orthogonal symmetry matrix from the fractional
   matrix plus the orthogonalising and fractionalising matrices
   derived from the unit cell parameters */
int ApplyCellToSymmat(double rorth[3][3], double rfrac[3][3],
		      float rsym[4][4], float rsymt[4][4]) {
  int i,j;
  double rsymd[4][4],r[3][3],t[3],to[3],ro[3][3];

  /* Make a "double" version of the symop matrix */
  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
      rsymd[i][j] = (double) rsym[i][j];
    }
  }

  /* Split the 4 matrix up */
  split_matrix4(rsymd,r,t);
  /*
  print_double_matrix3("3 matrix",r);
  print_double_vector3("3 vector",t);
  */

  /* Transform the symop matrix
     using:
     [rfsym] = [ro] [rsym] [rf] */
  ccp4_3matmul(ro,r,rfrac);
  ccp4_3matmul(r,rorth,ro);
  /*
  print_double_matrix3("Transformed matrix [r]",r);
  */

  /* Transform the translation vector */
  for (i=0; i<3; i++) {
    to[i] = 0.0;
    for (j=0; j<3; j++)
      to[i] = to[i] + rorth[i][j]*t[j];
  }
  /*
  print_double_vector3("Transformed translation [t]",to);
  */

  /* Assemble a float 4 matrix for output */
  join_matrix4(r,to,rsymd);
  for (i=0; i<4; i++)
    for (j=0; j<4; j++)
      rsymt[i][j] = (float) rsymd[i][j];
  return 1;
}

/* Given a spacegroup, print the symops in string
   notation */
int PrintSymops(CCP4SPG *spgrp) {
  int nsym,i;
  float rsym[4][4];
  char symch[80];
  nsym = GetNSymops(spgrp);
  if (nsym) {
    printf("  Sym.id\tOperator\n  ----------------------------\n");
    for ( i=0 ; i < nsym ; i++ ) {
      /* Get rsym matrix */
      GetRsymMatrix(spgrp,i,rsym);
      /* Get C string representation */
      GetLCSymopString(rsym,symch,80);
      printf("  %6d\t%s\n",(i+1),symch);
    }
  } else {
    printf("No symmetry operators\n");
  }
  return 1;
}

/* Given two spacegroups, print out the symops in string
   notation, plus the RCSB and CCP4 symids
   Variant of PrintSymops */
int PrintRCSBSymops(CCP4SPG *spgrp, CCP4SPG *rcsb_spgrp) {
  int nsym,i,j;
  float rsym[4][4];
  char symch[80],flag;
  nsym = GetNSymops(spgrp);
  if (nsym) {
    if (rcsb_spgrp) {
      printf("    Sym.ids\n  CCP4\tRCSB\tOperator\n  ----------------------------\n");
    } else {
      printf("  Sym.id\tOperator\n  ----------------------------\n");
    }
    for ( i=0 ; i < nsym ; i++ ) {
      /* Get rsym matrix */
      GetRsymMatrix(spgrp,i,rsym);
      /* Get C string representation */
      GetLCSymopString(rsym,symch,80);
      /* Get RCSB symid */
      if (rcsb_spgrp) {
	j = LookupSymId(rcsb_spgrp,rsym);
	if (i+1 != j) {
	  flag = '*';
	} else {
	  flag = ' ';
	}
	printf("  %4d\t%4d%c\t%s\n",(i+1),j,flag,symch);
      } else {
	printf("  %6d\t%s\n",(i+1),symch);
      }
    }
  } else {
    printf("No symmetry operators\n");
  }
  return 1;
}

/* Given a spacegroup and a symmetry operation in 4x4 matrix
   form, put the operation into the unit cell and print the
   sym.id, the string representation of the operation in the
   unit cell, any additional unit cell translations and the
   sym code (sym.id plus translation e.g. 5_555)
 */
int PrintSymMatLookup(CCP4SPG *spgrp, float rsym[4][4]) {
  int i,nop,itrn;
  float trn[3];
  char symop[120],symid[120];

  if (!LookupSymMatInSpgrp(spgrp,rsym,symop,&nop,symid,&itrn,trn)) {
    /* Not found (or no operators for spacegroup?) */
    printf("\n Not recognised as an operator in %s\n\n",GetxHMSymbol(spgrp));
    return 0;
  }
  printf(" sym.id: %s\n",symid); 
  printf(" Corresponds to operator number %d (%s) in %s\n",
	 nop,symop,GetxHMSymbol(spgrp));
  /* Report any translations necessary */
  if (itrn) {
    printf(" with an additional translation of [");
    for (i=0; i<3; i++) {
      printf(" %.0f",trn[i]);
    }
    printf(" ]\n");
  }
  /* Finished so return */
  printf("\n");
  return 1;
}
