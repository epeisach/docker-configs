/*
  symconv_utils.c

  Utilities for symconv program (mainly printing and
  manipulating 3x3/4x4 matrices)

  CVS ID: $Id$
*/

#include "symconv_utils.h"

/* Print out a 3x3 matrix of doubles with a title string*/
int print_double_matrix3(char *title, double matrix[3][3]) {
  int i,j;
  if (strlen(title) > 0) {
    printf("%s:\n",title);
  }
  for (i=0; i<3; i++) {
    for (j=0; j<3; j++) {
      printf(" % 7.3f",matrix[i][j]);
    }
    printf("\n");
  }
  return 1;
}

/* Print out a 3 vector of doubles with a title string*/
int print_double_vector3(char *title, double vector[3]) {
  int i;
  if (strlen(title) > 0) {
    printf("%s:\n",title);
  }
  for (i=0; i<3; i++) {
    printf(" % 7.3f",vector[i]);
  }
  printf("\n");
  return 1;
}

/* Print out a 4x4 matrix of floats with a title string*/
int print_float_matrix4(char *title, float matrix[4][4]) {
  int i,j;
  if (strlen(title) > 0) {
    printf("%s:\n",title);
  }
  for (i=0; i<4; i++) {
    for (j=0; j<4; j++) {
      printf(" % 7.3f",matrix[i][j]);
    }
    printf("\n");
  }
  printf("\n");
  return 1;
}

/* Set all elements to zero for a 3x3 double precision
   matrix */ 
int zero_double_matrix3(double matrix[3][3]) {
  int i,j;
  for (i=0; i<3; i++)
    for (j=0; j<3; j++)
      matrix[i][j] = 0.0;
  return 1;
}


/* Split 4x4 matrix into 3x3 and 3 vector */
int split_matrix4(double mat4[4][4], double mat3[3][3],
		  double vec3[3]) {
  int i,j;
  for (i=0; i<3; i++) {
    vec3[i] = mat4[i][3];
    for (j=0; j<3; j++) {
      mat3[i][j] = mat4[i][j];
    }
  }
  return 1;
}

/* Join 3x3 matrix and 3 vector into 4x4 matrix */
int join_matrix4(double mat3[3][3],double vec3[3],
		 double mat4[4][4]) {
  int i,j;
  for (i=0; i<3; i++) {
    mat4[i][3] = vec3[i];
    for (j=0; j<3; j++) {
      mat4[i][j] = mat3[i][j];
    }
  }
  return 1;
}

/* Calculate the determination of a 3x3 matrix of
   doubles */
double determinant(double r[3][3]) {
  return r[0][0]*(r[1][1]*r[2][2]-r[2][1]*r[1][2]) -
    r[1][0]*(r[0][1]*r[2][2]-r[2][1]*r[0][2]) +
    r[2][0]*(r[0][1]*r[1][2]-r[1][1]*r[0][2]);
}
