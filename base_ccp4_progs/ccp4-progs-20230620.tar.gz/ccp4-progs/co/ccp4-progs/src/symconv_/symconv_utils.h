/*
  symconv_utils.h

  Header file with function prototypes for utilities for
  symconv program

  CVS ID: $Id$
*/

#include <stdio.h>
#include <string.h>
#include <ccp4/cvecmat.h>

int print_double_matrix3(char *title,double matrix[3][3]);

int print_double_vector3(char *title,double vector[3]);

int print_float_matrix4(char *title, float matrix[4][4]);

int zero_double_matrix3(double matrix[3][3]);

int split_matrix4(double mat4[4][4], double mat3[3][3],
		  double vec3[3]);

int join_matrix4(double mat3[3][3],double vec3[3],
		 double mat4[4][4]);

double determinant(double r[3][3]);
