#!/usr/bin/env python
from __future__ import print_function
# import this into a python script in order to set up the CCP4 environment when
# CCP4Dispatchers is not in PYTHONPATH

import os
import sys

# Assume the dispatcher package is in $CCP4/share/python
cbin = os.path.dirname(os.path.realpath(__file__))
pkg_path = os.path.realpath(os.path.join(cbin, "../share/python"))
sys.path.insert(0, pkg_path)

import CCP4Dispatchers

# We now have a CCP4 environment
assert 'CCP4' in os.environ

if __name__ == '__main__':

    args = sys.argv
    myname = args.pop(0)
    if len(args) < 1:
        print("Not enough arguments supplied.")
        print("Usage:", myname, "dispatchername [program arguments]")
        sys.exit(2)        

    requested_dispatcher = args.pop(0)

    # Attempt to import Dispatcher
    try:
        _temp = __import__("CCP4Dispatchers." + requested_dispatcher, globals(),
                           locals(), ["Dispatcher"], -1)
    except ImportError:
        msg = "No dispatcher with the name '" + requested_dispatcher + "'"
        sys.exit(msg)

    # Instantiate and set any remaining command line arguments
    Dispatch = _temp.Dispatcher(communicate = False)
    Dispatch.set_cmd_args(args)

    # Call and return with the program's exit code
    Dispatch.call()
    if Dispatch.call_err:
        raise (Dispatch.call_err[1], None, Dispatch.call_err[2])
    else:
        sys.exit(Dispatch.call_val)    
