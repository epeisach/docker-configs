/************************************************************************
  msg_box.c
  Z070192
************************************************************************/

#include <stdio.h>
#include <X11/cursorfont.h>
#include <X11/StringDefs.h>
#include <X11/IntrinsicP.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>

extern XtAppContext  appcontext;     /* application context */
static  Widget       topLevel;       /* application shell */


static void       noticePopdownCallback(
			Widget            w,
			XtPointer         shell,
				   XtPointer         garbage2
			);
static void       no_op(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );
static void       popdown(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );
static void       ringbell(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );

/*** NEW behaviour ***/
static char notice_translations[] = {
  "<BtnDown>:     no_op()               \n\
   <BtnUp>:       no_op()               \n\
   <Key>Return:   popdown()             \n\
   <Key>:         ringbell()            \n\
"};
static XtActionsRec  actions [] = {
  {"no_op", no_op},
  {"popdown", popdown},
  {"ringbell", ringbell}
};
static Boolean actions_added = False;

/************************************************************************/
void
msg_box_ini(
	    Widget  top_level)
{
  topLevel = top_level;
}



/************************************************************************/
void
msg_box(
       char     *string)
{
  Screen        *screen;
  int            swidth, sheight;
  static Widget  noticeshell = (Widget)NULL,
                 noticetext = (Widget)NULL,
                 noticebutton = (Widget)NULL;
  Widget         noticeform;
  Dimension      width, height,
                 bwidth, bheight,
                 nwidth, nheight;
  Position       bx, by;
  static Cursor  cursor = (Cursor)NULL;

  if (!noticeshell) {
    noticeshell = XtVaCreatePopupShell("noticeShell", overrideShellWidgetClass,
			       topLevel,
			       XtNallowShellResize, True,
			       XtNborderWidth, 30,
			       NULL);
    XtOverrideTranslations(noticeshell,
			   XtParseTranslationTable(notice_translations));
    if (!actions_added) {
      actions_added = True;
      XtAppAddActions(appcontext, actions, XtNumber(actions));
    }
    noticeform = XtVaCreateManagedWidget("noticeForm", formWidgetClass,
			       noticeshell,
			       NULL);
  }
  if (!noticetext)
    noticetext = XtVaCreateManagedWidget("noticeLabel", labelWidgetClass,
			       noticeform,
			       XtNresize, True,
			       XtNresizable, True,
			       XtNborderWidth, 0,
			       NULL);
  XtVaSetValues(noticetext,
		               XtNlabel, string,
		               NULL);
  if (!noticebutton) {
    noticebutton = XtVaCreateManagedWidget("Continue", commandWidgetClass,
			       noticeform,
			       XtNresize, True,
			       XtNresizable, True,
			       XtNfromVert, noticetext,
			       XtNvertDistance, 20,
			       XtNhorizDistance, 0,
			       NULL);
        XtAddCallback(noticebutton, XtNcallback, noticePopdownCallback,
		      (XtPointer)noticeshell);
    XtRealizeWidget(noticeshell);
    cursor = XCreateFontCursor(XtDisplay(noticeshell), XC_top_left_arrow);
    XDefineCursor(XtDisplay(noticeshell), XtWindow(noticeshell), cursor);
  }

  /*** Set position of shell and it's children ***/

  screen = XtScreen(noticeshell);
  swidth = screen->width;
  sheight = screen->height;

  XtVaGetValues(noticeshell,
		XtNwidth, &width,
		XtNheight, &height,
		NULL);
  XtVaGetValues(noticebutton,
		XtNwidth, &bwidth,
		XtNheight, &bheight,
		XtNx, &bx,
		XtNy, &by,
		NULL);

  XtMoveWidget(noticeshell, (swidth-width)/2, (sheight-height)/2);
  XtMoveWidget(noticebutton, (width-bwidth)/2 , by);
  
  XtPopup(noticeshell, XtGrabExclusive);
  XtGrabKeyboard(noticeshell, False, GrabModeAsync,
		 GrabModeAsync, CurrentTime);
  XBell(XtDisplay(noticeshell), 80);
}




/***************** Callbacks & Actions *****************************/
static void
noticePopdownCallback(w, shell, garbage2)
Widget            w;
XtPointer         shell;
XtPointer         garbage2;
{
  XtPopdown((Widget)shell);
  XtUngrabKeyboard((Widget)shell, CurrentTime);
}


static void
no_op(
      Widget        w,
      XEvent       *event,
      String       *params,
      Cardinal     *num_params)
{
}


static void
popdown(
	Widget        w,
	XEvent       *event,
	String       *params,
	Cardinal     *num_params)
{
  XtPopdown(w);
  XtUngrabKeyboard(w, CurrentTime);
}


static void
ringbell(
	 Widget        w,
	 XEvent       *event,
	 String       *params,
	 Cardinal     *num_params)
{
  XBell(XtDisplay(w), 80);
}
