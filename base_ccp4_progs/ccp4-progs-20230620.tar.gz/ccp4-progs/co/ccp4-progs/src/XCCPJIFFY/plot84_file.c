/******************************************************************************
  plot84_file.c
  Z190592

  Deals with plot84 metafile
******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Command.h>

#include "sys_includes.h"
#include "msg_box.h"
#include "hardcopy_ctrl.h"
#include "plot84_file.h"
#include "ZDr2d.h"

extern Widget     topLevel;


static char  *bad_file_format = "Bad plot84 file format";

static void     my_quitCallback(
                        Widget              w,
                        XtPointer           shell,
                        XtPointer           garbage);

static void     my_plotCallback(
                        Widget              w,
                        XtPointer           plot_w,
                        XtPointer           garbage2);


char
*read_plot84_file(                   /* returns static error message or NULL */
		  char                 *plot84_filename, /* input */
		  int                  *npictures,       /* output */
		  int                  *file_descriptor, /* output */
		  PLOT84_FILE_CONTENS **contens)         /* output */
{
  PLOT84_HEADER       *headers;
  PLOT84_FILE_CONTENS *cont;
  int                  nread;
  char                 c, *pc, *pcb, *pce;
  int                  i;
  off_t                fileposition;

  if ((*file_descriptor = open(plot84_filename, O_RDONLY)) == -1)
    return(strerror(errno) );

  headers = (PLOT84_HEADER*)malloc(sizeof(PLOT84_HEADER));     /* one header */

  if ((nread = read(*file_descriptor, (void *)headers,
		    (unsigned)sizeof(PLOT84_HEADER))) != sizeof(PLOT84_HEADER))
    return(bad_file_format);

  /* c = (headers->paswrd) [8];
  (headers->paswrd) [8] = '\0'; */
  if (strncmp(headers->paswrd, "PLOT%%84",8))
    return(bad_file_format);
  /* (headers->paswrd) [8] = c; */

  *npictures = headers->npics;
  free(headers);

  /*** Now scan ALL pictures ***/

  lseek(*file_descriptor, (off_t)0, SEEK_SET);
  fileposition = (off_t)0;
  headers = (PLOT84_HEADER*)malloc(sizeof(PLOT84_HEADER) * *npictures);
  cont = (PLOT84_FILE_CONTENS *)malloc(sizeof(PLOT84_FILE_CONTENS) *
				       *npictures);
  for (i = 0; i < *npictures; ++i) {
    if ((nread = read(*file_descriptor, (void *)(headers + i),
		    (unsigned)sizeof(PLOT84_HEADER))) != sizeof(PLOT84_HEADER))
      return(bad_file_format);

    /* c = ((headers + i)->paswrd) [8];
    ((headers + i)->paswrd) [8] = '\0'; */
    if (strncmp((headers + i)->paswrd, "PLOT%%84",8))
      return(bad_file_format);
    /* ((headers + i)->paswrd) [8] = c; */

    (cont + i)->header = headers + i;
    (cont + i)->command_addr = fileposition + (off_t)sizeof(PLOT84_HEADER);
    (cont + i)->ncommands = ((headers + i)->nrec);
    (cont + i)->picture_number = i + 1;

    /*** Convert fortran title to C string (calculate default) ***/

    for (pcb = (headers + i)->titleh, pce = pcb + 79;
	 *pce && *pce == ' ' && pce > pcb; --pce)
      ;
    if (*pcb == ' ' && pcb == pce)                            /* title empty */
      sprintf((cont + i)->title, "Picture %4d", (cont + i)->picture_number);
    else {
      for (pc = (cont + i)->title; pcb <= pce; ++pc, ++pcb)
	*pc = *pcb;
      *pc = '\0';
    }
      
   if (i < (*npictures - 1)) {
     fileposition += (off_t)sizeof(PLOT84_HEADER) +
                     (off_t)((headers + i)->nrec * sizeof(PLOT84_DATA_RECORD));
     lseek(*file_descriptor, fileposition, SEEK_SET);
   }
  }

  *contens = cont;
  return((char *)NULL);     /* O.K. */
}

char *
interpret_plot84_picture(
			 int                  file_descriptor,
			 PLOT84_FILE_CONTENS *cont,
			 Boolean              scene_scale_absolute,
			 float                scene_scale,
			 float                scene_orientation,
			 Widget               parent_w)
{
  PLOT84_DATA_RECORD           *commands;
  register  PLOT84_DATA_RECORD *pcom;
  Widget                        plot_w;
  unsigned                      input_size;
  register int                  i;
  float                         scale;
  float                         x, y;
  static int                    object_1 = 0;
  char                         *errmsg;
  ZDR2D_SCENE_DSC               scene;

  lseek(file_descriptor, cont->command_addr, SEEK_SET);
  input_size = sizeof(PLOT84_DATA_RECORD) * cont->ncommands;
  commands = (PLOT84_DATA_RECORD *)malloc(input_size);

  if (read(file_descriptor, (void *)commands, input_size) != input_size) {
    free((void *)commands);
    return("I/O error on plot84 file");
  }

  memset((void *)(&scene), (int)NULL, sizeof(scene));

  scale = 0.1;                          /* 10 dots per mm plot 84 convention */

  scene.label = cont->title;
  scene.minx = (float)(cont->header->ixmin) / 10.0;
  scene.maxx = (float)(cont->header->ixmax) / 10.0;         /* by definition */
  scene.miny = (float)(cont->header->iymin) / 10.0;
  scene.maxy = (float)(cont->header->iymax) / 10.0;
  scene.absolute_scale = scene_scale_absolute;
  scene.shift_to_min = True;
  scene.origin = ZDr2dSouthWest;
  scene.orientation = scene_orientation;
  scene.scale = scene_scale;


  /*** Create window environment ***/
  {
    Widget    shell, form, w, plot_button;

    shell = XtVaCreatePopupShell("plot84Picture", topLevelShellWidgetClass,
			       parent_w,
			       XtNtitle, cont->title,
			       XtNiconName, cont->title,
			       NULL);
    form = XtVaCreateManagedWidget("form", formWidgetClass,
			       shell,
			       NULL);
    w = XtVaCreateManagedWidget("Quit", commandWidgetClass,
			       form,
			       NULL);
                XtAddCallback(w,
		               XtNcallback, my_quitCallback,
			       (XtPointer)shell);
    plot_button = w = XtVaCreateManagedWidget("Plot", commandWidgetClass,
			       form,
			       XtNfromHoriz, w,
			       NULL);
    plot_w = XtVaCreateManagedWidget("draw2d", zDr2dWidgetClass, 
				form,
				XtNsceneDsc, &scene,
			        XtNfromVert, w,
				NULL);
    if (errmsg = XZDr2dNewObject(plot_w, (XtPointer)NULL, 1, (XtPointer)NULL,
				 (ZDR2D_MATRIX *)NULL))
      msg_box(errmsg);

    XtAddCallback(plot_button, XtNcallback, my_plotCallback,(XtPointer)plot_w);
    XtPopup(shell, XtGrabNone);
  }

  for (pcom = commands, i = 0; i < cont->ncommands; ++i, ++pcom)
    switch (pcom->x) {
    case END:
      if (errmsg = XZDr2dFinishObject(plot_w))
	msg_box(errmsg);
      if (errmsg = XZDr2dRenderScene(plot_w, True))
	msg_box(errmsg);
      free((void *)commands);
      return((char *)NULL);
      break;
    case DOT:
      ++i; ++pcom;
      x = (float)(pcom->x) * scale;
      y = (float)(-pcom->y) * scale;
      XZDr2dMoveto(plot_w, x, y); XZDr2dLineto(plot_w, x, y);
      break;
    case LINEWEIGHT:
      if (errmsg = XZDr2dChangeLineWidth(plot_w, (int)pcom->y))
	msg_box(errmsg);
      break;
    case COLOUR:
      if (errmsg = XZDr2dChangeColor(plot_w, (int)pcom->y))
	msg_box(errmsg);
      break;
    case BLANK_PAPER:
      XtWarning("BLANK_PAPER not implemented");
      break;
    case ERASE_MODE:
      XtWarning("ERASE_MODE ignored");
      break;

    default:
      x = (float)(pcom->x) * scale;
      if (pcom->y < (float)0) {
	y = (float)(-pcom->y) * scale;
	if (errmsg = XZDr2dMoveto(plot_w, x, y))
	  XtWarning(errmsg);
      }
      else {
	y = (float)(pcom->y) * scale;
	if (errmsg = XZDr2dLineto(plot_w, x, y))
	  XtWarning(errmsg);
      }
      break;
    }

  if (errmsg = XZDr2dFinishObject(plot_w))
    msg_box(errmsg);
  if (errmsg = XZDr2dRenderScene(plot_w, True))
    msg_box(errmsg);
  free((void *)commands);

  return((char *)NULL);
}
  

/*****************************************************************************/
static void
my_quitCallback(
		  Widget              w,
		  XtPointer           shell,
		  XtPointer           garbage)
{
  XtDestroyWidget((Widget)shell);
}


/*****************************************************************************/
static void
my_plotCallback(
		Widget              w,
		XtPointer           plot_w,
		XtPointer           garbage2)
{
  FILE  *fp;
  char  *errmsg;

  if (!(fp = hardcopy_rent_ps_file()))
    hardcopy_return_ps_file(True);
  else {
    if (errmsg = XZDr2dPostscript((Widget)plot_w, hardcopy_is_portrait(), fp))
      msg_box(errmsg);
    hardcopy_return_ps_file(errmsg ? True : False);
  }
}
