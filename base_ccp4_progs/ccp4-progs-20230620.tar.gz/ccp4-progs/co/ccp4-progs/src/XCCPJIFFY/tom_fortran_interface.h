/******************************************************************************
  tom_fortran_interface.h
  Z131093
******************************************************************************/

#ifndef tom_fortran_interface_
#define tom_fortran_interface_

/******************************************************************************
  This code IS machine dependent, because convetion for FORTRAN subroutine
  names is NOT standard. Please, have a look at your C - FORTRAN cooperation
  policy.
******************************************************************************/

#if defined(IRIX_4) || defined(IRIX_5) || defined(IRIX_6) || defined(IRIX_64) || defined(ESV_2) || defined (AL2800_2) || defined(CONVEX) || defined (SUNOS_4) || defined (SUNOS_5) || defined (DECALPHAOSF) || defined (_AIX) || defined (__hpux) || defined (linux) || (__DARWIN__) || (__APPLE__) || (__FreeBSD__) || defined (___AIX)  || defined (__linux__)
#  define KNOWN_MACHINE
#endif

#if ! defined (KNOWN_MACHINE)
  #error "machine is not known, correct Imakefile & this file"
#endif



extern char   *fontPath;

#if defined(IRIX_4) || defined(IRIX_5) || defined(IRIX_6) || defined(IRIX_64) || defined(ESV_2) || defined(AL2800_2) || defined (CONVEX) || defined (SUNOS_4) || defined (SUNOS_5) || defined (DECALPHAOSF) || defined (linux) || defined (__DARWIN__) || defined (__APPLE__) || (__FreeBSD__)
#  define TOM_GFPTH                 gfpth_
#  define TOM_START_GRAPHICS        graphic_start_up_
#  define TOM_START_OBJECT          start_object_
#  define TOM_FINISH_OBJECT         finish_object_
#  define TOM_GRAPH_MOVE            graph_move_
#  define TOM_GRAPH_DRAW            graph_draw_
#  define TOM_GRAPH_COL             graph_col_
#  define TOM_GRAPH_ALPHA           graph_alpha_
#  define TOM_GRAPH_CURSOR          graph_cursor_

/*** Other fortran routines (defined in Tom's code) ***/

#  define TOM_TEXT_STRING           text_string_
#  define TOM_AUTOSCALE             autoscale_
#  define TOM_ZEROY                 zeroy_
#  define TOM_DRAW_LIMITS           draw_limits_
#  define TOM_DRAW_GRAPH            draw_graph_

#endif /* IRIX_4 ESV_2 AL2800_2 CONVEX */

#if defined (_AIX) || defined (__hpux) || defined (___AIX)
#  define TOM_GFPTH                 gfpth
#  define TOM_START_GRAPHICS        graphic_start_up
#  define TOM_START_OBJECT          start_object
#  define TOM_FINISH_OBJECT         finish_object
#  define TOM_GRAPH_MOVE            graph_move
#  define TOM_GRAPH_DRAW            graph_draw
#  define TOM_GRAPH_COL             graph_col
#  define TOM_GRAPH_ALPHA           graph_alpha
#  define TOM_GRAPH_CURSOR          graph_cursor
#  define TOM_TEXT_STRING           text_string
#  define TOM_AUTOSCALE             autoscale
#  define TOM_ZEROY                 zeroy
#  define TOM_DRAW_LIMITS           draw_limits
#  define TOM_DRAW_GRAPH            draw_graph
#endif /* _AIX || __hpux */
/*** Routines defined within C code ***/

extern void   TOM_GFPTH(
		    char      *path);
extern void   TOM_START_GRAPHICS(
		    void);
extern void   TOM_START_OBJECT(
	            int    *num);     /* # of object. Tom's actual policy is */
                               /* 1 for axes, 2, 3, ... for each graph curve */
extern void   TOM_FINISH_OBJECT(
	            void);
extern void   TOM_GRAPH_MOVE(
	            float *x,
	            float *y);
extern void   TOM_GRAPH_DRAW(
	            float *x,
	            float *y);
extern void   TOM_GRAPH_COL(                 /* color - which pen is choosen */
	            int   *pen);
extern void   TOM_GRAPH_ALPHA(
	            void);
extern void   TOM_GRAPH_CURSOR(
	            void);


/*** Routines defined within FORTRAN code ***/

extern void   TOM_TEXT_STRING(
		    float     *x,
		    float     *y,
		    float     *size,
                    float     *rotation,
                    int       *textlength,
                    char      *text,
                    int       *not_used_dummy_length);
extern void   TOM_AUTOSCALE(
		    void);
extern void   TOM_ZEROY(
		    void);
extern void   TOM_DRAW_LIMITS(
		    float     *xmin,
		    float     *xmax,
		    float     *ymin,
		    float     *ymax);
extern void  TOM_DRAW_GRAPH(
		    float     *array,
		    int       *n_curves,
		    int       *n_rows,
		    int       *n_curves_once_more,
		    int       *n_rows_once_more);

#endif /* tom_fortran_interface_ */

