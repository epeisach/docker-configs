/*****************************************************************************
  ZDr2d.c
  Z090992

  Graphic widget for 2D graphics.

  Coordinate system used:

  -------------------------------->x
  |
  |
  |
  V
  y

  Bugs:
          check for maximal request size writes only warning message
	  GC properties other than color and line width cannot be set
*****************************************************************************/

#include <stdio.h>
#include <math.h>
#include <string.h>

#include <X11/Xlib.h>
#include <X11/IntrinsicP.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/CoreP.h>
#include <X11/Shell.h>
#include "ZDr2d.h"
#include "ZDr2dP.h"

#define POOL         100    /* default number of slots in instruction buffer */


/*** Standard methods and callbacks ***/

/*static void    Curs_pos();         * cursor position callback */

static void    Initialize(Widget       request,
			  Widget       new,
			  ArgList      args,
			  Cardinal    *num_args);
static void    Redisplay(Widget w,
			 XEvent       *event,
			 Region        region);
static void    Resize(Widget w);
static void    Destroy(Widget w);



/*** Supporting routines ***/

static void     setscale(                    /* scans data for & sets scale  */
			 ZDr2dWidget  w,
			 GR_OBJECT   *object);
static void     displayobj(                                /* removes object */
			 ZDr2dWidget  w, 
		         GR_OBJECT   *object);
static void     removeobj(                                /* displays object */
			 ZDr2dWidget  w, 
		         GR_OBJECT   *object);
static void     scaleobj(                               /* (re)scales object */
			 ZDr2dWidget  w,
			 GR_OBJECT   *object);
static GR_OBJECT *find_object(
			 GR_OBJECT *objects,
			 XtPointer obj_id);
static INSTRUCTION* newinstruction(
			 ZDr2dWidget  w, 
			 int       instruction_type);
static void       finishinstruction(
			 ZDr2dWidget  w);
static void       addpolylinepoint(
			 ZDr2dWidget  w, 
			 float     x,
			 float     y);

/*** Postscript management ***/

static char *    ps_init(
			 ZDr2dWidget  w,
			 int    portraitmode,
			 FILE  *psout);
static char *    ps_finish(void);

static char *    ps_interpret(
			 ZDr2dWidget  w,
			 GR_OBJECT   *object);
static char *    ps_moveto(
			 float  x,
			 float  y);
static char *    ps_lineto(
			 float  x,
			 float  y);

/*****
static char defaultTranslations[] = "<Btn1Down>: curs_pos() \n\
                                     <Btn2Down>: curs_pos() \n\
                                     <Btn3Down>: curs_pos()";

static XtActionsRec actionsList[] = {
  { "curs_pos",   (XtActionProc) Curs_pos},
};
*****/

static XtResource resources[] = {
  {  XtNhorizontalMargins, XtCMargin,
     XtRDimension, sizeof(Dimension),
     XtOffset(ZDr2dWidget, zDr2d.horizMargin),
     XtRString, "20"},

  {  XtNverticalMargins, XtCMargin,
     XtRDimension, sizeof(Dimension),
     XtOffset(ZDr2dWidget, zDr2d.vertMargin),
     XtRString, "20"},

  {  XtNsceneDsc, XtCSceneDsc,
     XtRPointer, sizeof(XtPointer),
     XtOffset (ZDr2dWidget, zDr2d.scene_limits),
     XtRPointer, NULL},

/***
  {  XtNcursorPositionCallback, XtCCallback,
     XtRCallback, sizeof(XtCallbackList),
     XtOffset (ZDr2dWidget, zDr2d.curs_pos), 
     XtRCallback, NULL},
***/

/********************************************************/
/********* Graphic contexts - pen descriptions **********/
/********************************************************/

  /* This convex conditional seems to have been for some borken
  version of X on the defunct Daresbury system.  Fails elsewhere. */
/* #ifdef __convex__
#    define PenOffset(pennum, penattr) \
     ((unsigned int) \
     &(((((ZDr2dWidget)NULL)->zDr2d.pen)[pennum]).penattr))
#else */
#    define PenOffset(pennum, penattr) \
     ((Cardinal) \
     (((char *)(&(((((ZDr2dWidget)NULL)->zDr2d.pen)[pennum]).penattr)) \
     - ((char *)NULL))))
/* #endif */ /*__convex__*/

  /*** Pen 1 ***/
  {  XtNpen1Color, XtCColor,  XtRPixel, sizeof (Pixel),
     PenOffset(0, color), XtRString, "Black" },
  {  XtNpen1LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(0, linewidth), XtRString, "0" },

  /*** Pen 2 ***/
  {  XtNpen2Color, XtCColor, XtRPixel, sizeof (Pixel), 
     PenOffset(1, color), XtRString, "Black" },
  {  XtNpen2LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(1, linewidth), XtRString, "0" },

  /*** Pen 3 ***/
  {  XtNpen3Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(2, color), XtRString, "Black" },
  {  XtNpen3LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(2, linewidth), XtRString, "0" },


  /*** Pen 4 ***/
  {  XtNpen4Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(3, color), XtRString, "Black" },
  {  XtNpen4LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(3, linewidth), XtRString, "0" },


  /*** Pen 5 ***/
  {  XtNpen5Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(4, color), XtRString, "Black" },
  {  XtNpen5LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(4, linewidth), XtRString, "0" },


  /*** Pen 6 ***/
  {  XtNpen6Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(5, color), XtRString, "Black" },
  {  XtNpen6LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(5, linewidth), XtRString, "0" },


  /*** Pen 7 ***/
  {  XtNpen7Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(6, color), XtRString, "Black" },
  {  XtNpen7LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(6, linewidth), XtRString, "0" },


  /*** Pen 8 ***/
  {  XtNpen8Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(7, color), XtRString, "Black" },
  {  XtNpen8LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(7, linewidth), XtRString, "0" },


  /*** Pen 9 ***/
  {  XtNpen9Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(8, color), XtRString, "Black" },
  {  XtNpen9LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(8, linewidth), XtRString, "0" },


  /*** Pen 10 ***/
  {  XtNpen10Color, XtCColor, XtRPixel, sizeof (Pixel),
     PenOffset(9, color), XtRString, "Black" },
  {  XtNpen10LineWidth, XtCLineWidth, XtRInt, sizeof(int),
     PenOffset(9, linewidth), XtRString, "0" },
#    undef  PenOffset

  /****************************************/
  /******** Postscript pen database *******/
  /****************************************/

#ifdef __convex__
#    define PenOffset(pennum) \
     ((unsigned int) \
     &((((ZDr2dWidget)NULL)->zDr2d.ps_pen)[pennum-1]))
#else
#    define PenOffset(pennum) \
     ((Cardinal) \
     (((char *)(&((((ZDr2dWidget)NULL)->zDr2d.ps_pen)[pennum-1])) - \
     ((char *)NULL))))
#endif /*__convex__*/

  /*** Ps Pen 1 ***/
  {  XtNpsPen1Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(1), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 2 ***/
  {  XtNpsPen2Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(2), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 3 ***/
  {  XtNpsPen3Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(3), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 4 ***/
  {  XtNpsPen4Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(4), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 5 ***/
  {  XtNpsPen5Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(5), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 6 ***/
  {  XtNpsPen6Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(6), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 7 ***/
  {  XtNpsPen7Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(7), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 8 ***/
  {  XtNpsPen8Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(8), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 9 ***/
  {  XtNpsPen9Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(9), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },

  /*** Ps Pen 10 ***/
  {  XtNpsPen10Attr, XtCPsPenAttr,  XtRString, sizeof(String),
     PenOffset(10), XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash" },
#    undef PenOffset


  /***********************************/
  /********** Color database ********/
  /***********************************/

/* #ifdef __convex__
#    define ColorOffset(colornum) \
     ((unsigned int) \
     &((((ZDr2dWidget)NULL)->zDr2d.color)[colornum-1])
#else */
#    define ColorOffset(colornum) \
    ((Cardinal) \
    (((char *)&((((ZDr2dWidget)NULL)->zDr2d.color)[colornum-1]) - \
      ((char *)NULL))))
/* #endif */ /*__convex__*/

  /*** Color 1 ***/
  { XtNcolor1, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(1), XtRString, "Black"},

  /*** Color 2 ***/
  { XtNcolor2, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(2), XtRString, "Black"},

  /*** Color 3 ***/
  { XtNcolor3, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(3), XtRString, "Black"},

  /*** Color 4 ***/
  { XtNcolor4, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(4), XtRString, "Black"},

  /*** Color 5 ***/
  { XtNcolor5, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(5), XtRString, "Black"},

  /*** Color 6 ***/
  { XtNcolor6, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(6), XtRString, "Black"},

  /*** Color 7 ***/
  { XtNcolor7, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(7), XtRString, "Black"},

  /*** Color 8 ***/
  { XtNcolor8, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(8), XtRString, "Black"},

  /*** Color 9 ***/
  { XtNcolor9, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(9), XtRString, "Black"},

  /*** Color 10 ***/
  { XtNcolor10, XtCColor, XtRPixel, sizeof(Pixel),
    ColorOffset(10), XtRString, "Black"},
#   undef ColorOffset

  /********************************************/
  /******** Postscropt "Color" database *******/
  /********************************************/

/* #ifdef __convex__
#    define ColorOffset(colornum) \
     ((unsigned int) \
     &((((ZDr2dWidget)NULL)->zDr2d.ps_color)[colornum-1]))
#else */
#    define ColorOffset(colornum) \
       ((Cardinal) \
          (((char *)&((((ZDr2dWidget)NULL)->zDr2d.ps_color)[colornum-1])- \
             ((char *)NULL))))
/* #endif */ /*__convex__*/

  /*** psColor 1 ***/
  { XtNpsColor1, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(1), XtRString, "[] 0 setdash"},

  /*** psColor 2 ***/
  { XtNpsColor2, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(2), XtRString, "[] 0 setdash"},

  /*** psColor 3 ***/
  { XtNpsColor3, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(3), XtRString, "[] 0 setdash"},

  /*** psColor 4 ***/
  { XtNpsColor4, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(4), XtRString, "[] 0 setdash"},

  /*** psColor 5 ***/
  { XtNpsColor5, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(5), XtRString, "[] 0 setdash"},

  /*** psColor 6 ***/
  { XtNpsColor6, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(6), XtRString, "[] 0 setdash"},

  /*** psColor 7 ***/
  { XtNpsColor7, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(7), XtRString, "[] 0 setdash"},

  /*** psColor 8 ***/
  { XtNpsColor8, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(8), XtRString, "[] 0 setdash"},

  /*** psColor 9 ***/
  { XtNpsColor9, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(9), XtRString, "[] 0 setdash"},

  /*** psColor 10 ***/
  { XtNpsColor10, XtCPsColor, XtRString, sizeof(String),
    ColorOffset(10), XtRString, "[] 0 setdash"},
#   undef ColorOffset

  /***********************************************/
  /************ Postscript setting  **************/
  /***********************************************/

  {  XtNpsDefaultAttr, XtCPsPenAttr,
     XtRString, sizeof(String),
     XtOffset(ZDr2dWidget, zDr2d.ps_default_attr),
     XtRString, "1 setlinejoin 0.5 setlinewidth [] 0 setdash"},

  {  XtNpsBasicLineWidth, XtCPsBasicLineWidth,
     XtRFloat, sizeof(float),
     XtOffset(ZDr2dWidget, zDr2d.ps_basic_line_width),
     XtRString, "0.5"}
};



ZDr2dClassRec  zDr2dClassRec = {
     /* CoreClassPart */
  {
   (WidgetClass) &widgetClassRec,  /* superclass            */
   "ZDr2d",                        /* class_name            */
   sizeof(ZDr2dRec),               /* widget_size           */
   NULL,                           /* class_initialize      */
   NULL,                           /* class_part_initialize */
   FALSE,                          /* class_inited          */
   Initialize,                     /* initialize            */
   NULL,                           /* initialize_hook       */
   XtInheritRealize,               /* realize               */
   NULL, /*actionsList,*/          /* actions               */
   0,    /*XtNumber(actionsList),*//* num_actions           */
   resources,                      /* resources             */
   XtNumber(resources),            /* num_resources         */
   NULLQUARK,                      /* xrm_class             */
   TRUE,                           /* compress_motion       */
   TRUE,                           /* compress_exposure     */
   TRUE,                           /* compress_enterleave   */
   FALSE,                          /* visible_interest      */
   Destroy,                        /* destroy               */
   Resize,                         /* resize                */
   Redisplay,                      /* expose                */
   NULL,                           /* set_values            */
   NULL,                           /* set_values_hook       */
   XtInheritSetValuesAlmost,       /* set_values_almost     */
   NULL,                           /* get_values_hook       */
   NULL,                           /* accept_focus          */
   XtVersion,                      /* version               */
   NULL,                           /* callback private      */
   NULL, /*defaultTranslations,*/  /* tm_table              */
   XtInheritQueryGeometry,         /* query_geometry        */
   XtInheritDisplayAccelerator,    /* display_accelerator   */
   NULL,                           /* extension             */
   },
      /* ZDr2d class fields */
  {
   0,                              /* ignore                */
   }
};

WidgetClass zDr2dWidgetClass = (WidgetClass) &zDr2dClassRec;





/********************** Initialize method *********************************/
static void
Initialize(
	   Widget       request,
	   Widget       new,
	   ArgList      args,
	   Cardinal    *num_args)
{
  ZDr2dPart            *ppart;
  Display              *display;
  float                 fx, fy, dx, dy;
  register int          i;
  double                angle, sina, cosa;

  ppart = &(((ZDr2dWidget)new)->zDr2d);

  if (!ppart->scene_limits)
    XtError("ZDr2d widget requires scene limits");

  /*** Clear important entries ***/

  ppart->objects = ppart->current_object = (GR_OBJECT *)NULL;
  ppart->current_instr = (INSTRUCTION *)NULL;
  ppart->gc = (GC)NULL;
  ppart->tot_scale = 0.0;

  /*** Display dependent pixel/mm ratio ***/

  display = XtDisplay(new);
  ppart->pixel_to_mm_ratio =
                      (float)DisplayWidth  (display, DefaultScreen(display)) /
                      (float)DisplayWidthMM(display, DefaultScreen(display));

  /*** Display dependent size of max size graphic request ***/

  ppart->serverlimit = XMaxRequestSize(XtDisplay(request));

  /*** initialize other data ***/

  ppart->limits_from_scene_limits = False;                    /* assume THIS */
  ppart->min_x = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->minx;
  ppart->max_x = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->maxx;
  ppart->min_y = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->miny;
  ppart->max_y = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->maxy;
  ppart->scene_label =
         XtNewString((String)((ZDR2D_SCENE_DSC *)ppart->scene_limits)->label);
  ppart->abs_scale = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->absolute_scale;
  ppart->scale = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->scale;
  if (ppart->scale == (float)0 || !ppart->abs_scale) ppart->scale = (float)1;
  ppart->shift_to_min = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->shift_to_min;
  ppart->origin = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->origin;
  ppart->max_scene_size =
         ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->max_scene_size;
  ppart->orientation = ((ZDR2D_SCENE_DSC *)ppart->scene_limits)->orientation;
  ppart->scene_limits = NULL;

  if ((dx = ppart->max_x - ppart->min_x) && (dy = ppart->max_y - ppart->min_y))
    ppart->limits_from_scene_limits = True;

  if (ppart->abs_scale)
    ppart->tot_scale = ppart->pixel_to_mm_ratio * ppart->scale;

  /*** scene rotation matrix ***/

  angle = (ppart->orientation / 180.0) * 3.14159;          /* deg -> radians */
  sina = sin(angle);
  cosa = cos(angle);

  ppart->scene_rot_matrix [0] [0] =  cosa;
  ppart->scene_rot_matrix [0] [1] =  sina;
  ppart->scene_rot_matrix [1] [0] = -sina;
  ppart->scene_rot_matrix [1] [1] =  cosa;


  /*** scene shift vector - calculated in SCENE coord system ***/

  if (dx && dy) {
    fx = ppart->shift_to_min ? dx : ppart->max_x;
    fy = ppart->shift_to_min ? dy : ppart->max_y;

    if      (cosa >= 0.0 && sina >= 0.0) {
      ppart->scene_shift_vector [0] = 0.0;/**/
      ppart->scene_shift_vector [1] = fx * sina;
    }
    else if (cosa < 0.0 && sina >= 0.0) {
      ppart->scene_shift_vector [0] = -fx * cosa;
      ppart->scene_shift_vector [1] =  fx * sina - fy * cosa;
    }
    else if (cosa >= 0.0 && sina < 0.0) {
      ppart->scene_shift_vector [0] = -fy * sina;
      ppart->scene_shift_vector [1] =  0.0;
    }
    else {
      ppart->scene_shift_vector [0] = -fy * sina - fx * cosa;
      ppart->scene_shift_vector [1] = -fy * cosa;
    }
  }


  if (ppart->abs_scale && dx && dy) {
    Dimension  x, y;
    double     fytmp;

    /*** calculate canvas size ***/

    if (!ppart->max_scene_size) {
      if (sina < 0.0) sina = -sina;
      if (cosa < 0.0) cosa = -cosa;
      fytmp = fy * cosa + fx * sina;                /* maxima after rotation */
      fx = (fx * cosa + fy * sina) * ppart->tot_scale;
      fy = fytmp * ppart->tot_scale;
    }
    else {
      fytmp = sqrt(fx*fx + fy*fy);
      fx = fy = fytmp * ppart->tot_scale;
    }

    x = fx; y = fy;
    new->core.width = x + 2 * ppart->horizMargin;
    new->core.height = y + 2 * ppart->vertMargin;
  }
    
  /*** If the widget size is 0, allocate something ***/

  if (new->core.width == 0)
    new->core.width = 180;
  if (new->core.height == 0)
    new->core.height = 140;
}


/********************** Destroy method *********************************/
static void
Destroy (
	 Widget w)
{
  ZDr2dPart          *ppart;
  register int        i;
  register GR_OBJECT *obj, *objnext;

  ppart = &(((ZDr2dWidget)w)->zDr2d);

  /*** Free memory ***/

  XtFree(ppart->scene_label);
  for (obj = ppart->objects; obj; obj = objnext) {
    objnext = obj->next;
    removeobj((ZDr2dWidget)w, obj);
  }

  /*** Release the GC ***/

  if (ppart->gc)
    XFreeGC (XtDisplay(w), ppart->gc);

  /*** Remove callbacks ***/
/**
  XtRemoveAllCallbacks (w, XtNcursorPositionCallback);
**/
}

/********************** Resize method ***********************************/
static void
Resize(
       Widget    w)
{
  ZDr2dPart    *ppart;
  float         data_ratio, screen_ratio;
  float         dx, dy, dytmp, sina, cosa, angle;
  Dimension     netwidth, netheight;

  ppart = &(((ZDr2dWidget)w)->zDr2d);

  if (ppart->abs_scale) {
    scaleobj((ZDr2dWidget)w, ppart->objects);
    return;
  }

  /*** Calculate new scale ***/

  netwidth = w->core.width - 2 * ppart->horizMargin;
  netheight = w->core.height - 2 * ppart->vertMargin;
  if (netwidth <= 10 || netheight <= 10) {
    ppart->tot_scale = 0.0;
    return;
  }

  dx = ppart->max_x;
  dy = ppart->max_y;
  if (ppart->shift_to_min) {
    dx -= ppart->min_x;
    dy -= ppart->min_y;
  }

  angle = (ppart->orientation / 180.0) * 3.14159;          /* deg -> radians */
  sina = sin(angle);
  cosa = cos(angle);
  if (!ppart->max_scene_size) {
    if (sina < 0.0) sina = -sina;
    if (cosa < 0.0) cosa = -cosa;
    dytmp = dy * cosa + dx * sina;                  /* maxima after rotation */
    dx = (dx * cosa + dy * sina);
    dy = dytmp;
  }
  else {
    dytmp = sqrt(dx*dx + dy*dy);
    dx = dy = dytmp;
  }

  data_ratio = dx / dy;
  screen_ratio = (float)(netwidth) / (float)(netheight);

  ppart->tot_scale = (data_ratio >= screen_ratio) ? 
                       ((float)(w->core.width) - 2 * ppart->horizMargin) / dx :
                       ((float)(w->core.height) - 2 * ppart->vertMargin) / dy;

  /*** Rescale objects ***/

  scaleobj((ZDr2dWidget)w, ppart->objects);
}

/********************** Redisplay method ***********************************/

static void
Redisplay (
	   Widget       w,
	   XEvent       *event,
	   Region        region)
{
  ZDr2dPart          *ppart;

  ppart = &(((ZDr2dWidget)w)->zDr2d);

  if(w->core.visible)
    displayobj((ZDr2dWidget)w, ppart->objects);
}


/************************** Call Back ***************************************/
/**
static void Curs_pos(w, event, args, n_args)
ZDr2dWidget   w;
XEvent        *event;
char          *args[];
int            n_args;
{
  ZDr2dCallbackStruct   cb;

  XtError("Cursor position not implemented");
  if(event->type == ButtonPress) {
    cb.reason = BUTTON_PRESS;
    cb.event = event;
*** Not ready yet
    cb.x = (float)(event->xbutton.x)/tot_scale;
    cb.y = (float)(event->xbutton.y)/tot_scale;
***
  }

*** Call user specified callback ***

  XtCallCallbacks ((Widget)w, XtNcursorPositionCallback, (XtPointer)(&cb)); 
} 
**/


/*****************************************************************************/
static GR_OBJECT *
find_object(
	    GR_OBJECT *objects,
	    XtPointer  obj_id)
{
  register GR_OBJECT  *obj;

  if (!objects)
    return((GR_OBJECT *)NULL);
  if (objects->objid == obj_id)
    return(objects);

  do {
    if (obj = find_object(objects->sub_object, obj_id))
      return(obj);
    else
      objects = objects->next;
  } while (objects);

  return((GR_OBJECT *)NULL);
}




/************************ Internal subroutines *****************************/

/************************ Scale object(s) **********************************/
static void
setscale(
	 ZDr2dWidget w,
	 GR_OBJECT  *object)
{
  register ZDr2dPart      *ppart;
  register INSTRUCTION    *pinstr;

  ppart = &(w->zDr2d);
  if (ppart->abs_scale)
    return;

  while (object) {
    for (pinstr = object->instructions; pinstr; pinstr = pinstr->next) {
      switch (pinstr->instruction_type) {
      case POLYLINE_TYPE: {
	register POLYLINE *ppoly;
	register int       i;
	float              fnum;
	
	for (i = pinstr->n_subinstructions, ppoly = pinstr->instrc.poly_line;
	     i; --i, ++ppoly) {
	  if ((fnum = ppoly->x) < ppart->min_x)
	    ppart->min_x = fnum;
	  if ((fnum = ppoly->x) > ppart->max_x)
	    ppart->max_x = fnum;
	  if ((fnum = ppoly->y) < ppart->min_y)
	    ppart->min_y = fnum;
	  if ((fnum = ppoly->y) > ppart->max_y)
	    ppart->max_y = fnum;
	}
        }
	break;
      default:
	XtError("ZDr2d - instruction type not implemented");
      };

      /*** Display sub-objects ***/

      setscale(w, object->sub_object);
      object = object->next;
    }
  }
}


/************************ Scale object(s)   **********************************/
static void
scaleobj(
	 ZDr2dWidget w,
	 GR_OBJECT  *object)
{
  ZDr2dPart               *ppart;
  register INSTRUCTION    *pinstr;
  register int             maxpolyline;
  int                      horiz_margin, vert_margin;
  float                    scale, shift_x, shift_y;
  float                    rot_matrix [2] [2], shift_vec [2];
  register int             row, col;

  ppart = &(((ZDr2dWidget)w)->zDr2d);

  scale = ppart->tot_scale;
  for (row = 0; row < 2; ++row)
    for (col = 0; col < 2; ++col)
      rot_matrix [row] [col] = ppart->scene_rot_matrix [row] [col] * scale;

  shift_x = (ppart->shift_to_min) ? ppart->min_x : (float)0;
  shift_y = (ppart->shift_to_min) ? ppart->min_y : (float)0;

  shift_vec [0] = ppart->scene_shift_vector [0] * scale +
                  w->zDr2d.horizMargin;
  shift_vec [1] = ppart->scene_shift_vector [1] * scale +
                  w->zDr2d.vertMargin;

  maxpolyline = (w->zDr2d.serverlimit - 3) / 2;
  horiz_margin = w->zDr2d.horizMargin;
  vert_margin = w->zDr2d.vertMargin;

  while (object) {
    for (pinstr = object->instructions; pinstr; pinstr = pinstr->next)
      switch (pinstr->instruction_type) {
      case POLYLINE_TYPE: {
	  register XPoint   *point;
	  register POLYLINE *ppoly;
	  register int       i;

	  if (pinstr->n_subinstructions > maxpolyline)
	    XtError("Polyline too long, complain to the author");
	  if (!pinstr->X11_buf)
	    pinstr->X11_buf =
	      (XtPointer)XtMalloc(sizeof(XPoint) * pinstr->n_subinstructions);
	  point = (XPoint *)pinstr->X11_buf;

	  if (w->zDr2d.origin == ZDr2dSouthWest)
	    for (i = pinstr->n_subinstructions,
		 ppoly = pinstr->instrc.poly_line; i; --i, ++ppoly, ++point) {
	      point->x = (ppoly->x - shift_x) * rot_matrix [0] [0] +
		         (w->zDr2d.max_y - ppoly->y) * rot_matrix [0] [1] +
			 shift_vec [0];

	      point->y = (ppoly->x - shift_x) * rot_matrix [1] [0] +
		         (w->zDr2d.max_y - ppoly->y) * rot_matrix [1] [1] +
			 shift_vec [1];
	    }
	  else /* Must be ZDr2dNorthWest */
	    for (i = pinstr->n_subinstructions,
		 ppoly = pinstr->instrc.poly_line; i; --i, ++ppoly, ++point) {

	      point->x = (ppoly->x - shift_x) * rot_matrix [0] [0] +
		         (ppoly->y - shift_y) * rot_matrix [0] [1] +
			 shift_vec [0];

	      point->y = (ppoly->x - shift_x) * rot_matrix [1] [0] +
		         (ppoly->y - shift_y) * rot_matrix [1] [1] +
			 shift_vec [1];
	    }
	}
	break;

      case CHANGE_PEN_TYPE:
      case CHANGE_COLOR_TYPE:
      case CHANGE_LINE_WIDTH_TYPE:
	break;
	
      default:
	XtError("ZDr2d - instruction type not implemented");
      };

    /*** Display sub-objects ***/

    scaleobj(w, object->sub_object);
                                                        /* Scale sub-objects */
    object = object->next;                           /*** try the next one ***/
  }
}



/************************ Display object(s) **********************************/
static void
displayobj(
	   ZDr2dWidget  w,
	   GR_OBJECT   *object)
{
  register ZDr2dPart      *ppart;
  register INSTRUCTION    *pinstr;
  register Display        *display;
  register Drawable        window;
  unsigned long            valueMask;      /* fo GC */
  XGCValues                values;

  ppart = &(w->zDr2d);
  display = XtDisplay((Widget)w);
  window = XtWindow((Widget)w);

  if (!ppart->gc) {
    static unsigned long  valueMask = 0L;      /* fo GC */
    static XGCValues      gcvalues;

    ppart->gc = XCreateGC (XtDisplay(w), XtWindow(w),
			   valueMask, &gcvalues);                /* empty GC */
    XCopyGC(XtDisplay(w), DefaultGCOfScreen(XtScreen(w)),
	    ~valueMask, ppart->gc);
  }

  while (object) {

    /*** Realize instructions ***/

    for (pinstr = object->instructions; pinstr; pinstr = pinstr->next)
      switch (pinstr->instruction_type) {
      case POLYLINE_TYPE:
	XDrawLines(display, window,
		   ppart->gc,
		   (XPoint *)(pinstr->X11_buf), 
		   pinstr->n_subinstructions,
		   CoordModeOrigin);
	break;

      case CHANGE_PEN_TYPE:
	valueMask = GCForeground | GCLineWidth;
	values.foreground = ((ppart->pen)+pinstr->instrc.pen_num-1)->color;
	values.line_width = ((ppart->pen)+pinstr->instrc.pen_num-1)->linewidth;
	XChangeGC(display, ppart->gc, valueMask, &values);
	break;

      case CHANGE_COLOR_TYPE:
	valueMask = GCForeground;
	values.foreground = (ppart->color) [pinstr->instrc.color_num-1];
	XChangeGC(display, ppart->gc, valueMask, &values);
	break;

      case CHANGE_LINE_WIDTH_TYPE:
	valueMask = GCLineWidth;
	values.line_width = pinstr->instrc.line_width == 1 ? 0 :
	                                       pinstr->instrc.line_width;
	XChangeGC(display, ppart->gc, valueMask, &values);
	break;

      default:
	XtError("ZDr2d - instruction type not implemented");
      };

    /*** Display sub-objects ***/

    displayobj(w, object->sub_object);            /*** Display sub-objects ***/
    object = object->next;                           /*** try the next one ***/
  }
}

/*****************************************************************************/
static void
removeobj(
	  ZDr2dWidget  w, 
	  GR_OBJECT   *object)
{
  register INSTRUCTION  *pinstr;
  register GR_OBJECT    *obj, *child_obj;

  obj = object;
  for (child_obj = obj->sub_object; child_obj; child_obj = child_obj->next) {
    removeobj(w, child_obj);
    for (pinstr = obj->instructions; pinstr; pinstr = pinstr->next)
      switch (pinstr->instruction_type) {
      case POLYLINE_TYPE: 
	XtFree((char *)pinstr->X11_buf);
	XtFree((char *)pinstr->instrc.poly_line);
	break;
      case CHANGE_PEN_TYPE:
      case CHANGE_COLOR_TYPE:
      case CHANGE_LINE_WIDTH_TYPE:
	break;

      default:
	XtError("ZDr2d - corrupted instructions");
      }
  }
  XtFree((char *)object);
}


/*****************************************************************************
 * Description of the following routines ins in ZDr2d.h file 
 *****************************************************************************/

/*****************************************************************************/
char *
XZDr2dNewObject(
		Widget         wdg,
		XtPointer      obj_id,
		int            pen_num,
		XtPointer      parent_obj_id,
		ZDR2D_MATRIX  *matrix)
{
  register GR_OBJECT    *parobj;
  register GR_OBJECT    *gobj;
  ZDr2dWidget            w;

  XZDr2dFinishObject(wdg);  
  w = (ZDr2dWidget)wdg;

  if (find_object(w->zDr2d.objects, obj_id))
    return("Object alredy exists");

  gobj = XtNew(GR_OBJECT);
  memset((void *)gobj, 0, sizeof(GR_OBJECT));
  gobj->objid = obj_id;

  if (!parent_obj_id) {                 /* object attached directly to scene */
    if (!w->zDr2d.objects)
      w->zDr2d.objects = gobj;
    else {
      for (parobj = w->zDr2d.objects; parobj->next; parobj = parobj->next)
	;
      parobj->next = gobj;
    }
  }
  else if (parobj = find_object(w->zDr2d.objects, parent_obj_id)) {
    if (!parobj->sub_object)
      parobj->sub_object = gobj;
    else {
      for (parobj = parobj->sub_object; parobj->next; parobj = parobj->next)
	;
      parobj->next = gobj;
    }
  }
  else {
    XtFree((char *)gobj);
    return("Cannot find parent object");
  }
  w->zDr2d.current_object = gobj;
  w->zDr2d.current_instr = (INSTRUCTION *)NULL;
  if (pen_num < 0 || pen_num > NPEN) {
    XtWarning("Wrong pen number");
    pen_num = 0;
  }
  if (pen_num)
    XZDr2dChangePen(wdg, pen_num);

  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dFinishObject(
		Widget         wdg)
{
  finishinstruction((ZDr2dWidget)wdg);
  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dRenderScene(
		  Widget  wdg,
		  Boolean paint_immediately)
{
  ZDr2dWidget            w;

  w = (ZDr2dWidget)wdg;
  if (w->zDr2d.render = paint_immediately)
    Resize((Widget)w);
  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dChangePen(
		Widget wdg,
		int    pen_num)
{
  ZDr2dWidget            w;
  register INSTRUCTION  *inst;

  w = (ZDr2dWidget)wdg;

  inst = newinstruction(w, CHANGE_PEN_TYPE);
  inst->instrc.pen_num = pen_num;
  w->zDr2d.lastwasmove = True;                                 /* dummy move */
  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dChangeColor(
		  Widget wdg,
		  int    color_num)
{
  ZDr2dWidget            w;
  register INSTRUCTION  *inst;

  w = (ZDr2dWidget)wdg;

  inst = newinstruction(w, CHANGE_COLOR_TYPE);
  inst->instrc.color_num = color_num;
  w->zDr2d.lastwasmove = True;                                 /* dummy move */
  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dChangeLineWidth(
		  Widget    wdg,
		  Dimension width)
{
  ZDr2dWidget            w;
  register INSTRUCTION  *inst;

  w = (ZDr2dWidget)wdg;

  inst = newinstruction(w, CHANGE_LINE_WIDTH_TYPE);
  inst->instrc.line_width = width;
  w->zDr2d.lastwasmove = True;                                 /* dummy move */
  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dLineto(
	     Widget wdg,
	     float x,
	     float y)
{
  ZDr2dWidget   w;
  GR_OBJECT    *obj;
  INSTRUCTION  *instr;

  w = (ZDr2dWidget)wdg;
  if (!(obj = w->zDr2d.current_object))
    return("XZDr2dNewObject not called");

  instr = w->zDr2d.current_instr;
  if (!w->zDr2d.lastwasmove &&
      (!instr || instr->instruction_type != POLYLINE_TYPE))
    return("Unknown starting point position");

  if      (!w->zDr2d.lastwasmove && instr &&
	   instr->instruction_type == POLYLINE_TYPE)
    addpolylinepoint(w, x, y);
  else if (w->zDr2d.lastwasmove) {
    newinstruction(w, POLYLINE_TYPE);
    addpolylinepoint(w, w->zDr2d.current_pointx,
		     w->zDr2d.current_pointy);
    addpolylinepoint(w, x, y);
  }
  else
    return("ZDr2d wrong status - painting corrupted");


  w->zDr2d.lastwasmove = False;
  w->zDr2d.current_pointx = x;
  w->zDr2d.current_pointy = y;
  return((char *)NULL);
}


/*****************************************************************************/
char *
XZDr2dMoveto(
	     Widget wdg,
	     float  x,
	     float  y)
{
  GR_OBJECT             *obj;
  INSTRUCTION           *instr;
  register ZDr2dWidget   w;

  w = (ZDr2dWidget)wdg;

  if (!(obj = w->zDr2d.current_object))
    return("XZDr2dNewObject not called");

  w->zDr2d.lastwasmove = True;
  w->zDr2d.current_pointx = x;
  w->zDr2d.current_pointy = y;
  return((char *)NULL);
}


/*****************************************************************************/
static INSTRUCTION *
newinstruction(
	       ZDr2dWidget w,
	       int         instruction_type)
{
  register ZDr2dPart      *ppart;
  register INSTRUCTION    *instr;

  finishinstruction(w);

  ppart = &(w->zDr2d);
  instr = XtNew(INSTRUCTION);
  memset((void *)instr, 0, sizeof(INSTRUCTION));
  instr->instruction_type = instruction_type;

  if (ppart->current_instr)
    ppart->current_instr->next = instr;
  else
    ppart->current_object->instructions = instr;
  ppart->current_instr = instr;
  return(instr);
}


/*****************************************************************************/
static void
finishinstruction(
		  ZDr2dWidget w)
{
  register INSTRUCTION  *curinst;
  int                    size;
  register ZDr2dPart    *ppart;

  ppart = &(w->zDr2d);
  if (!(curinst = ppart->current_instr))
    return;

  switch (curinst->instruction_type) {
  case POLYLINE_TYPE:
    size = sizeof(POLYLINE);
    curinst->instrc.poly_line =
      (POLYLINE *)XtRealloc((char *)curinst->instrc.poly_line,
			    size * curinst->n_subinstructions);
    break;

  case CHANGE_PEN_TYPE:
  case CHANGE_COLOR_TYPE:
  case CHANGE_LINE_WIDTH_TYPE:
    break;
	
  default:
    XtError("ZDr2d - data corrupted");
  }
  ppart->free_slots = 0;
}


/*****************************************************************************/
static void
addpolylinepoint(
		 ZDr2dWidget  w,
		 float        x,
		 float        y)
{
  register INSTRUCTION       *curinst;
  register ZDr2dPart         *ppart;

  ppart = &(w->zDr2d);

  if      (!(curinst = ppart->current_instr)->instrc.poly_line) {
    curinst->instrc.poly_line = (POLYLINE *)XtMalloc(sizeof(POLYLINE) * POOL);
    ppart->free_slots = POOL;
  }
  else if (!ppart->free_slots) {
    curinst->instrc.poly_line = (POLYLINE *)XtRealloc(
		       (char *)curinst->instrc.poly_line,
		       sizeof(POLYLINE) * (curinst->n_subinstructions + POOL));
    ppart->free_slots = POOL;
  }
  (curinst->instrc.poly_line+curinst->n_subinstructions)->x = x;
  (curinst->instrc.poly_line+curinst->n_subinstructions)->y = y;
  ++curinst->n_subinstructions;
  --ppart->free_slots;
}


/*****************************************************************************/
extern char *
XZDr2dPostscript(                                 /* creates Postscript file */
		 Widget w,
		 int    portrait_mode,               /* portrait orientation */
		 FILE  *psfile)
{
  register GR_OBJECT      *object;
  register ZDr2dPart      *ppart;
  Boolean                  shift;
  float                    shift_x, shift_y;
  float                    scale;
  char                    *errmsg;

  ppart = &(((ZDr2dWidget)w)->zDr2d);

  if (errmsg = ps_init((ZDr2dWidget)w, portrait_mode, psfile))
    return(errmsg);

  for (object = ((ZDr2dWidget)w)->zDr2d.objects;
           object; object = object->next)
    ps_interpret((ZDr2dWidget)w, object);

  ps_finish();
  return((char *)NULL);
}




/******************************************************************************
/******************************************************************************
  ps_driver

REMEMBER: coordinate system used is:

y
^
|
|
|
|
|
|
--------------------------> x

Currently ONLY A4 page implemented

******************************************************************************/

#define MAXSEGMENTS       1000               /* max # of ps path */
#define MOVETHRESHOLD      200        /* drawing interrupted preferably here */

#define A4_X            (float)210.0         /* A4 page  [mm] */
#define A4_Y            (float)297.0
#define A3_X            (float)297.0         /* A4 page  [mm] */
#define A3_Y            (float)420.0
#define MM_TO_INCH      (float)(1.0/25.4)    /* mm to Inch ratio */
#define PS_UNIT         (float)72.0          /* 1/72 INCH postscript unit */

/*** BUT remeber postscript printers cannot cover the whole page
     THERE IS a BLANKAREA near the edges of the paper which can be addressed,
     but is NOT printed
***/

#define BLANKAREA    (float)10               /* in [mm] */

#define PSBLANKAREA  BLANKAREA * MM_TO_INCH
#define PSMINX       PSBLANKAREA 
#define PSMINY       PSBLANKAREA
#define PSMAXX       A4_XPS - PSBLANKAREA 
#define PSMAXY       A4_YPS - PSBLANKAREA 

static FILE     *psFile;
static Boolean   portrait_mode;
static float     psScale;
static float     ps_scene_shift_vector [2];
static float     ps_scene_rot_matrix [2] [2];
static int       max_segments;
static float     pslastx, pslasty;    /* last position (for broken polygons) */
static char     *psLineWidth = "0.5",
                *psDashPattern = "[] 0";

/*****************************************************************************/
static char *
ps_interpret(
	     ZDr2dWidget      w,
	     GR_OBJECT       *object)
{
  register INSTRUCTION    *pinstr;
  register GR_OBJECT      *obj;
  register ZDr2dPart      *ppart;
  float                    x, y, shift_x, shift_y;

  ppart = &(((ZDr2dWidget)w)->zDr2d);
  if (ppart->shift_to_min) {
    shift_x = ppart->min_x;
    shift_y = ppart->min_y;
  }
  else
    shift_x = shift_y = 0.0;

  for (pinstr = object->instructions; pinstr; pinstr = pinstr->next)
      switch (pinstr->instruction_type) {
      case POLYLINE_TYPE: {
	  register POLYLINE *ppoly;
	  register int       i;

	  ppoly = pinstr->instrc.poly_line;
	  for (i = pinstr->n_subinstructions; i; --i, ++ppoly) {
	    if (w->zDr2d.origin == ZDr2dSouthWest) {
	      x = (ppoly->x - shift_x) * ps_scene_rot_matrix [0] [0] +
	          (ppoly->y - shift_y) * ps_scene_rot_matrix [0] [1] +
		  ps_scene_shift_vector [0];
	      y = (ppoly->x - shift_x) * ps_scene_rot_matrix [1] [0] +
	          (ppoly->y - shift_y) * ps_scene_rot_matrix [1] [1] +
		  ps_scene_shift_vector [1];
	    }
	    else {
	      x = (ppoly->x - shift_x) * ps_scene_rot_matrix [0] [0] +
	          (ppart->max_y - ppoly->y)* ps_scene_rot_matrix [0] [1] +
		  ps_scene_shift_vector [0];
	      y = (ppoly->x - shift_x) * ps_scene_rot_matrix [1] [0] +
	          (ppart->max_y - ppoly->y) * ps_scene_rot_matrix [1] [1] +
		  ps_scene_shift_vector [1];
	    }
	    if (i == pinstr->n_subinstructions)
	      ps_moveto(x, y);
	    else
	      ps_lineto(x, y);
	  }
	}
	break;

      case CHANGE_PEN_TYPE:
	fprintf(psFile, "S newpath %s\n",
		(ppart->ps_pen) [pinstr->instrc.pen_num - 1]);
	break;

      case CHANGE_COLOR_TYPE:
	fprintf(psFile, "S newpath %s\n",
		(ppart->ps_color) [pinstr->instrc.color_num - 1]);
	break;

      case CHANGE_LINE_WIDTH_TYPE:
	fprintf(psFile, "S newpath %f setlinewidth\n",
		ppart->ps_basic_line_width * (float)pinstr->instrc.line_width);
	break;

      default:
	XtError("ZDr2d - instruction type not implemented");
      };
	

  for (obj = object->sub_object; obj; obj->next)
    ps_interpret(w, obj);
  return(NULL);
}


/*****************************************************************************/
static char *
ps_init(
	ZDr2dWidget  w,
	int          portraitmode,
	FILE  *psout)
{
  register ZDr2dPart   *ppart;
  float                 angle, sina, cosa, maxx, maxy, maxytmp;
  float                 paper_x_offset, paper_y_offset, paper_rotation;
  int                   row, col;

  if (!psout)
    return("Postscript output (file) not available");

  ppart = &(w->zDr2d);
  psFile = psout;
  portrait_mode = portraitmode;
  max_segments = MAXSEGMENTS;


  angle = (ppart->orientation / 180.0) * 3.14159;          /* deg -> radians */
  sina = sin(angle);
  cosa = cos(angle);

  ps_scene_rot_matrix [0] [0] =  cosa;
  ps_scene_rot_matrix [0] [1] = -sina;  
  ps_scene_rot_matrix [1] [0] =  sina;
  ps_scene_rot_matrix [1] [1] =  cosa;

  maxx = ppart->max_x; maxy = ppart->max_y;
  if (ppart->shift_to_min) {
    maxx -= ppart->min_x;
    maxy -= ppart->min_y;
  }
  if      (cosa >= 0.0 && sina >= 0.0) {
    ps_scene_shift_vector [0] = maxy * sina;
    ps_scene_shift_vector [1] = 0.0;
  }
  else if (cosa < 0.0 && sina >= 0.0) {
    ps_scene_shift_vector [0] = -maxx * cosa + maxy * sina;
    ps_scene_shift_vector [1] = -maxy * cosa;
  }
  else if (cosa >= 0.0 && sina < 0.0) {
    ps_scene_shift_vector [0] = 0.0;
    ps_scene_shift_vector [1] = -maxx * sina;
  }
  else {
    ps_scene_shift_vector [0] = -maxx * cosa;
    ps_scene_shift_vector [1] = -maxx * sina - maxy * cosa;
  }

  if (sina < 0.0) sina = -sina;
  if (cosa < 0.0) cosa = -cosa;

  maxytmp = maxy * cosa + maxx * sina;            /* maxima after rotation */
  maxx = (maxx * cosa + maxy * sina);
  maxy = maxytmp;

  if (!maxx || !maxy) {
      ps_finish();
      return("Picture has a zero dimension.");
    }

  if (ppart->abs_scale) {
    psScale = MM_TO_INCH * PS_UNIT * ppart->scale;
    if (portrait_mode &&
	((maxx * ppart->scale) > A4_X - 2.0 * BLANKAREA ||
	 (maxy * ppart->scale) > A4_Y - 2.0 * BLANKAREA    )   ||
       !portrait_mode &&
	((maxx * ppart->scale) > A4_Y - 2.0 * BLANKAREA ||
	 (maxy * ppart->scale) > A4_X - 2.0 * BLANKAREA))
      return("\
Picture is bigger than paper.\n\
Change the paper orientation or the scale.");
  }
  else {                                                   /* relative scale */
    float      sx, sy;   /*temporary scales */

    if (portrait_mode) {
      sx = (A4_X - 2.0 * BLANKAREA) / maxx;
      sy = (A4_Y - 2.0 * BLANKAREA) / maxy;
      psScale = ((sx < sy) ? sx : sy) * MM_TO_INCH * PS_UNIT;
    }
    else {
      sy = (A4_Y - 2.0 * BLANKAREA) / maxx;
      sx = (A4_X - 2.0 * BLANKAREA) / maxy;
      psScale = ((sx < sy) ? sx : sy)  * MM_TO_INCH * PS_UNIT;
    }
  }

  if (portrait_mode) {
    paper_x_offset = paper_y_offset = BLANKAREA * MM_TO_INCH * PS_UNIT;
    paper_rotation = 0.0;
  }
  else {  /* landscape */
    paper_x_offset = (A4_X - BLANKAREA)  * MM_TO_INCH * PS_UNIT;
    paper_y_offset = BLANKAREA * MM_TO_INCH * PS_UNIT;
    paper_rotation = 90.0;
  }

  ps_scene_shift_vector [0] *= psScale;
  ps_scene_shift_vector [1] *= psScale;

  for (row = 0; row < 2; ++row)
    for (col = 0; col < 2; ++col)
      ps_scene_rot_matrix [row] [col] *= psScale;

  if (psFile)
    fprintf(psFile,
"%%!PS\n\
/S { stroke } def\n\
/M { moveto } def\n\
/L { lineto } def\n\
\n\
%%#######################################################################\n\
%%# Please correct next three lines to obtain the desired efect:\n\
%%#\n\
%f %f translate\n\
%f rotate\n\
1 1 scale\n\
%%#\n\
%%# Remeber, this file finishes by `showpage`\n\
%%#######################################################################\n\
\n\
newpath\n\
%s\n",
       paper_x_offset, paper_y_offset, paper_rotation, ppart->ps_default_attr);
return((char *)NULL);
}
      

/************************************************************************/
static char *
ps_finish()
{
  if (psFile) {
    fprintf(psFile,"S\nshowpage\n");
    psFile = NULL;
  }
  return(NULL);
}


/************************************************************************/
static char *
ps_moveto(
	  float x,
	  float y)
{
  float       fx, fy;

  if (max_segments <= MOVETHRESHOLD) {
    fprintf(psFile, "S\nnewpath\n");
    max_segments = MAXSEGMENTS;
  }
  else
    --max_segments;

  fx = x;
  fy = y;
  pslastx = fx; pslasty = fy;
  fprintf(psFile, "%-7.2f %-7.2f M\n", fx, fy);
  return(NULL);
}


/************************************************************************/
static char *
ps_lineto(
	  float  x,
	  float  y)
{
  float      fx, fy;

  if (max_segments <= 0) {
    fprintf(psFile, "S\nnewpath\n");
    fprintf(psFile, "%-7.2f %-7.2f M\n", pslastx, pslasty);
    max_segments = MAXSEGMENTS;
  }
  else
    --max_segments;

  fx = x;
  fy = y;
  pslastx = fx; pslasty = fy;
  fprintf(psFile, "%-7.2f %-7.2f L\n", fx, fy);
  return(NULL);
}
