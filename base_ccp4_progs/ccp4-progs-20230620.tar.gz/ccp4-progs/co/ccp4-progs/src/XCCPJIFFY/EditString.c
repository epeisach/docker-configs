/***********************************************************
  EditString.c
  IVersion Z191191

***********************************************************/

#define ASCII_DISK     /* for AsciiSrcP.h structure */

#include "EditStringP.h"
#include <string.h>
#include <ctype.h>

#ifdef GETLASTPOS
#undef GETLASTPOS
#endif

#define GETLASTPOS(ctx)  XawTextSourceScan(((TextWidget)ctx)->text.source, 0, \
                                      XawstAll, XawsdRight, 1, TRUE)

#define INTEGER             1
#define FLOAT               2
#define STRING              3

static XtResource resources[] = {

#define offset(field)    XtOffset(EditStringWidget, editString.field)
  /* {name, class, type, size, offset, default_type, default_addr}, */

  { XtNformatString, XtCString, XtRString, sizeof(String),
    offset(format_string), XtRString, "%10s" },
  { XtNstring, XtCString, XtRString, sizeof(String),
    offset(string), XtRString, NULL },
  { XtNlength, XtCLength, XtRInt, sizeof(int),
    offset(string_length), XtRInt, 0 },
  { XtNuseStringInPlace, XtCUseStringInPlace, XtRBoolean, sizeof(Boolean),
    offset(use_string_in_place), XtRBoolean, False },
  { XtNnewString, XtCString, XtRString, sizeof(String),
    offset(new_string), XtRString, NULL},
  { XtNfloatValue, XtCFloatValue, XtRFloat, sizeof(float),
    offset(float_value), XtRFloat, NULL},
  { XtNintValue, XtCIntValue, XtRInt, sizeof(int),
    offset(int_value), XtRInt, NULL},
  { XtNcheckFunction, XtCCheckFunction, XtRPointer, sizeof(CheckFunction),
    offset(check_function), XtRPointer, NULL},

  /*** Some usefull callbacks ***/

  { XtNvalueChangeCallback, XtCCallback, XtRCallback, sizeof(XtCallbackList),
    offset(value_change_callback), XtRCallback, NULL},
  { XtNleaveNotifyCallback, XtCCallback, XtRCallback, sizeof(XtCallbackList),
    offset(leave_callback), XtRCallback, NULL},
  { XtNenterPressCallback, XtCCallback, XtRCallback, sizeof(XtCallbackList),
    offset(enterpress_callback), XtRCallback, NULL}
#undef offset
};

static char string_translations[] =
  "<Key>Left:      backward-character() curs_pos()    \n\
   <Key>Right:     forward-character()  curs_pos()    \n\
   <Btn1Down>:     select-start()                     \n\
   <Btn1Motion>:   extend-adjust()                    \n\
   <Btn1Up>:       extend-end(PRIMARY, CUT_BUFFER0) curs_pos()   \n\
   <Btn2Down>:     select-start() edit_string_insert-selection() \n\
   <Btn2Up>:       curs_pos()                         \n\
   <Btn3Down>:     select-start()                     \n\
   <Btn3Motion>:   extend-adjust()                    \n\
   <Btn3Up>:       extend-end(PRIMARY, CUT_BUFFER0) curs_pos()   \n\
   <Key>Delete:    edit_delete()                      \n\
   <Key>BackSpace: edit_delete()                      \n\
   <Key>Return:    enter_press()                      \n\
   <Key>Linefeed:  no-op(RingBell)                    \n\
   <Key>Tab:       select_all()                       \n\
   <Key>Escape:    no-op(RingBell)                    \n\
   <Key>KP_Enter:  enter_press()                      \n\
   None<Key>:      edit_insert()                      \n\
   !Shift<Key>:    edit_insert()                      \n\
   <Key>:          no-op(RingBell)                    \n\
   <EnterNotify>:  highlight()                        \n\
   <LeaveNotify>:  un_highlight() leave()             \n\
";

static void         initialize(
		         Widget     request,
		         Widget     new,
		         ArgList    args,
		         Cardinal  *num_args
			 );

static void         destroy(
			 Widget       w
			 );

static Boolean      setValues(
			 Widget       current,
			 Widget       request,
			 Widget       new,
			 ArgList      args,
			 Cardinal    *num_args
			 );

static void         change_width(
			 Widget       w
			 );

static void         edit_insert(
			 Widget       w,
			 XEvent      *event,
			 String      *params,
			 Cardinal    *num_params
			 );
static void         insert_string(
			 Widget       ctx,
			 char        *input,
			 int          count
			 );
static void         edit_delete(
			 Widget      w,
			 XEvent     *event,
			 String     *params,
			 Cardinal   *num_params
			 );

static void         highlight(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );

static void         un_highlight(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );

static void         leave(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );
static void         enter_press(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );
static void         curs_pos(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );
static void         select_all(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );

static void         removespaces(
			 String        s
			 );

static void         updatevalues(
		          Widget       w
		          );
static Boolean      isblank_es(
		          char        *s
		          );
static void         eds_ins_selection(
			 Widget        w,
			 XEvent       *event,
			 String       *params,
			 Cardinal     *num_params
			 );
static void         receive_string(
			 Widget       w,
			 XtPointer    client_data,
			 Atom        *selection,
			 Atom        *type,
			 XtPointer    value,
			 unsigned long *length,
			 int         *format
			 );

static XtActionsRec  private_actions [] = {
  {"edit_insert", edit_insert},
  {"edit_delete", edit_delete},
  {"highlight", highlight},
  {"un_highlight", un_highlight},
  {"leave", leave},
  {"enter_press", enter_press},
  {"edit_string_insert-selection", eds_ins_selection},
  {"curs_pos", curs_pos},
  {"select_all", select_all}
};

static XawTextSelectType  sel_array [] =
{XawselectPosition, XawselectNull};


EditStringClassRec editStringClassRec = {
  { /* core fields */
    /* superclass		*/	(WidgetClass) &asciiTextClassRec,
    /* class_name		*/	"EditString",
    /* widget_size		*/	sizeof(EditStringRec),
    /* class_initialize		*/	NULL,
    /* class_part_initialize	*/	NULL,
    /* class_inited		*/	FALSE,
    /* initialize		*/	initialize,
    /* initialize_hook		*/	NULL,
    /* realize			*/	XtInheritRealize,
    /* actions			*/	private_actions,
    /* num_actions		*/	XtNumber(private_actions),
    /* resources		*/	resources,
    /* num_resources		*/	XtNumber(resources),
    /* xrm_class		*/	NULLQUARK,
    /* compress_motion		*/	TRUE,
    /* compress_exposure	*/	TRUE,
    /* compress_enterleave	*/	TRUE,
    /* visible_interest		*/	FALSE,
    /* destroy			*/	destroy,
    /* resize			*/	XtInheritResize,
    /* expose			*/	XtInheritExpose,
    /* set_values		*/	setValues,
    /* set_values_hook		*/	NULL,
    /* set_values_almost	*/	XtInheritSetValuesAlmost,
    /* get_values_hook		*/	NULL,
    /* accept_focus		*/	XtInheritAcceptFocus,
    /* version			*/	XtVersion,
    /* callback_private		*/	NULL,
    /* tm_table			*/	string_translations,
    /* query_geometry		*/	XtInheritQueryGeometry,
    /* display_accelerator	*/	XtInheritDisplayAccelerator,
    /* extension		*/	NULL
  },

  { /* simple fields */
    /* change_sensitive */              XtInheritChangeSensitive
  },
  { /* text fields */
    /* empty */                         0
  },
  { /* ascii fields */
    /* empty */                         0
  },

  { /* editString fields */
    /* empty */	                        0
  }
};


WidgetClass editStringWidgetClass = (WidgetClass)&editStringClassRec;


static char                   space_char [] = {' ','\0'};
static XawTextBlock           new_input,
                              no_input = {0, 0, NULL, 0},
                              space_input = {0, 1, space_char, 0};

/***********************************************************/
static void
initialize(
	   Widget     request,
	   Widget     new,
	   ArgList    args,
	   Cardinal  *num_args)
{
  register EditStringPart      *espn;

  espn = &(((EditStringWidget)new)->editString);

  if (!espn->use_string_in_place)
    XtError("editStringWidgetClass - you MUST useStringInPlace");

  espn->backup.format = space_input.format = new_input.format =
    no_input.format = FMT8BIT;

  espn->backup.ptr = espn->old_string = espn->new_string = (String)NULL;
  espn->backup.firstPos = 0;

  espn->format_string = XtNewString(espn->format_string);

  XtVaSetValues(new,
		      XtNselectTypes, sel_array,
		      XtNdisplayNonprinting, False,
		      NULL);
}


/***********************************************************/
static void
destroy(
	Widget  w)
{
  register EditStringPart      *esp;

  esp = &(((EditStringWidget)w)->editString);

  XtFree(esp->backup.ptr);
  XtFree(esp->old_string);
  XtFree(esp->new_string);
  XtFree(esp->format_string);
  XtRemoveAllCallbacks (w, XtNvalueChangeCallback);
  XtRemoveAllCallbacks (w, XtNleaveNotifyCallback);
  XtRemoveAllCallbacks (w, XtNenterPressCallback);
}


/***********************************************************/
static Boolean
setValues(
	  Widget       current,
	  Widget       request,
	  Widget       new,
	  ArgList      args,
	  Cardinal    *num_args
	  )
{
  register EditStringPart      *espn, *espr, *espc;
  char                          tmpbuf [1001], *pc;
  static char                  *actualstring;

  espc = &(((EditStringWidget)current)->editString);
  espr = &(((EditStringWidget)request)->editString);
  espn = &(((EditStringWidget)new)->editString);

  /*** Important changes ***/

  if (!espc->old_string ||                    /* called from initialize */
      espc->format_string != espr->format_string || /* format chnged */
      espr->string != espn->old_string) {    /* string changed */

    /*** Format ***/

    espn->format_string = XtNewString(espr->format_string);
    espn->isright_justified = (*(espn->format_string+1) == '-') ? False : True;
    for (pc = espn->format_string + 1; *pc && !isalpha(*pc); ++pc)
      ;
    switch (*pc) {
    case 'd':      espn->data_type = INTEGER;
                   break;
    case 'f':      espn->data_type = FLOAT;
                   break;
    case 's':      espn->data_type = STRING;
                   break;
    default:       XtError("editStringWidgetClass - bad format string");
                   break;
    };

    /*** Setup buffer ***/

    espn->string = espr->string;

    switch(espn->data_type) {
    case INTEGER:   sscanf(espn->string, "%d", &espn->int_value);
                    sprintf(tmpbuf, espn->format_string, espn->int_value);
                    espn->new_string = XtMalloc(100);
                    sprintf(espn->new_string, "%d", espn->int_value);
                    break;
    case FLOAT:     sscanf(espn->string, "%f", &espn->float_value);
                    sprintf(tmpbuf, espn->format_string, espn->float_value);
                    espn->new_string = XtMalloc(100);
                    sprintf(espn->new_string, "%f", espn->float_value);
                    break;
    case STRING:    actualstring = espn->string ? espn->string : "";
                    sprintf(tmpbuf, espn->format_string, actualstring);
                    espn->new_string = XtNewString(tmpbuf);
                    removespaces(espn->new_string);
                    break;
    }

    espn->string = (String)NULL;
    espn->string_length = strlen(tmpbuf);
    espn->old_string = XtNewString(tmpbuf);
    espn->backup.ptr = XtNewString(espn->old_string);
    removespaces(espn->backup.ptr);
    espn->backup.length = strlen(espn->backup.ptr);
    XtVaSetValues(new, XtNlength, espn->string_length,
		       XtNstring, espn->old_string,
		       NULL);
    XtVaSetValues(new, XtNlength, espn->string_length, /* God knows why 2x */
		       XtNstring, espn->old_string,
		       NULL);
    removespaces(espn->old_string);
    XawTextSetInsertionPoint(new, zeroPosition);
    XawTextReplace(new, zeroPosition, GETLASTPOS(new), &(espn->backup));
    if (espn->isright_justified)
      XawTextSetInsertionPoint(new, GETLASTPOS(new));

    XtFree(espc->backup.ptr);
    XtFree(espc->old_string);
    XtFree(espc->new_string);
    XtFree(espc->format_string);

  }
  change_width(new);
  return(True);      /* redraw */
}


/***********************************************************/
static void
edit_insert(
	    Widget        ctx,
	    XEvent       *event,
	    String       *params,
	    Cardinal     *num_params)
{
  char                          input [101];
  static int                    input_size = 100;
  KeySym                        keysym;
  XComposeStatus                compose;
  int                           count;
  TextSrcObject                 tsr;

  tsr = (TextSrcObject)((EditStringWidget)ctx)->text.source;

  if (tsr->textSrc.edit_mode == XawtextRead)
    return;

  count = XLookupString((XKeyEvent*)event, input, input_size,
			&keysym, &compose);
  input [count] = '\0';
  if (!count)
    return;

  insert_string(ctx, input, count);
}


/***********************************************************/
static void
insert_string(
	      Widget     ctx,
	      char      *input,
	      int        count)
{
  register EditStringPart      *esp;
  register char                *pc;
  register int                  i;

  new_input.firstPos = 0;
  new_input.ptr = input;
  new_input.format = FMT8BIT;
  new_input.length = count;

    
  esp = &(((EditStringWidget)ctx)->editString);

  esp->text_position = XawTextGetInsertionPoint(ctx);
  XtFree(esp->backup.ptr);
  esp->backup.ptr = XtNewString(esp->string);
  esp->backup.length = strlen(esp->backup.ptr);

  /*** Do insert ***/

  if (esp->isright_justified) {
    for (pc = esp->string, i = 0; *pc == ' '; ++pc, ++i)
      ;
    if (i < count) {        /* insert too long */
      XBell(XtDisplay(ctx), 100);
      return;
    }
    XawTextReplace(ctx, zeroPosition, count, &no_input);
    XawTextReplace(ctx, esp->text_position - count,
		   esp->text_position - count, &new_input);
    XawTextSetInsertionPoint(ctx, esp->text_position);
  }
  else {
    if ((strlen(esp->string) + count) > esp->string_length) { /* too long */
      XBell(XtDisplay(ctx), 100);
      return;
    }
    if (XawTextReplace(ctx, esp->text_position,
		       esp->text_position, &new_input) == XawEditDone)
      XawTextSetInsertionPoint(ctx, esp->text_position + count);
    else {
      XBell(XtDisplay(ctx), 100);
      return;
    }
  }
  
  updatevalues(ctx);             /* Update new values */
  return;
}


/***********************************************************/
static void
edit_delete(
	    Widget         ctx,
	    XEvent        *event,
	    String        *params,
	    Cardinal      *num_params)
{
  register EditStringPart      *esp;
  char                          c;
  TextSrcObject                 tsr;
  XawTextPosition               begin, end;
  int                           count, i;

  tsr = (TextSrcObject)((EditStringWidget)ctx)->text.source;
  esp = &(((EditStringWidget)ctx)->editString);

  if (tsr->textSrc.edit_mode == XawtextRead)
    return;

  XawTextGetSelectionPos(ctx, &begin, &end);

  if (count = (int)(end - begin)) {      /* selection made, delete selection */
    esp->text_position = begin;
    XawTextReplace(ctx, begin, end, &no_input);
    if (esp->isright_justified) {
      for (i = count; i; --i)
	XawTextReplace(ctx, zeroPosition, zeroPosition, &space_input);
      XawTextSetInsertionPoint(ctx, end);
    }
    else
      XawTextSetInsertionPoint(ctx, begin);
  }
  else {                        /* delete only one character */
    esp->text_position = XawTextGetInsertionPoint(ctx);
    XawTextReplace(ctx, esp->text_position-1, esp->text_position, &no_input);
    if (esp->isright_justified) {
      XawTextReplace(ctx, zeroPosition, zeroPosition, &space_input);
      XawTextSetInsertionPoint(ctx, esp->text_position);
    }
    else
      XawTextSetInsertionPoint(ctx, esp->text_position - 1);
  }

  updatevalues(ctx);
}


/***********************************************************/
static void
updatevalues(
	     Widget  ctx)
{
  register EditStringPart        *esp;
  float                           fval;
  int                             ival;
  char                            c;
  int                             scaned;
  Boolean                         appcheck;

  esp = &(((EditStringWidget)ctx)->editString);
  scaned = 1;                    /* assume o.k. */
  c = '\0';

  /*** Syntax analysis ***/

  switch (esp->data_type) {
  case INTEGER:    scaned = sscanf(esp->string, "%d%c", &ival, &c);
                   break;
  case FLOAT:      scaned = sscanf(esp->string, "%f%c", &fval, &c);
                   break;
  case STRING:     break;
  };

  if (isblank_es(esp->string)) {
    ival = 0;
    fval = (float)0.0;
    scaned = 1;
  }

  appcheck = (esp->check_function) ? (*esp->check_function)(esp->string) :
                                     True;
  if (scaned != 1 || !appcheck) {
    XBell(XtDisplay(ctx), 100);
    XawTextReplace(ctx, zeroPosition, GETLASTPOS(ctx), &(esp->backup));
    XawTextSetInsertionPoint(ctx, esp->text_position);
    return;
  }

  switch (esp->data_type) {
  case INTEGER:    sprintf(esp->new_string, "%d", ival);
                   esp->int_value = ival;
                   esp->float_value = (float)ival;
                   break;
  case FLOAT:      sprintf(esp->new_string, "%f", fval);
                   esp->float_value = fval;
                   esp->int_value = (int)fval;
                   break;
  case STRING:     strcpy(esp->new_string, esp->old_string);
                   removespaces(esp->new_string);
                   break;
  };
  XtCallCallbacks(ctx, XtNvalueChangeCallback, NULL);
}


/***********************************************************/
static void
change_width(
	     Widget   w)
{
  XFontStruct             *edit_font_struct = (XFontStruct *)NULL;
  Dimension                edit_left_margin, edit_right_margin;
  Dimension                old_width, new_width;
  register EditStringPart *esp;

  esp = &(((EditStringWidget)w)->editString);

  XtVaGetValues(w,
		XtNfont, &edit_font_struct,
		XtNleftMargin, &edit_left_margin,
		XtNrightMargin, &edit_right_margin,
		XtNwidth, &old_width,
		NULL);
/*  new_width = edit_font_struct->max_bounds.width * (esp->string_length - 1) +*/
  new_width = edit_font_struct->max_bounds.width * esp->string_length +
			  edit_font_struct->max_bounds.width / 2 +
		          edit_left_margin + edit_right_margin;
  if (old_width != new_width)
    XtVaSetValues(w,
		XtNwidth, new_width,
		NULL);
}


/***********************************************************/
static void
removespaces(
	     String    s)
{
  register char        *pc;
  register int          i;

  for (pc = s + strlen(s) - 1; pc >= s && *pc == ' '; --pc)
    *pc = '\0';                   /* remove trailing spaces */
}


/***********************************************************/
static Boolean
isblank_es(
	char   *s)
{
  Boolean       signfound;
  Boolean       decpointfound;

  while (*s) {
    switch (*s) {
    case '.':   if (decpointfound)
                  return(False);
                decpointfound = True;
                break;
    case '+':
    case '-':   if (signfound)
                  return(False);
                signfound = True;
                break;
    case ' ':   break;
    default:    return(False);
    }
    ++s;
  }
  return(True);
}

/***********************************************************/
static void
highlight(
	  Widget       w,
	  XEvent      *event,
	  String      *params,
	  Cardinal    *num_params)
{
  Pixel          background,
                 foreground;
  TextSrcObject  tsr;
  TextSinkObject tsi;

  tsr = (TextSrcObject)((EditStringWidget)w)->text.source;
  tsi = (TextSinkObject)((EditStringWidget)w)->text.sink;
}

/***********************************************************/
static void
un_highlight(
	     Widget      w,
	     XEvent     *event,
	     String     *params,
	     Cardinal   *num_params)
{
  Pixel     background,
            foreground;
  TextSrcObject  tsr;

  tsr = (TextSrcObject)((EditStringWidget)w)->text.source;
}


/***********************************************************/
static void
leave(
      Widget     w,
      XEvent    *event,
      String    *params,
      Cardinal  *num_params)
{
  XtCallCallbacks(w, XtNleaveNotifyCallback, NULL);
}


/***********************************************************/
static void
enter_press(
	    Widget    w,
	    XEvent   *event,
	    String   *params,
	    Cardinal *num_params)
{
  XtCallCallbacks(w, XtNenterPressCallback, NULL);
}


/***********************************************************/
static void
select_all(
	   Widget      w,
	   XEvent     *event,
	   String     *params,
	   Cardinal   *num_params)
{
  register EditStringPart      *esp;

  XawTextSetSelection(w, zeroPosition, GETLASTPOS(w));
}


/***********************************************************/
static void
curs_pos(
	 Widget     w,
	 XEvent    *event,
	 String    *params,
	 Cardinal  *num_params)
{
  register EditStringPart      *esp;
  register char                *pc;

  esp = &(((EditStringWidget)w)->editString);

  if (esp->isright_justified &&
          (esp->data_type == INTEGER ||
	   esp->data_type == FLOAT)     ) {
    esp->text_position = XawTextGetInsertionPoint(w);
    for (pc = esp->string + esp->text_position; *(pc) == ' '; ++pc)
      ;
    esp->text_position = pc - esp->string;
    XawTextSetInsertionPoint(w, esp->text_position);
  }
}


/***********************************************************/
static void
eds_ins_selection(
		  Widget     w,
		  XEvent    *event,
		  String    *params,
		  Cardinal  *num_params)
{
  TextSrcObject                 tsr;

  tsr = (TextSrcObject)((EditStringWidget)w)->text.source;

  if (tsr->textSrc.edit_mode == XawtextRead)
    return;

  XtGetSelectionValue(w, XA_PRIMARY, XA_STRING,
		      receive_string,
		      (XtPointer)NULL, ((XButtonEvent*)event)->time);
}


/***********************************************************/
static void
receive_string(
	       Widget                 w,
	       XtPointer              client_data,
	       Atom                  *selection,
	       Atom                  *type,
	       XtPointer              value,
	       unsigned long         *length,
	       int                   *format)
{
  insert_string(w, (char *)value, (int)*length);
  XtFree(value);
}
