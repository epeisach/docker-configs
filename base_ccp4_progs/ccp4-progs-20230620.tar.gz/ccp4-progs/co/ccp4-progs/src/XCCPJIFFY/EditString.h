/***********************************************************
  EditString.h
  IVersion Z191191

***********************************************************/


#ifndef _EditString_h
#define _EditString_h

#include <X11/Xaw/AsciiText.h>
/****************************************************************
 *
 * EditString widget
 *
 ****************************************************************/

/* Resources from superclass:

 Name		     Class		RepType		Default Value
 ----		     -----		-------		-------------
 background	     Background		Pixel		XtDefaultBackground
 border		     BorderColor	Pixel		XtDefaultForeground
 borderWidth	     BorderWidth	Dimension	1
 destroyCallback     Callback		Pointer		NULL
 displayPosition     TextPosition	int		0
 editType	     EditType		XawTextEditType	XawtextRead
 font		     Font		XFontStruct*	Fixed
 foreground	     Foreground		Pixel		Black
 height		     Height		Dimension	font height
 insertPosition	     TextPosition	int		0
 leftMargin	     Margin		Dimension	2
 mappedWhenManaged   MappedWhenManaged	Boolean		True
 selectTypes	     SelectTypes	Pointer		(internal)
 selection	     Selection		Pointer		empty selection
 sensitive	     Sensitive		Boolean		True
 string		     String		String		NULL
 textOptions	     TextOptions	int		0
 width		     Width		Dimension	100
 x		     Position		Position	0
 y		     Position		Position	0

 *** Edit String ***
 formatString        String             String          NULL
 newString           String             String          current value
 floatValue          FloatValue         float           current value
 intValue            IntValue           int             current value

 valueChangeCallback Callback           Callback        NULL
 leaveNotifyCallback Callback           Callback        NULL
 enterPressCallback  Callback           Callback        NULL
 checkFunction       CheckFunction      CheckFunction   NULL
 
*/

typedef Boolean (*CheckFunction)(
				 String      s
				 );

/* define any special resource names here that are not in superclass */

#ifndef XtNformatString
#define XtNformatString                "formatString"
#endif

#define XtNnewString                   "newString"
#define XtNfloatValue                  "floatValue"
#define XtNintValue                    "intValue"
#define XtNvalueChangeCallback         "valueChangeCallback"
#define XtNleaveNotifyCallback         "leaveNotifyCallback"
#define XtNenterPressCallback          "enterPressCallback"
#define XtNcheckFunction               "checkFunction"

#define XtCFloatValue                  "FloatValue"
#define XtCIntValue                    "IntValue"
#define XtCCheckFunction               "CheckFunction"

/*** String format has one of the following values ***
  %nd   %nf  %ns  - where n is int denoting the length of the string
 ***                                               ***/
/*** Following are the read only resources         ***
  newString, floatValue, intValue
  

 * declare specific EditStringWidget class and instance datatypes */

typedef struct _EditStringClassRec*	EditStringWidgetClass;
typedef struct _EditStringRec*		EditStringWidget;

/* declare the class constant */

extern WidgetClass editStringWidgetClass;

#endif /* _EditString_h */
