/******************************************************************************
  ZDr2d.h
  Z200592

Public header file for ZDr2d widget
******************************************************************************/

#ifndef  _ZDr2d_h
#define  _ZDr2d_h

#include <X11/Intrinsic.h>

/*** ZDr2d widget class resources ***/

#define XtCMargins                   "Margins"                  /* Type: int */
#define XtNhorizontalMargins         "horizontalMargins"
                          /* Horizontal margins around the picture in pixels */
#define XtNverticalMargins           "verticalMargins"
                            /* Vertical margins around the picture in pixels */

#define XtCSceneDsc                  "SceneDsc" /* Type: (ZDR2D_SCENE_DSC *) */
#define XtNsceneDsc                  "sceneDsc"
                                           /* MUST be set within create call */



/***
#define XtNcursorPositionCallback    "cursorPositionCallback"
***/

/*** 10 default pens are defined as: ***
#define XtCColor                                              * Type: Pixel */
#define XtCLineWidth                 "LineWidth"             /* Type: int */
#define XtCPsPenAttr                 "PsPenAttr"             /* Type: String */
#define XtCPsLineWidth               "PsLineWidth"           /* Type: int */
#define XtCPsColor                   "PsColor"               /* Type: String */
#define XtCPsBasicLineWidth          "PsBasicLineWidth"      /* Type: double */

#define XtNpen1Color                 "pen1Color"
#define XtNpen1LineWidth             "pen1LineWidth"
#define XtNpen2Color                 "pen2Color"
#define XtNpen2LineWidth             "pen2LineWidth"
#define XtNpen3Color                 "pen3Color"
#define XtNpen3LineWidth             "pen3LineWidth"
#define XtNpen4Color                 "pen4Color"
#define XtNpen4LineWidth             "pen4LineWidth"
#define XtNpen5Color                 "pen5Color"
#define XtNpen5LineWidth             "pen5LineWidth"
#define XtNpen6Color                 "pen6Color"
#define XtNpen6LineWidth             "pen6LineWidth"
#define XtNpen7Color                 "pen7Color"
#define XtNpen7LineWidth             "pen7LineWidth"
#define XtNpen8Color                 "pen8Color"
#define XtNpen8LineWidth             "pen8LineWidth"
#define XtNpen9Color                 "pen9Color"
#define XtNpen9LineWidth             "pen9LineWidth"
#define XtNpen10Color                "pen10Color"
#define XtNpen10LineWidth            "pen10LineWidth"

/*** 10 Postscript pens are defined as : ***/

#define XtNpsPen1Attr                "psPen1Attr"
#define XtNpsPen2Attr                "psPen2Attr"
#define XtNpsPen3Attr                "psPen3Attr"
#define XtNpsPen4Attr                "psPen4Attr"
#define XtNpsPen5Attr                "psPen5Attr"
#define XtNpsPen6Attr                "psPen6Attr"
#define XtNpsPen7Attr                "psPen7Attr"
#define XtNpsPen8Attr                "psPen8Attr"
#define XtNpsPen9Attr                "psPen9Attr"
#define XtNpsPen10Attr               "psPen10Attr"

/*** 10 colors used to refill pens ***/

#define XtNcolor1                    "color1"
#define XtNcolor2                    "color2"
#define XtNcolor3                    "color3"
#define XtNcolor4                    "color4"
#define XtNcolor5                    "color5"
#define XtNcolor6                    "color6"
#define XtNcolor7                    "color7"
#define XtNcolor8                    "color8"
#define XtNcolor9                    "color9"
#define XtNcolor10                   "color10"

/*** 10 Postscript commands used to modify colors ***/

#define XtNpsColor1                  "psColor1"
#define XtNpsColor2                  "psColor2"
#define XtNpsColor3                  "psColor3"
#define XtNpsColor4                  "psColor4"
#define XtNpsColor5                  "psColor5"
#define XtNpsColor6                  "psColor6"
#define XtNpsColor7                  "psColor7"
#define XtNpsColor8                  "psColor8"
#define XtNpsColor9                  "psColor9"
#define XtNpsColor10                 "psColor10"

/*** Basic Postscript line attributes set if pen number == 0 ***/

#define XtNpsDefaultAttr             "psDefaultAttr"

/*** Basic Postscript line width - will be multiplied by X11 line width ***/

#define XtNpsBasicLineWidth          "psBasicLineWidth"


extern WidgetClass zDr2dWidgetClass;

typedef struct _ZDr2dClassRec*   ZDr2dWidgetClass;
typedef struct _ZDr2dRec*        ZDr2dWidget;


/******************************************************************************
  Programatic interface
******************************************************************************/

/*** ZDr2d widgit scene description structure ***/

typedef enum {ZDr2dNorthWest, ZDr2dSouthWest} OriginPosition;

typedef struct ZDr2d_scene_dsc { /*** SEE XtNsceneDsc ***/
  char          *label;              /* scene label - not used now */
  float          minx, maxx,         /* will be used as maximum and minimum */
                 miny, maxy;         /* values of the scene. If all = 0.0, wid-
				        get will calculate something ... */
  Boolean        absolute_scale;     /* coordinates are supposed to be in mm,
					otherwise scaling is automatic */
  float          scale;              /* coeficient for absolute scale */
  Boolean        shift_to_min;       /* calculate real x, y as x-minx y-miny */
  OriginPosition origin;             /* Position of the origin point (0,0) -
				        recognizes 2 coordinate systems */
  Boolean        max_scene_size;     /* will dimension scene to fit the picture
					in any orientation, otherwise scene
					size is dimensioned to fit the picture
					given by limits and orientation */
  float          orientation;      /* scene orientation [deg anti-clockwise] */
} ZDR2D_SCENE_DSC;

typedef struct ZDr2d_matrix {
  int           empty_for_now;
} ZDR2D_MATRIX;

/*****************************************************************************/
/*** Following functions returns static error string */
/*****************************************************************************/

extern char *   XZDr2dNewObject(
			    Widget         w,
			    XtPointer      obj_id,
			    int            pen_num,
			    XtPointer      parent_obj_id,
			    ZDR2D_MATRIX  *matrix);
/*** MUST be called at least once. obj_id is suplied by user for further
     references, pen_num denotes the starting pen. If parent_obj_id == NULL
     object is a child of the scene
***/

extern char *   XZDr2dFinishObject(              /* finishes current object. */
			    Widget  w);/* XZDr2dNewObject does it implicitly */
                                   /* however, the last one MUST be finished */

extern char *   XZDr2dRenderScene(   /* Connect/disconnect scene to renderer */
			    Widget  w,
			    Boolean paint);

extern char *   XZDr2dChangePen(       /* will use the new pen as defined by */
			    Widget w,                   /* resource database */
			    int    pen_num);

extern char *   XZDr2dChangeColor(                  /* will change the color */
			    Widget w,
			    int    color_num);

extern char *   XZDr2dChangeLineWidth(             /* will change line width */
			    Widget w,
			    Dimension width);

extern char *   XZDr2dLineto(     /* Draws line from current point to (x, y) */
			    Widget w,
			    float  x,
			    float  y);

extern char *   XZDr2dMoveto(     /* moves dwawing point to the new position */
			    Widget w,
			    float  x,
			    float  y);
extern char *   XZDr2dPostscript(                 /* creates Postscript file */
			    Widget w,
			    int    portrait_mode,    /* portrait orientation */
			    FILE  *psfile);                /* where to write */

#endif /* _ZDr2d_h */
