/******************************************************************************
  log_file.c
  Z110992
******************************************************************************/

#define MAXTABLES 100
#define TABLE_KEYWORD    "$TABLE"
#define KEYTEXT_KEYWORD  "$KEYTEXT"
#define TEXT_KEYWORD     "$TEXT"
#define SUMMARY_KEYWORD  "$SUMMARY"
#define GRAPH_KEYWORD    "$GRAPHS"
#define DELIMITER        "$$"

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/AsciiText.h>
#include "ZDr2d.h"

#include "sys_includes.h"
#include "msg_box.h"
#include "hardcopy_ctrl.h"
#include "log_file.h"
#include "tom_fortran_interface.h"

extern XtTranslations   text_translations;

static void     my_quitCallback(
                        Widget              w,
                        XtPointer           shell,
                        XtPointer           garbage);

static void     my_plotCallback(
                        Widget              w,
                        XtPointer           plot_w,
                        XtPointer           garbage2);

static void     textPrintCallback(
                        Widget              w,
                        XtPointer           print_w,
                        XtPointer           garbage2);


typedef struct log_file_graph {
  struct log_file_graph *next;
  char                  *title;
  int                    graphtype;      /* graph type - see manual */
  float                  xlowlimit,      /* x value limits - low */
                         xhighlimit;     /* x value limits - high */
  float                  ylowlimit,      /* y value limits - low */
                         yhighlimit;     /* y value limits - high */
  int                    numcols;        /* # of table columns used in graph */
  int                   *col;            /* numbers of these columns */
} LOG_FILE_GRAPH;
  


typedef struct log_file_table {
  char                    *title;
  int                      n_cols;                      /* columns per table */
  char                   **column_names;    /* names of columns in the table */
  LOG_FILE_GRAPH          *graphs;                              /* -> graphs */
  char                   **graph_list;                /* list of graph names */
  int                      n_values;                     /* values per table */
  float                   *values;   /* floating representation of the table */
} LOG_FILE_TABLE;

typedef struct log_file_keytext {
  char                    *title;
  char                    *text_position; /* `any` text position in log file */
  int                      text_length;   /* `any` text length */
  char                    *keytext_position; /* keytext position in log file */
  int                      keytext_length;/* keytext length */
} LOG_FILE_KEYTEXT;

typedef struct log_file_text {
  char                    *title;
  char                    *text_position; /* text position in log file */
  int                      text_length;   /* text length */
} LOG_FILE_TEXT;


typedef enum {TEXT_TYPE, KEYTEXT_TYPE} SUMMARY_CONTENT_TYPE;

typedef struct summary_content {
  SUMMARY_CONTENT_TYPE   type;
  int                    index;
} SUMMARY_CONTENT;


typedef struct log_file_summary {
  char                    *title;
  int                      content_size;
  SUMMARY_CONTENT         *content;
  char                    *text_form;
} LOG_FILE_SUMMARY;


Widget                      current_draw_w;

static char                 *log_file_txt = "";
static LOG_FILE_TABLE       *log_file_tabs;
static char                **table_list = (char **)NULL;
static LOG_FILE_KEYTEXT     *log_file_keytxts;
static char                **keytext_list = (char **)NULL;
static LOG_FILE_TEXT        *log_file_txts;
static char                **text_list = (char **)NULL;
static LOG_FILE_SUMMARY    *log_file_summs;
static char                **summary_list = (char **)NULL;


#define STRDUP(str) (char *)\
      ((str) != NULL ? \
           (strcpy((char *)malloc((unsigned)strlen(str) + 1), str)) : NULL)
#define dietab() \
       { sprintf(errmsg, "Syntax error in table #%d beginning at line %d", \
		 tableno, lineno); return(errmsg);}
#define diesum() \
       { sprintf(errmsg, "Syntax error in summary #%d beginning at line %d", \
		 summaryno, lineno); return(errmsg);}

#define REASONABLE_LENGTH       256     /* reasonable length of text unit */


static char*         parstable(
			      char             *pt,
			      int               lineno,
			      int               tableno,
			      LOG_FILE_TABLE   *table);
static char*         parskeytext(
			      char             *pt,
			      int               lineno,
			      int               keytextno,
			      LOG_FILE_KEYTEXT *table);
static char*         parstext(
			      char             *pt,
			      int               lineno,
			      int               textno,
			      LOG_FILE_TEXT    *table);
static char*         parssummary(
			      char             *pt,
			      int               lineno,
			      int               summaryno,
			      LOG_FILE_SUMMARY *summary);
static int           find_text(
			      char       *name);
static int           find_keytext(
			      char       *name);
static char*         movword(
			      char       *pc,
			      char       *where,
			      char       *stopchars);
static char*         getnoblank(
			      char       *pc,
			      int        *newline_found);
#if !defined (__APPLE__) && !defined (__DARWIN__) && !defined (__FreeBSD__)
static int           isblank(
			      char        c);
#endif
static int           strmatch(
			      char       *fixstring,
			      char       *varstring);
static char *        filetostring(          /* returns error message or NULL */
			      char      *filename,
			      char     **string);
static off_t         filesize(
			      int        fildes);


/*********************************************************************/
char *
read_log_file(
	      char              *logfilname)
/*** Read and parse the log file ***/
{
  int             ntables, nkeytexts, ntexts, nsumms;
  int             lineno, tableno, keytextno, textno, summno;
  register char  *pc, **ppc;
  int             i;
  char           *errmsg;
  LOG_FILE_TABLE *tables;

  errmsg = (char *)NULL;

  /*** Read the log file ***/

  if (errmsg = filetostring(logfilname, &log_file_txt))
      return(errmsg);

  /*** Calculate necessary memory resources ***/

  ntables = nkeytexts = ntexts = nsumms = 0;
  for (pc = log_file_txt; *pc; ++pc) /* number of tables */
    if      (strmatch(TABLE_KEYWORD, pc))
      ++ntables;
    else if (strmatch(KEYTEXT_KEYWORD, pc))
      ++nkeytexts;
    else if (strmatch(TEXT_KEYWORD, pc))
      ++ntexts;
    else if (strmatch(SUMMARY_KEYWORD, pc))
      ++nsumms;

  /*** Allocate main memory resources ***/

  log_file_tabs =
     (LOG_FILE_TABLE *)malloc(sizeof(LOG_FILE_TABLE) * (ntables+1));
  memset((void *)log_file_tabs, NULL,
	 (size_t)sizeof(LOG_FILE_TABLE) * (ntables+1));
  table_list = (char **)XtMalloc(sizeof(char *) * (ntables + 1));
  table_list [ntables] = (char *)NULL;

  log_file_keytxts =
     (LOG_FILE_KEYTEXT *)malloc(sizeof(LOG_FILE_KEYTEXT) * (nkeytexts+1));
  memset((void *)log_file_keytxts, NULL,
	 (size_t)sizeof(LOG_FILE_KEYTEXT) * (nkeytexts+1));
  keytext_list = (char **)XtMalloc(sizeof(char *) * (nkeytexts + 1));
  keytext_list [nkeytexts] = (char *)NULL;

  log_file_txts = (LOG_FILE_TEXT *)malloc(sizeof(LOG_FILE_TEXT) * (ntexts+1));
  memset((void *)log_file_txts, NULL,
	 (size_t)sizeof(LOG_FILE_TEXT) * (ntexts+1));
  text_list = (char **)XtMalloc(sizeof(char *) * (ntexts + 1));
  text_list [ntexts] = (char *)NULL;

  log_file_summs =
     (LOG_FILE_SUMMARY *)malloc(sizeof(LOG_FILE_SUMMARY) * (nsumms+1));
  memset((void *)log_file_summs, NULL,
	 (size_t)sizeof(LOG_FILE_SUMMARY) * (nsumms+1));
  summary_list = (char **)XtMalloc(sizeof(char *) * (nsumms + 1));
  summary_list [nsumms] = (char *)NULL;


  /*** Parse the log file */

  tableno = keytextno = textno = summno = 0;
  for (pc = log_file_txt, lineno = 1; *pc; ++pc)
    if      (*pc == '\n')
      ++lineno;
    else if (strmatch(TABLE_KEYWORD, pc)) {
      if (errmsg = parstable(pc, lineno, tableno, log_file_tabs + tableno))
	return(errmsg);
      ++tableno;
    }
    else if (strmatch(KEYTEXT_KEYWORD, pc)) {
      if (errmsg = parskeytext(pc, lineno, keytextno,
			       log_file_keytxts + keytextno))
	return(errmsg);
      ++keytextno;
    }
    else if (strmatch(TEXT_KEYWORD, pc)) {
      if (errmsg = parstext(pc, lineno, textno, log_file_txts + textno))
	return(errmsg);
      ++textno;
    }
    else if (strmatch(SUMMARY_KEYWORD, pc)) {
      if (errmsg = parssummary(pc, lineno, textno, log_file_summs + summno))
	return(errmsg);
      ++summno;
    }

  /*** Prepare object lists ***/

  for (ppc = table_list, i = 0; i < ntables; ++i, ++ppc)
    *ppc = (log_file_tabs + i)->title;
  for (ppc = keytext_list, i = 0; i < nkeytexts; ++i, ++ppc)
    *ppc = (log_file_keytxts + i)->title;
  for (ppc = text_list, i = 0; i < ntexts; ++i, ++ppc)
    *ppc = (log_file_txts + i)->title;
  for (ppc = summary_list, i = 0; i < nsumms; ++i, ++ppc)
    *ppc = (log_file_summs + i)->title;

  return NULL;
}


/*********************************************************************/
char *
log_file_text(
	      void)
/*** Returns log file text ***/
{
  return log_file_txt;
}


/*********************************************************************/
char **
log_file_tables(
		void)
/*** Returns table list ***/
{
  return table_list;
}


/*********************************************************************/
char **
log_file_keytexts(
		  void)
/*** Returns key text table list ***/
{
  return keytext_list;
}


/*********************************************************************/
char *
interpret_log_text(
		   int      textnum,
		   Widget   parent_w)
{
  char               c;
  LOG_FILE_TEXT     *txt;
  char              *displayed_text;

  txt = log_file_txts + textnum;

  c = txt->text_position [txt->text_length];
  txt->text_position [txt->text_length] = '\0';
  displayed_text = strdup(txt->text_position);
  txt->text_position [txt->text_length] = c;

#if  0
  printf("text name |%s|\nany text |%s|\n",
	 txt->title,
	 txt->text_position);
#endif

  /*** Create window environment ***/

  {
    Widget    shell, form, w, print_w, text_w;

    shell = XtVaCreatePopupShell("logText", topLevelShellWidgetClass,
                               parent_w,
			       XtNtitle, txt->title,
                               XtNiconName, txt->title,
                               NULL);
    form = XtVaCreateManagedWidget("form", formWidgetClass,
                               shell,
                               NULL);
    w = XtVaCreateManagedWidget("Quit", commandWidgetClass,
                               form,
                               NULL);
                XtAddCallback(w,
                               XtNcallback, my_quitCallback,
                               (XtPointer)shell);
    print_w = XtVaCreateManagedWidget("Print", commandWidgetClass,
                               form,
                               XtNfromHoriz, w,
                               NULL);
    text_w = XtVaCreateManagedWidget("text", asciiTextWidgetClass,
                               form,
                               XtNeditType, XawtextRead,
                               XtNdisplayCaret, True,
                               XtNstring, displayed_text,
                               XtNuseStringInPlace, False,
                               XtNscrollVertical, XawtextScrollAlways,
                               XtNscrollHorizontal, XawtextScrollWhenNeeded,
                               XtNfromVert, w,
                               NULL);
    XtOverrideTranslations(text_w, text_translations);
                XtAddCallback(print_w,
			      XtNcallback, textPrintCallback,
			      (XtPointer)text_w);

  XtPopup(shell, XtGrabNone);
  }
  XtFree(displayed_text);
  return NULL;
}


/*********************************************************************/
char **
log_file_texts(
	      void)
/*** Returns text table list ***/
{
  return text_list;
}


/*********************************************************************/
char *
interpret_log_keytext(
		      int      keytextnum,
		      Widget   parent_w)
{
  char               c;
  LOG_FILE_KEYTEXT  *kt;
  
  kt = log_file_keytxts + keytextnum;

  c = kt->text_position [kt->text_length];
  kt->text_position [kt->text_length] = '\0';
  kt->keytext_position [kt->keytext_length] = '\0';

#if 0
  printf("keytext name |%s|\nany text |%s|\nkeytext |%s|\n",
	 kt->title,
	 kt->text_position,
	 kt->keytext_position);
#endif

  {
    Widget    shell, form, w, print_w, text_w, keytext_w;

    shell = XtVaCreatePopupShell("keyLogText", topLevelShellWidgetClass,
                               parent_w,
			       XtNtitle, kt->title,
                               XtNiconName, kt->title,
                               NULL);
    form = XtVaCreateManagedWidget("form", formWidgetClass,
                               shell,
                               NULL);
    w = XtVaCreateManagedWidget("Quit", commandWidgetClass,
                               form,
                               NULL);
                XtAddCallback(w,
                               XtNcallback, my_quitCallback,
                               (XtPointer)shell);
    print_w = XtVaCreateManagedWidget("Print", commandWidgetClass,
                               form,
                               XtNfromHoriz, w,
                               NULL);
    w = text_w = XtVaCreateManagedWidget("text", asciiTextWidgetClass,
                               form,
                               XtNeditType, XawtextRead,
                               XtNdisplayCaret, True,
                               XtNstring, kt->text_position,
                               XtNuseStringInPlace, False,
                               XtNscrollVertical, XawtextScrollAlways,
                               XtNscrollHorizontal, XawtextScrollWhenNeeded,
                               XtNfromVert, w,
                               NULL);
    XtOverrideTranslations(text_w, text_translations);

    w = keytext_w = XtVaCreateManagedWidget("keyText", asciiTextWidgetClass,
                               form,
                               XtNeditType, XawtextRead,
                               XtNdisplayCaret, True,
                               XtNstring, kt->keytext_position,
                               XtNuseStringInPlace, False,
                               XtNscrollVertical, XawtextScrollAlways,
                               XtNscrollHorizontal, XawtextScrollWhenNeeded,
                               XtNfromVert, w,
                               NULL);
    XtOverrideTranslations(keytext_w, text_translations);
                XtAddCallback(print_w,
			      XtNcallback, textPrintCallback,
			      (XtPointer)keytext_w);

  XtPopup(shell, XtGrabNone);
  }




  kt->text_position [kt->text_length] =
    kt->keytext_position [kt->keytext_length] = c;
  return NULL;
}


/*********************************************************************/
char **
log_file_summaries(                 /* returns summary list */
		   void)
{
  return summary_list;
}


/*********************************************************************/
char *
interpret_log_summary(
		      int      summarynum,
		      Widget   parent_w)
{
  Widget              shell, form, w, print_w, text_w;
  LOG_FILE_SUMMARY   *summ;

  summ = log_file_summs + summarynum;
  /*** Create window environment ***/

  shell = XtVaCreatePopupShell("logSummary", topLevelShellWidgetClass,
                               parent_w,
			       XtNtitle, summ->title,
                               XtNiconName, summ->title,
                               NULL);
  form = XtVaCreateManagedWidget("form", formWidgetClass,
                               shell,
                               NULL);
  w = XtVaCreateManagedWidget("Quit", commandWidgetClass,
                               form,
                               NULL);
                XtAddCallback(w,
                               XtNcallback, my_quitCallback,
                               (XtPointer)shell);
  print_w = XtVaCreateManagedWidget("Print", commandWidgetClass,
                               form,
                               XtNfromHoriz, w,
                               NULL);
  text_w = XtVaCreateManagedWidget("text", asciiTextWidgetClass,
                               form,
                               XtNeditType, XawtextRead,
                               XtNdisplayCaret, True,
                               XtNstring, summ->text_form,
                               XtNuseStringInPlace, False,
                               XtNscrollVertical, XawtextScrollAlways,
                               XtNscrollHorizontal, XawtextScrollWhenNeeded,
                               XtNfromVert, w,
                               NULL);
  XtOverrideTranslations(text_w, text_translations);
                XtAddCallback(print_w,
			      XtNcallback, textPrintCallback,
			      (XtPointer)text_w);

  XtPopup(shell, XtGrabNone);

  return NULL;
}


/*********************************************************************/
char **
log_file_graphs(
		int      tablenum)
{
  return((log_file_tabs + tablenum)->graph_list);
}


/*********************************************************************/
char *
interpret_log_graph(       /* returns error message or NULL */
		    int      tablenum,
		    int      graphnum,
		    Widget   parent_w)
{
  Widget                        plot_w;
  unsigned                      input_size;
  register int                  i;
  float                         scale;
  float                         x, y;
  static int                    object_1 = 0;
  char                         *errmsg;
  ZDR2D_SCENE_DSC               scene;
  LOG_FILE_GRAPH               *graph;
  LOG_FILE_TABLE               *table;

  /*** Find current graph ***/

  table = log_file_tabs + tablenum;
  for (graph = table->graphs, i = graphnum; i; --i)
    graph = graph->next;

  /*** Play with absolute/relative scale ***/

  memset((void *)(&scene), (int)NULL, sizeof(scene));

  scale = 1.0;                              /* scaling done in plot widget */

  scene.label = NULL;
  scene.minx = 0.0;
  scene.maxx = 180.0;
  scene.miny = 0.0;
  scene.maxy = 140.0;
  scene.absolute_scale = False;
  scene.shift_to_min = False;
  scene.origin = ZDr2dSouthWest;
  scene.orientation = 0.0;
  scene.scale = 0.0;


  /*** Create window environment ***/
  {
    Widget    shell, form, w, plot_button;

    shell = XtVaCreatePopupShell("graph", topLevelShellWidgetClass,
                               parent_w,
			       XtNtitle, graph->title,
                               XtNiconName, graph->title,
                               NULL);
    form = XtVaCreateManagedWidget("form", formWidgetClass,
                               shell,
                               NULL);
    w = XtVaCreateManagedWidget("Quit", commandWidgetClass,
                               form,
                               NULL);
                XtAddCallback(w,
                               XtNcallback, my_quitCallback,
                               (XtPointer)shell);
    plot_button = w = XtVaCreateManagedWidget("Plot", commandWidgetClass,
                               form,
                               XtNfromHoriz, w,
                               NULL);
    current_draw_w =
    plot_w = XtVaCreateManagedWidget("draw2d", zDr2dWidgetClass,
                                form,
                                XtNsceneDsc, &scene,
                                XtNfromVert, w,
                                NULL);
    if (errmsg = XZDr2dNewObject(plot_w, (XtPointer)NULL, 1, (XtPointer)NULL,
                                 (ZDR2D_MATRIX *)NULL))
      msg_box(errmsg);
    XZDr2dRenderScene(plot_w, True);
  XtAddCallback(plot_button, XtNcallback, my_plotCallback, (XtPointer)plot_w);
  XtPopup(shell, XtGrabNone);
  }

  /*** Prepare data for Tom Oldfield's routines ***/
  {
    int                 nrows,      /* # of rows of thetable */
                        xcolnum,    /* index of column for X axis */
                        ncurves,    /* total # of graph curves */
                        colindex;   /* working - curent column index */
    float              *array,      /* space for values */
                       *pa,         /* working -> array */
                       *val;        /* working -> table values */
    int    dummy_text_length = 1024;/* not important, just some */
    char               *text;       /* text written into graph */
    int                 textlength; /* it's length */
    float               x, y,       /* working coordinates */
                        size,       /* text size */
                        rotation;   /* text rotation */
    int                 i, j;
    static int          one = 1;

    TOM_START_GRAPHICS();
    nrows = table->n_values / table->n_cols;
    xcolnum = *(graph->col) - 1;       /* x axis given by column */
    ncurves = graph->numcols - 1;
    array = (float *)XtMalloc(sizeof(float) * 2 * nrows * ncurves);

    /*** Fill 3-dim fortran array for Tom subroutines ***/

    for (i = 0, pa = array, val = table->values; i < nrows; ++i) {
      for (j = 1; j <= ncurves; ++j) {
	colindex = (graph->col) [j] - 1;
	*pa++ = val [xcolnum];
	*pa++ = val [colindex];
      }
      val += table->n_cols;
    }

    /*** Graph title (axis will start at the position (40,40) ***/

    x = 40.0; y = 130.0; size = 3.5; rotation = 0.0;
    text = graph->title;
    textlength = strlen(text);
    TOM_TEXT_STRING(&x, &y, &size, &rotation, &textlength,
		    text, &dummy_text_length);

    /** X axis description ***/

    x = 140.0; y = 30.0; size = 2.2; rotation = 0.0;
    text = (table->column_names) [*graph->col - 1];
    textlength = strlen(text);
    TOM_TEXT_STRING(&x, &y, &size, &rotation, &textlength,
		    text, &dummy_text_length);

    /*** Legend ***/

    for (i = 0; i < graph->numcols - 1; ++i) {
      x = 40.0; y = (float)(29 - (4*i));
      j = i + 2;
      TOM_GRAPH_COL(&j);
      TOM_GRAPH_MOVE(&x, &y);
      x += 10.0;
      TOM_GRAPH_DRAW(&x, &y);
      TOM_GRAPH_COL(&one);
      x += 2.0; y -= 1.0;
      size = 2.2; rotation = 0.0;
      text = (table->column_names) [graph->col [i+1] - 1];
      textlength = strlen(text);
      TOM_TEXT_STRING(&x,&y,&size, &rotation, &textlength,
		      text, &dummy_text_length);
    }


    /*** Set graph characteristics ***/

    switch (graph->graphtype) {
    case 'A':
      TOM_AUTOSCALE();
      break;
    case 'N':
      TOM_ZEROY();
      break;
    case 'S':
      TOM_DRAW_LIMITS(&(graph->xlowlimit), &(graph->xhighlimit),
		      &(graph->ylowlimit), &(graph->yhighlimit));
    }

    /*** Draw graph itself ***/

    TOM_DRAW_GRAPH(array, &ncurves, &nrows, &ncurves, &nrows);
    XZDr2dRenderScene(current_draw_w, True);
    XtFree((char *)array);
  }
  return(NULL);
}


/*********************************************************************/
static char *
parstable(
	  char           *pt,
	  int             lineno,
	  int             tableno,
	  LOG_FILE_TABLE *table)
/*** Parse one table from the log file ***/
{
  char                rubish [256], *prbegin, *prend, c;
  register char      *pttmp;
  float              *pv;
  double              tmpdouble; /* fu. compilers don't do direct conversion */
  int                 newline_found, counter;
  int                 colnumbers [1024];
  char               *colnames [1024];
  register LOG_FILE_GRAPH     *pgraph;
  int                          i;
  static char         errmsg [512];

  pt = movword(pt, rubish, " :\t\n");               /* discard TABLE keyword */
  pt = getnoblank(pt, &newline_found);                     /* discard blanks */
  if (*pt != ':')
    dietab();
  ++pt;
  pt = movword(pt, rubish, ":");                             /* :table name: */
  ++pt;
  table->title = STRDUP(rubish);

  pt = getnoblank(pt, &newline_found);                     /* discard blanks */
  pt = movword(pt, rubish, " :\t\n");               /* discard GRAPH keyword */

  if (strcmp(rubish, GRAPH_KEYWORD))
    dietab();

  pt = getnoblank(pt, &newline_found);                     /* discard blanks */

  while (*pt == ':') {                                     /* for all graphs */

    /*** Allocate entry & chain it ***/

    pgraph = XtNew(LOG_FILE_GRAPH);
    memset((void *)pgraph, NULL, (size_t)sizeof(LOG_FILE_GRAPH));
    if (!table->graphs)
      table->graphs = pgraph;
    else {
      register LOG_FILE_GRAPH     *pg;

      for (pg = table->graphs; pg->next; pg = pg->next)
	;
      pg->next = pgraph;
    }

    /*** parse graph description ***/
    ++pt;
    pt = movword(pt, rubish, ":");                        /* read graph name */
    pgraph->title = STRDUP(rubish);
    ++pt;
    pt = movword(pt, rubish, "|:");        /* read graph type (or it's part) */
    if (*pt == ':')
      switch (*rubish) {
      case 'A':
      case 'N':
	pgraph->graphtype = (int)*rubish;
	break;
      default: dietab();
      }
    else {          /* must be abs scale now - so: limits for absolute scale */
      pgraph->graphtype = (int)'S';
      tmpdouble = atof(rubish);
      pgraph->xlowlimit = (float)tmpdouble;
      ++pt;

      pt = movword(pt, rubish, "x:");
      switch(*pt) {
      case 'x':
	tmpdouble = atof(rubish);
	pgraph->xhighlimit = (float)tmpdouble;
	++pt;
	break;
      default:
	dietab();
      }

      pt = movword(pt, rubish, "|:");
      switch(*pt) {
      case '|':
	tmpdouble = atof(rubish);
	pgraph->ylowlimit = (float)tmpdouble;
	++pt;
	break;
      default:
	dietab();
      }

      pt = movword(pt, rubish, ":");
      tmpdouble = atof(rubish);
      pgraph->yhighlimit = (float)tmpdouble;
    }
      
    do {
      ++pt;
      pt = movword(pt, rubish, ",:");                  /* read column number */
      colnumbers [pgraph->numcols] = atoi(rubish);
      ++(pgraph->numcols);
    } while (*pt == ',');
    ++pt;
    pgraph->col = (int *)XtMalloc(sizeof(int) * pgraph->numcols);
    memcpy((void *)pgraph->col,(void *)colnumbers,sizeof(int)*pgraph->numcols);

    pt = getnoblank(pt, &newline_found);
  }

  pt = movword(pt, rubish, " \t\n");                    /* discard delimiter */
  if (strcmp(rubish, DELIMITER))
    dietab();

  pt = getnoblank(pt, &newline_found);


  /*** Column description parsing ***/

  while (!strmatch(DELIMITER, pt)) {                     /*** column names ***/
    pt = movword(pt, rubish, " \t\n");
    colnames [table->n_cols] = STRDUP(rubish);
    ++(table->n_cols);
    pt = getnoblank(pt, &newline_found);                   /* discard blanks */
  }
  table->column_names = (char **)XtMalloc(sizeof(char *) * table->n_cols);
  memcpy((void *)table->column_names, (void *)colnames,
	 sizeof(char *) * table->n_cols);

  pt = movword(pt, rubish, " \t\n");                    /* discard delimiter */
  pt = getnoblank(pt, &newline_found);

  /*** Discard possible comment/nice_header ***/

  while (!strmatch(DELIMITER, pt)) {
    pt = movword(pt, rubish, " \t\n"); /* discard comment (up to next delim. */
    pt = getnoblank(pt, &newline_found);
  }
  pt = movword(pt, rubish, " \t\n");                    /* discard delimiter */
  pt = getnoblank(pt, &newline_found);

  /*** Table numbers parsing ***/

  pttmp = pt;
  counter = 0;
  while (!strmatch(DELIMITER, pttmp)) {             /* count # of values 1st */
    pttmp = movword(pttmp, rubish, " \t\n");
    ++counter;
    if (counter <= table->n_cols)
      ++(table->n_values);
    pttmp = getnoblank(pttmp, &newline_found);
    if (newline_found && counter >= table->n_cols)
      counter = 0;                                          /* new table row */
  }

  pv = table->values = (float *)XtMalloc(sizeof(float) * table->n_values);

  counter = 0;
  while (!strmatch(DELIMITER, pt)) {               /* and now read the table */
    pt = movword(pt, rubish, " \t\n");
    ++counter;
    if (counter <= table->n_cols) {
      tmpdouble = atof(rubish);
      *pv++ = (float)tmpdouble;
    }
    pt = getnoblank(pt, &newline_found);
    if (newline_found && counter >= table->n_cols)
      counter = 0;                                          /* new table row */
  }

  for (pgraph = table->graphs, i = 0; pgraph; pgraph = pgraph->next)
    ++i;                                         /* Number of graph in table */
  table->graph_list = (char **)XtMalloc(sizeof(char *) * (i + 1));
  (table->graph_list) [i] = (char *)NULL;
  for (pgraph = table->graphs, i = 0; pgraph; pgraph = pgraph->next, ++i)
    (table->graph_list) [i] = pgraph->title;
  return(NULL);
}


/*********************************************************************/
static char *
parskeytext(
	  char              *pt,
	  int                lineno,
	  int                keytextno,
	  LOG_FILE_KEYTEXT  *keytxts)
/*** Parse one keytext from the log file ***/
{
  register char       *pc, *ptold;
  register int         length;

  while (*pt != ':') ++pt;

  /*** Title length & copy ***/

  for (ptold = ++pt, length = 0; *pt && *pt != ':'; ++length, ++pt);
  keytxts->title = pc = (char *)malloc(sizeof(char) * length + 1);
  for (pt = ptold; length; --length, *pc++ = *pt++);
  *pc = '\0';

  /*** 'any' text length and address ***/

  while (!strmatch(DELIMITER, pt)) ++pt;
  pt += strlen(DELIMITER);
  keytxts->text_position = pt;

  for (length = 0; !strmatch(DELIMITER, pt); ++pt, ++length);
  keytxts->text_length = length;
  
  /*** 'Key' text length and address ***/

  while (!strmatch(DELIMITER, pt)) ++pt;
  pt += strlen(DELIMITER);
  keytxts->keytext_position = pt;

  for (length = 0; !strmatch(DELIMITER, pt); ++pt, ++length);
  keytxts->keytext_length = length;

  return NULL;
}

/*********************************************************************/
static char *
parstext(
	  char           *pt,
	  int             lineno,
	  int             textno,
	  LOG_FILE_TEXT  *txts)
/*** Parse one text from the log file ***/
{
  register char       *pc, *ptold;
  register int         length;

  while (*pt != ':') ++pt;

  /*** Title length & copy ***/

  for (ptold = ++pt, length = 0; *pt && *pt != ':'; ++length, ++pt);
  txts->title = pc = (char *)malloc(sizeof(char) * length + 1);
  for (pt = ptold; length; --length, *pc++ = *pt++);
  *pc = '\0';

  /*** skip junk - ignored text ***/

  while (!strmatch(DELIMITER, pt)) ++pt;
  pt += strlen(DELIMITER);
  while (!strmatch(DELIMITER, pt)) ++pt;

  /*** 'any' text length and address ***/

  while (!strmatch(DELIMITER, pt)) ++pt;
  pt += strlen(DELIMITER);
  txts->text_position = pt;

  for (length = 0; !strmatch(DELIMITER, pt); ++pt, ++length);
  txts->text_length = length;
  
  return NULL;
}


/*********************************************************************/
static char*
parssummary(
	    char             *pt,
	    int               lineno,
	    int               summaryno,
	    LOG_FILE_SUMMARY *summary)
/*** Parse one summary description from the log file ***/
{
  char                rubish [256], *prbegin, *prend, c;
  register char       *pttmp;
  int                  newline_found, content_size;
  SUMMARY_CONTENT      content [1024], *pcontent;
  static char          errmsg [512];

  content_size = 0; pcontent = content;

  pt = movword(pt, rubish, " :\t\n");               /* discard TABLE keyword */
  pt = getnoblank(pt, &newline_found);                     /* discard blanks */
  if (*pt != ':')
    diesum();
  ++pt;
  pt = movword(pt, rubish, ":");                           /* :summary name: */
  ++pt;
  summary->title = STRDUP(rubish);

  while (!strmatch(DELIMITER, pt)) ++pt;          /* discard up to delimiter */
  ++pt;
  while (!strmatch(DELIMITER, pt)) ++pt;     /* discard up to next delimiter */
  pt += strlen(DELIMITER);
  pt = getnoblank(pt, &newline_found);

  while (!strmatch(DELIMITER, pt)) {
    if (*pt != ':')
      diesum();
    ++pt;
    pt = movword(pt, rubish, ":");                         /* component type */
    ++pt;

    if (!strcmp("TEXT", rubish))
      pcontent->type = TEXT_TYPE;
    else if (!strcmp("KEYTEXT", rubish))
      pcontent->type = KEYTEXT_TYPE;
    else
      diesum();

    pt = movword(pt, rubish, ":");                         /* component name */
    if (pcontent->type == TEXT_TYPE) {
      if ((pcontent->index = find_text(rubish)) < 0)
	diesum();
    }
    else if (pcontent->type == KEYTEXT_TYPE) {
      if ((pcontent->index = find_keytext(rubish)) < 0)
	diesum();
    }
	  
    ++pt;
    pt = getnoblank(pt, &newline_found);
    ++pcontent;
    ++content_size;
  }

  summary->content =
       (SUMMARY_CONTENT *)malloc(sizeof(SUMMARY_CONTENT) * content_size);
  summary->content_size = content_size;
  memcpy((void *)summary->content, (void *)content,
	 sizeof(SUMMARY_CONTENT) * content_size);
  

  {
    int      i, j, text_form_size;
    char    *buf, *pco, *pci;;
#define N_NEWLINES   2

    for (text_form_size = i = 0, pcontent = content;
	 i < content_size; ++i, ++pcontent) {
      switch ((content + i)->type) {

      case TEXT_TYPE:
	text_form_size += (log_file_txts + pcontent->index)->text_length;
	break;

      case KEYTEXT_TYPE:
	text_form_size += (log_file_keytxts + pcontent->index)->text_length +
	  (log_file_keytxts + pcontent->index)->keytext_length + 1/*newline*/;
	break;
      }
      text_form_size += N_NEWLINES;
    }

    pco = summary->text_form =
                (char *)malloc(sizeof(char) * text_form_size + 1);
    *(summary->text_form) = '\0';

    for (i = 0, pcontent = content; i < content_size; ++i, ++pcontent) {
      switch ((content + i)->type) {

      case TEXT_TYPE:
	pci = (log_file_txts + pcontent->index)->text_position;
	for (j = (log_file_txts + pcontent->index)->text_length; j; --j)
	  *pco++ = *pci++;
	break;

      case KEYTEXT_TYPE:
	pci = (log_file_keytxts + pcontent->index)->text_position;
	for (j = (log_file_keytxts + pcontent->index)->text_length; j; --j)
	  *pco++ = *pci++;
	*pco++ = '\n';
	pci = (log_file_keytxts + pcontent->index)->keytext_position;
	for (j = (log_file_keytxts + pcontent->index)->keytext_length; j; --j)
	  *pco++ = *pci++;
	break;
      }
      for (j = N_NEWLINES; j; --j)
	*pco++ = '\n';
    }
    for (j = N_NEWLINES-1; j; --j)
      --pco;
    *pco = '\0';
  }

  return NULL;
}


/*********************************************************************/
static int
find_text(
	  char       *name)
{
  int         i;

  for (i = 0; (log_file_txts + i)->title; ++i)
    if (!strcmp((log_file_txts + i)->title, name))
      return i;

  return -1;
}


/*********************************************************************/
static int
find_keytext(
	     char       *name)
{
  int         i;

  for (i = 0; (log_file_keytxts + i)->title; ++i)
    if (!strcmp((log_file_keytxts + i)->title, name))
      return i;

  return -1;
}


/*********************************************************************/
static char *
getnoblank(
	   char       *pc,
	   int        *newline_found)
{
  *newline_found = 0;

  while (isblank(*pc) || *pc=='\n') {
    if (*pc == '\n')
      *newline_found = 1;
    ++pc;
  }
  return(pc);
}


/*********************************************************************/
#if !defined (__APPLE__) && !defined (__DARWIN__) && !defined (__FreeBSD__)
static int
isblank(
	char c)
{
  if (c == ' ' || c == '\t')
    return(1);
  else
    return(0);
}
#endif

/*********************************************************************/
static int
strmatch(
	 char       *fixstring,
	 char       *varstring)
{
  while (*fixstring && *fixstring == *varstring) {
    ++fixstring;
    ++varstring;
  }
  return( *fixstring ? 0 : 1 );
}


/*********************************************************************/
static char *
movword(
	char          *pc,
	char          *where,
	char          *delim)
{
  register char    c, *p;
  register int     found;
  register int     i;

  for (i = found = 0, c = *pc; !found && i <= REASONABLE_LENGTH;
                                     c = *(++pc), ++where, ++i) {
    for (p = delim; *p; ++p)
      if (c == *p) {
	found = 1;
	break;
      }
    *where = c;
  }
  if (i > REASONABLE_LENGTH)
    XtError("Internal limitation exceede, contact author");
  *(--where) = '\0';
  return(--pc);
}


/*****************************************************************************/
static char *
filetostring(          /* returns error message or NULL */
	     char      *filename,
	     char     **string)
{
  int           fildes;
  off_t         filsiz;
  char         *s;
  static char   errmsg [1024];

  if ((fildes = open(filename, O_RDONLY)) == -1) {
    sprintf(errmsg, "Cannot open log file %s\n%s",
	    filename, strerror(errno));
    return(errmsg);
  }
  filsiz = filesize(fildes);
  s = (char *)malloc(filsiz + 1);
  if ((off_t)read(fildes, (void *)s, (unsigned)filsiz) != filsiz) {
    sprintf(errmsg, "Read error on log file %s\n%s",
	    filename, strerror(errno));
    return(errmsg);
  }
  *(s + (int)filsiz) = '\0';
  close(fildes);
  if (strlen(s) > filsiz)
    XtError("fileandstring - my terrible mistake\n");

  *string = s;
  return((char *)NULL);
}


/*****************************************************************************/
static off_t
filesize(fildes)
int            fildes;
{
#if defined _MSC_VER   
  struct _stat st;

  _fstat(fildes, &st);
#else
  struct stat st; 

  fstat(fildes, &st);
#endif
  return st.st_size; 
}


/*****************************************************************************/static void
my_quitCallback(
                  Widget              w,
                  XtPointer           shell,
                  XtPointer           garbage)
{
  XtDestroyWidget((Widget)shell);
}


/*****************************************************************************/static void
my_plotCallback(
                Widget              w,
                XtPointer           plot_w,
                XtPointer           garbage2)
{
  FILE  *fp;
  char  *errmsg;

  if (!(fp = hardcopy_rent_ps_file()))
    hardcopy_return_ps_file(True);
  else {
    if (errmsg = XZDr2dPostscript((Widget)plot_w, hardcopy_is_portrait(), fp))
      msg_box(errmsg);
    hardcopy_return_ps_file(errmsg ? True : False);
  }
}


/*****************************************************************************/static void
textPrintCallback(
		  Widget              w,
		  XtPointer           print_w,
		  XtPointer           garbage2)
{
  String   new_string;
  FILE  *fp;

  if (!(fp = hardcopy_rent_text_file()))
    hardcopy_return_text_file(True);
  else {
    XtVaGetValues((Widget)print_w, XtNstring, &new_string, NULL);
    fprintf(fp, "%s", new_string);
    XawAsciiSourceFreeString(XawTextGetSource((Widget)print_w));
    hardcopy_return_text_file(False);
  }
}
