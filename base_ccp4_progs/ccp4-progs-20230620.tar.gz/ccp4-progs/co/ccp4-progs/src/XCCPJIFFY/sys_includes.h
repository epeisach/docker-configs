/*********************************************************************
  sys_includes.h
  Z131093

As each UNIX is a little different, fix the problems here:
*********************************************************************/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

#if defined(__hpux) || defined(_AIX) || defined (___AIX)
#  include <unistd.h>
   extern char  *sys_errlist[];
#endif /* __hpux */

#if defined(ESV_2)
#  include <unistd.h>
   extern char   *is_errlist[];
#  define sys_errlist is_errlist
#endif /* ESV_2 */

#if defined (AL2800_2) || defined (_AIX) || defined (___AIX)
   extern char *sys_errlist [];
#endif /* ALLIANT_2800 */

#if defined (CONVEX)
#  define sys_errlist __ap$sys_errlist
#endif /* CONVEX */


#if defined (SUNOS_4)
   extern char *sys_errlist [];
#include <unistd.h>		/* for SEEK_SET */
#endif


