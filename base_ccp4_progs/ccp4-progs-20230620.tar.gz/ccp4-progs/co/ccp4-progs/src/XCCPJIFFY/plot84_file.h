/*********************************************************************
  plot84_file.h

  Deals with plot84 metafile
**********************************************************************/

typedef struct plot84_file_header {
  int        nrec;       /* number of data records in picture after header */
  float      dotmmx;     /* dots per mm along X */
  float      dotmmy;     /* dots per mm along Y */
  int        ixmin;      /* low raster X used */
  int        ixmax;      /* high raster X used */
  int        iymin;      /* low Y */
  int        iymax;      /* high Y */
  int        linwt;      /* line thickness */
  int        icolor;     /* colour */
  int        mixcol;     /* mixed colour */
  int        mdevic;     /* device type */
  int        mdirec;     /* direct/deferred */
  int        mout;       /* output unit (for vt640 only) */
  int        mpic;       /* picture number in this file */
  int        mscafl;     /* floating scale selection */
  int        mcntfl;     /* floating origin selection */
  float      dwlimx;     /* drawing board X size (mm) */
  float      dwlimy;     /* drawing board Y size (mm) */
  float      dvxmin;     /* device viewport X min (mm) */
  float      dvxmax;     /* device viewport X max (mm) */
  float      dvymin;     /* device viewport Y min (mm) */
  float      dvymax;     /* device viewport Y max (mm) */
  int        npics;      /* number of pictures in this file */           
  char       paswrd [8]; /* password "PLOT%%84" */
  int        spare [15]; /* spare bytes */
  char       titleh [80];/* plot title */
  int        lastspare [68]; /* filled to 512 bytes */
} PLOT84_HEADER;

typedef struct plot84_data_record {
  short      x;    /* POSITIVE - X coordinate, NEGATIVE - command */
  short      y;    /* Y coordinate POSITIVE- draw, NEGATIVE - move */
} PLOT84_DATA_RECORD;

typedef struct plot84_file_contens {
  off_t          command_addr;
  int            ncommands;
  PLOT84_HEADER *header;
  int            picture_number;
  char           title [81];
} PLOT84_FILE_CONTENS;

/*** Plot commands in x entry of PLOT84_RECORD ***/

#define END          -1 /* end of pitcture (in x entry of data record), y entry
			   is used to put out y pages before next picture */
#define DOT          -2 /* next record specifies the dot position */
#define LINEWEIGHT   -3 /* line thickness given by y in range 1..9 */
#define COLOUR       -4 /* y defines colour (y in range 1..7) */
#define BLANK_PAPER  -5 /* y rows at 100 rows per inch - NOT USED HERE */
#define ERASE_MODE   -6 /* VT640 only - NOT USED HERE */


extern char *       read_plot84_file(/* returns static error message or NULL */
			    char                 *plot84_filename,  /* input */
			    int                  *npictures,       /* output */
			    int                  *file_descriptor, /* output */
			    PLOT84_FILE_CONTENS **contens);        /* output */

extern char *       interpret_plot84_picture(
			    int                   file_descriptor,
			    PLOT84_FILE_CONTENS  *cont,
			    Boolean               scene_scale_absolute,
			    float                 scene_scale,
			    float                 scene_orientation,
			    Widget                parent_w);
