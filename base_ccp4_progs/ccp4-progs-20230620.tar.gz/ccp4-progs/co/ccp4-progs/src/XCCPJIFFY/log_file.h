/*********************************************************************
  log_file.h
  Z110992

  Deals with log file and tables desribed therein.
**********************************************************************/

#ifndef log_file_
#define log_file_

extern char *    read_log_file(             /* returns error message or NULL */
			char    *logfilname);

extern char *    log_file_text(                     /* returns log file text */
			void);

extern char **   log_file_keytexts(                  /* returns keytext list */
			void);
extern char *    interpret_log_keytext(
			int      keytextnum,
			Widget   parent_w);

extern char **   log_file_texts(                        /* returns text list */
			void);
extern char *    interpret_log_text(
			int      textnum,
			Widget   parent_w);

extern char **   log_file_summaries(                 /* returns summary list */
			void);
extern char *    interpret_log_summary(
			int      summarynum,
			Widget   parent_w);

extern char **   log_file_tables(                      /* returns table list */
			void);
extern char **   log_file_graphs(
			int      tablenum);
extern char *    interpret_log_graph(       /* returns error message or NULL */
			int      tablenum,
			int      graphnum,
			Widget   parent_w);
#endif /* log_file_ */
