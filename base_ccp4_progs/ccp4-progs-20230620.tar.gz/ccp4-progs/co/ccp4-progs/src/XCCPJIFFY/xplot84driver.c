/******************************************************************************
  xplot84driver.c

  Reads plot84 metafile and displays pictures

  Application class:             XCCPJiffy
  Default application instance:  xplot84driver
******************************************************************************/

#define VERSION "Z010394"

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/Toggle.h>
#include "EditString.h"


#include "plot84_file.h"
#include "msg_box.h"
#include "hardcopy_ctrl.h"


#define SCALEFMT        "%7.2f"
#define ORIENTATIONFMT  "%7.2f"

String        process_name;
String        app_class = "XCCPJiffy";
XtAppContext  appcontext;          /* application context */
static Widget topLevel,            /* application shell */
              absoluteScaleType,   /* absolute/relative scale */
              scaleValue,          /* scale value */
              orientationValue,    /* orientation value */
              ctrlPanel,           /* hardcopy control panel */
              ctrlPanelB;          /* hardcopy control panel Button*/

static char                 *topLabelText = "Select from Pictures:";
static char                **picture_list;
static char                 *empty_list [] = {NULL};
static int                   file_descriptor;
static PLOT84_FILE_CONTENS  *plot_file_contens;

static char listw_translations[] = {
  "<Btn1Up>:       Notify() Unset()              \n\
   <Btn2Up>:       Notify() Unset()              \n\
   <Btn3Up>:       Notify() Unset()              \n\
   <Motion>:       Set()                         \n\
   <LeaveNotify>:  Unset()                       \n\
"};

static XtTranslations    internal_listw_translations;

/********************** Manual *********************************/

static void
manual(
       void)
{
fprintf(stderr,
"\
\n\
Run %s using command\n\
\n\
%s plot84_metafile_name &\n", process_name, process_name);
}




/********************** CallBacks ******************************/
/***************************************************************/
static void
topQuitBCallback(
		 Widget     w,
		 XtPointer  garbage1,
		 XtPointer  garbage2)
{
  exit(0);
}

/***************************************************************/
static void
paintPictureCallback(
		  Widget      w,
		  XtPointer   garbage,
		  XtPointer   xtlist)
/*** Paint selected graph ***/
{
  XawListReturnStruct *list;
  char                *errmsg;
  Boolean              scale_absolute;
  float                scale;
  float                orientation;

  XtVaGetValues(absoluteScaleType, XtNstate, &scale_absolute, NULL);
  XtVaGetValues(scaleValue, XtNfloatValue, &scale, NULL);
  XtVaGetValues(orientationValue, XtNfloatValue, &orientation, NULL);

  list = (XawListReturnStruct *)xtlist;
  if (errmsg = interpret_plot84_picture(file_descriptor,
					plot_file_contens + list->list_index,
					scale_absolute, scale, orientation,
					topLevel))
    msg_box(errmsg);
}


/***************************************************************/
static void
ctrlPanelBCallback(
		  Widget      w,
		  XtPointer   garbage1,
		  XtPointer   garbage2)
/*** Display Hardcopy control panel ***/
{
  XtPopup(ctrlPanel, XtGrabNone);
  XtVaSetValues(ctrlPanelB, XtNsensitive, False, NULL);
}

/***************************************************************/
static void
popdownCallback(
		  Widget      w,
		  XtPointer   garbage1,
		  XtPointer   garbage2)
/*** (Un)Display Hardcopy control panel ***/
{
  XtPopdown(ctrlPanel);
  XtVaSetValues(ctrlPanelB, XtNsensitive, True, NULL);
}


/***************************************************************/
static void
scaleTypeCallback(
		 Widget     w,
		 XtPointer  garbage1,
		 XtPointer  garbage2)
{
  Boolean      abs_scale;

  XtVaGetValues(w, XtNstate, &abs_scale, NULL);
  XtVaSetValues(w, XtNlabel, abs_scale ? "Absolute" : "Relative", NULL);

  if (abs_scale) {
    if (XtIsRealized(scaleValue))
	XtMapWidget(scaleValue);
    else
      XtVaSetValues(scaleValue, XtNmappedWhenManaged, True, NULL);
  }
  else {
    if (XtIsRealized(scaleValue))
      XtUnmapWidget(scaleValue);
    else
      XtVaSetValues(scaleValue, XtNmappedWhenManaged, False, NULL);
  }
}


/***************************************************************/
static void
correctScaleCallback(
		  Widget      w,
		  XtPointer   garbage1,
		  XtPointer   garbage2)
{
  float    scale;
  char     correct_scale [100];

  XtVaGetValues(w, XtNfloatValue, &scale, NULL);

  if (scale < 0) {
    sprintf(correct_scale, SCALEFMT, -scale);
    XtVaSetValues(w, XtNstring, correct_scale, NULL);
  }
}


/***************************************************************/
static void
correctOrientationCallback(
		  Widget      w,
		  XtPointer   garbage1,
		  XtPointer   garbage2)
{
  float    orientation;
  Boolean  change;
  char     correct_orientation [100];

  XtVaGetValues(w, XtNfloatValue, &orientation, NULL);
  change = False;

  if (orientation < 0.0)
    while (orientation < -360.0) {
      change = True;
      orientation += 360.0;
    }
  if (orientation > 0.0)
    while (orientation > 360.0) {
      change = True;
      orientation -= 360.0;
    }

  if (change) {
    sprintf(correct_orientation, ORIENTATIONFMT, orientation);
    XtVaSetValues(w, XtNstring, correct_orientation, NULL);
  }
}



/************************* Option description Table *******************/

static Cardinal opTableEntries = 0;
static XrmOptionDescRec opTable [] = {
  { "-psPlotCommand",   ".psPlotCommand",   XrmoptionSepArg,    (caddr_t)NULL}
};

/********************** MAIN PROGRAM ***************************/
/***************************************************************/

int main(
     int         argc,
     char       *argv[])
{
  Display             *display;
  XrmDatabase          opDatabase;
  XrmValue             res_value;
  char                *res_value_class;
  char                *plot84filname;
  int                  npictures;
  char                *errmsg;
  char                 txtbuf [1024], txtbuf2 [1024];
  Widget               topForm,             /* application form */
                       topLabel,            /* label - what is in list */
                       scaleLabel,
                       orientationLabel,
                       fileLabel,           /* plot84 file name */
                       cmdBar1,             /* command buttons container */
                       topQuitB,            /* application QUIT button */
                       viewPictures,        /* viewport for pictures */
                       listPictures;        /* list of plot84 pictures */



  process_name = (String)(*argv);

  XtToolkitInitialize();
  appcontext = XtCreateApplicationContext();
  if (!(display = XtOpenDisplay(appcontext, NULL,
			  process_name, app_class,
			  opTable, opTableEntries,
			  &argc, argv))) {
    sprintf(txtbuf, "%s -- cannot open display", process_name);
    XtError(txtbuf);
  }

  if (argc != 2) {
    manual();
    exit(1);
  }


  /*** root application window ***/

  sprintf(txtbuf, "%s %s", process_name, VERSION);
  topLevel = XtVaAppCreateShell(process_name, app_class,
			applicationShellWidgetClass,
			display,
			XtNtitle, txtbuf,
		        NULL);
  msg_box_ini(topLevel);

  plot84filname = argv [1];
  if (errmsg = read_plot84_file(plot84filname, &npictures, &file_descriptor,
				&plot_file_contens)) {
    msg_box(errmsg);
    picture_list = empty_list;
  }
  else {
    register int                  i;
    register PLOT84_FILE_CONTENS *pcont;
    char                          buf [50];

    picture_list = (char **)malloc(sizeof(char *) * (npictures+1));
    picture_list [npictures] = (char *)NULL;
    for (i = 0, pcont = plot_file_contens; i < npictures; ++i, ++pcont) {
      *(picture_list + i) = pcont->title;
    }
  }
      
  
  topForm = XtVaCreateManagedWidget("topForm", formWidgetClass,
			       topLevel,
			       NULL);

  cmdBar1 = XtVaCreateManagedWidget("cmdBar1", formWidgetClass,
			       topForm,
			       XtNborderWidth, 0,
			       NULL);

  topQuitB = XtVaCreateManagedWidget("Quit", commandWidgetClass,
			       cmdBar1,
			       NULL);
                XtAddCallback(topQuitB,
		               XtNcallback, topQuitBCallback,
			       NULL);

  ctrlPanelB = XtVaCreateManagedWidget("controlPanelButton",commandWidgetClass,
			       cmdBar1,
			       XtNlabel, "Control panel",
			       XtNfromHoriz, topQuitB,
			       NULL);
                XtAddCallback(ctrlPanelB,
		               XtNcallback, ctrlPanelBCallback,
			       NULL);

  fileLabel = XtVaCreateManagedWidget("fileLabel", labelWidgetClass,
			       topForm,
			       XtNlabel, plot84filname,
			       XtNfromVert, cmdBar1,
			       NULL);

  absoluteScaleType =
                XtVaCreateManagedWidget("absoluteScaleType", toggleWidgetClass,
			       topForm,
			       XtNfromVert, fileLabel,
			       NULL);
                XtAddCallback(absoluteScaleType,
		               XtNcallback, scaleTypeCallback,
			       (XtPointer)NULL);
  scaleLabel = XtVaCreateManagedWidget("topLabel", labelWidgetClass,
			       topForm,
			       XtNlabel, "scale",
			       XtNborderWidth, 0,
			       XtNfromVert, fileLabel,
			       XtNfromHoriz, absoluteScaleType,
			       NULL);
  scaleValue = XtVaCreateManagedWidget("scaleValue", editStringWidgetClass,
			       topForm,
                               XtNuseStringInPlace, True,
                               XtNeditType, XawtextEdit,
                               XtNstring, "1.0",
                               XtNformatString, SCALEFMT,
                               XtNresizable, True,
			       XtNfromVert, fileLabel,
			       XtNfromHoriz, scaleLabel,
			       NULL);
          XtAddCallback(scaleValue,
			XtNleaveNotifyCallback, correctScaleCallback, NULL);

                scaleTypeCallback(absoluteScaleType, NULL, NULL);
  orientationLabel =
               XtVaCreateManagedWidget("topLabel", labelWidgetClass,
			       topForm,
			       XtNlabel, "Orientation [Deg]:",
			       XtNborderWidth, 0,
			       XtNfromVert, scaleLabel,
			       NULL);
  orientationValue =
             XtVaCreateManagedWidget("orientationValue", editStringWidgetClass,
			       topForm,
                               XtNuseStringInPlace, True,
                               XtNeditType, XawtextEdit,
                               XtNstring, "0.0",
                               XtNformatString, ORIENTATIONFMT,
                               XtNresizable, True,
			       XtNfromVert, scaleLabel,
			       XtNfromHoriz, orientationLabel,
			       NULL);
          XtAddCallback(orientationValue,
		     XtNleaveNotifyCallback, correctOrientationCallback, NULL);


  topLabel = XtVaCreateManagedWidget("topLabel", labelWidgetClass,
			       topForm,
			       XtNlabel, topLabelText,
			       XtNborderWidth, 0,
			       XtNfromVert, orientationValue,
			       NULL);

  
  internal_listw_translations = XtParseTranslationTable(listw_translations);


  /***** Table list - shown at the begining ******/

  viewPictures = XtVaCreateManagedWidget("viewPictures", viewportWidgetClass,
			       topForm,
			       XtNforceBars, True,
			       XtNallowHoriz, True,
			       XtNallowVert, True,
			       XtNfromVert, topLabel,
			       NULL);

  listPictures = XtVaCreateManagedWidget("listPictures", listWidgetClass,
                               viewPictures,
			       XtNlist, picture_list,
			       XtNdefaultColumns, 1,
			       XtNforceColumns, True,
			       NULL);
         XtOverrideTranslations(listPictures, internal_listw_translations);
         XtAddCallback(listPictures, XtNcallback, paintPictureCallback, NULL);


  ctrlPanel = hardcopy_ctrl(topLevel, True, False, popdownCallback);

  XtRealizeWidget(topLevel);
  XtAppMainLoop(appcontext);
}
