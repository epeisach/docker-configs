/************************************************************************
  hardcopy_ctrl.h
  Z151193
************************************************************************/

#ifndef hardcopy_ctrl_
#define hardcopy_ctrl_

#include <stdio.h>

extern Widget     hardcopy_ctrl(
		       Widget         parent_w,
		       Boolean        has_postscript,
		       Boolean        has_text,
                       XtCallbackProc popdownCallback);
extern int        hardcopy_is_portrait(
		       void);
extern FILE *     hardcopy_rent_ps_file(
		       void);
extern void       hardcopy_return_ps_file(
		       int        failed);                /* flag of success */
extern FILE *     hardcopy_rent_text_file(
		       void);
extern void       hardcopy_return_text_file(
		       int        failed);                /* flag of success */

#endif /* hardcopy_ctrl_ */
