/************************************************************************
  hardcopy_ctrl.c
  Z021193
************************************************************************/

#include <errno.h>

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Toggle.h>
#include "EditString.h"

#include "sys_includes.h"
#include "hardcopy_ctrl.h"
#include "msg_box.h"

extern String     process_name;
extern String     app_class;

static Boolean    portrait_mode = True;

static String     plotFilename = (String)NULL;
static String     printFilename = (String)NULL;
static FILE      *psfile = (FILE *)NULL;
static FILE      *textfile = (FILE *)NULL;
static int        psfile_rented = 0;
static int        textfile_rented = 0;
static Widget     driver_remark_w;

static char      *psPlotCommand = (char *)NULL;
static char      *textPrintCommand = (char*)NULL;

/********************** Driver mode  ***************************/
/***************************************************************/

static char ps_file_msg [512];
static char text_file_msg [512];

/********************** CallBacks ******************************/
/***************************************************************/
static void
paperOrientationCallback(
		 Widget     w,
		 XtPointer  garbage1,
		 XtPointer  garbage2)
{
  XtVaGetValues(w, XtNstate, &portrait_mode, NULL);
  XtVaSetValues(w, XtNlabel, portrait_mode ? "Portrait " : "Landscape", NULL);
}


/***************************************************************/
static void
setPlotFilenameCallback(
		 Widget     w,
		 XtPointer  garbage1,
		 XtPointer  garbage2)
{
  String     newfilename;

  XtVaGetValues(w, XtNnewString, &newfilename, NULL);

  if      (!*newfilename        ||                  /* empty new filename */
	   !plotFilename            ||              /* new name introduced */
	   strcmp(newfilename, plotFilename)) {     /* old was changed */
    XtFree(plotFilename);
    plotFilename = (String)NULL;
    if (psfile) {
      fclose(psfile);
      psfile = (FILE *)NULL;
    }
    plotFilename = *newfilename ? XtNewString(newfilename) : (String)NULL;
  }
}


/***************************************************************//***************************************************************/
static void
setPrintFilenameCallback(
		 Widget     w,
		 XtPointer  garbage1,
		 XtPointer  garbage2)
{
  String     newfilename;

  XtVaGetValues(w, XtNnewString, &newfilename, NULL);

  if      (!*newfilename        ||                  /* empty new filename */
	   !printFilename       ||                  /* new name introduced */
	   strcmp(newfilename, printFilename)) {    /* old was changed */
    XtFree(printFilename);
    printFilename = (String)NULL;
    if (textfile) {
      fclose(textfile);
      textfile = (FILE *)NULL;
    }
    printFilename = *newfilename ? XtNewString(newfilename) : (String)NULL;
  }
}



static Boolean
filenamecheck(
	      String s)
{
  while (*s) {
    switch (*s) {
    case ' ':
    case '\t':
    case '!':
    case '?':
    case '>':
    case '<':
    case '~':
    case '`':
    case '@':
    case '$':
    case '^':
    case '(':
    case ')':
    case '*':
    case '|':
    case '=':
    case '\\':
    case ':':
    case ';':
    case '"':
    case '\'':
    case '[':
    case ']':
    case '{':
    case '}':
    case '&':
      return(False);
    }
    ++s;
  }
  return(True);
}


/***********************************************************************/
int
hardcopy_is_portrait(
		     void)
{
  return(portrait_mode ? 1 : 0);
}


/***********************************************************************/
Widget
hardcopy_ctrl(
	      Widget         parent_w,
	      Boolean        has_postscript,
	      Boolean        has_text,
              XtCallbackProc popdownCallback)
{
  Widget     whoriz, wvert, hccShell, hccForm;
  Widget     driver_select_shell, gadget;
  char     **ppc;
  XrmDatabase  opDatabase;
  XrmValue     res_value;
  char        *res_value_class;
  char         txtbuf1 [512], txtbuf2 [512];
  char         ps_file_msg [512];

  /* Plot/Print resources */
  opDatabase = XtDatabase(XtDisplay(parent_w));

  sprintf(txtbuf1, "%s.psPlotCommand", process_name);
  sprintf(txtbuf2, "%s.psPlotCommand", app_class);
  if (XrmGetResource(opDatabase, txtbuf1, txtbuf2,
                     &res_value_class, &res_value)) {
    psPlotCommand = res_value.addr;
    sprintf(ps_file_msg,
	    "(If empty, plot command \"%s\" will be used):", psPlotCommand);
  }
  else
    sprintf(ps_file_msg,
	    "(Is compulsory, plot command was not specified):");

  sprintf(txtbuf1, "%s.textPrintCommand", process_name);
  sprintf(txtbuf2, "%s.textPrintCommand", app_class);
  if (XrmGetResource(opDatabase, txtbuf1, txtbuf2,
                     &res_value_class, &res_value)) {
    textPrintCommand = res_value.addr;
    sprintf(text_file_msg,
	    "(If empty, print command \"%s\" will be used):",textPrintCommand);
  }
  else
    sprintf(text_file_msg,
	    "(Is compulsory, print command was not specified):");




  hccShell = XtVaCreatePopupShell("controlPanel", topLevelShellWidgetClass,
			       parent_w,
			       XtNtitle, "Control Panel",
			       XtNiconName,"Control Panel" ,
			       NULL);
  hccForm = XtVaCreateManagedWidget("hccForm", formWidgetClass,
			       hccShell,
			       NULL);
  wvert = XtVaCreateManagedWidget("Quit", commandWidgetClass,
			       hccForm,
			       NULL);
                XtAddCallback(wvert,
		               XtNcallback, popdownCallback,
			       (XtPointer)NULL);
  if (has_postscript) {
    wvert = XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, "Plot Driver: Postscript",
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       NULL);
    whoriz = XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, "Paper orientation:",
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       NULL);
    wvert = XtVaCreateManagedWidget("hccButton", toggleWidgetClass,
			       hccForm,
			       XtNlabel, "Portrait ",
			       XtNstate, True,
			       XtNfromVert, wvert,
			       XtNfromHoriz, whoriz,
			       NULL);
                XtAddCallback(wvert,
		               XtNcallback, paperOrientationCallback,
			       (XtPointer)NULL);
    whoriz = XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, "Output Plot File",
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       NULL);
    wvert = driver_remark_w =
       XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, ps_file_msg,
			       XtNborderWidth, 0,
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       XtNfromHoriz, whoriz,
			       NULL);
    wvert = XtVaCreateManagedWidget("hccText", editStringWidgetClass,
                               hccForm,
                               XtNuseStringInPlace, True,
                               XtNeditType, XawtextEdit,
                               XtNstring, "",
                               XtNformatString, "%-100s",
                               XtNcheckFunction, filenamecheck,
                               XtNresizable, True,
                               XtNfromVert, wvert,
                               NULL);
                XtAddCallback(wvert,
			       XtNleaveNotifyCallback, setPlotFilenameCallback,
                               NULL);
  }

  if (has_text) {
    wvert = XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, "Print Driver: Plain text",
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       NULL);
    whoriz = XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, "Output Print File",
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       NULL);
    wvert = driver_remark_w =
       XtVaCreateManagedWidget("hccLabel", labelWidgetClass,
			       hccForm,
			       XtNlabel, text_file_msg,
			       XtNborderWidth, 0,
			       XtNborderWidth, 0,
			       XtNfromVert, wvert,
			       XtNfromHoriz, whoriz,
			       NULL);

    wvert = XtVaCreateManagedWidget("hccText", editStringWidgetClass,
                               hccForm,
                               XtNuseStringInPlace, True,
                               XtNeditType, XawtextEdit,
                               XtNstring, "",
                               XtNformatString, "%-100s",
                               XtNcheckFunction, filenamecheck,
                               XtNresizable, True,
                               XtNfromVert, wvert,
                               NULL);
                XtAddCallback(wvert,
			      XtNleaveNotifyCallback, setPrintFilenameCallback,
                              NULL);
  }

  return(hccShell);
}


/*****************************************************************************/
FILE *
hardcopy_rent_ps_file(
		      void)
{
  char    errmsg [1024];

  if (psfile_rented)
    XtError("hardcopy_rent_ps_file - system error - program is a sh...");

  if      (plotFilename) {
    if (!psfile) {
      if (!(psfile = fopen(plotFilename, "w"))) {
	sprintf(errmsg, "Cannot open Postscript file: %s\n%s",
		plotFilename, strerror(errno));
	msg_box(errmsg);
      }
      else
	psfile_rented = 1;
    }
    else
      psfile_rented = 1;
  }
  else if (psPlotCommand) {
    if (!(psfile = popen(psPlotCommand, "w"))) {
      sprintf(errmsg, "Cannot execute command: %s\n%s",
	      plotFilename, strerror(errno));
	msg_box(errmsg);
    }
    else
      psfile_rented = 1;
  }
  else {
    msg_box("Postscript plot command not specified\nuse control panel");
    psfile_rented = 1;
  }
  return(psfile);
}


/*****************************************************************************/
void
hardcopy_return_ps_file(
			int failed)
{
  char      message [512];

  psfile_rented = 0;

  if (!psfile)
    return;

  fflush(psfile);
  if (!plotFilename) {        /* was a pipe to spooler */
    pclose(psfile);
    psfile = (FILE *)NULL;
    if (!failed) {
      sprintf(message, "Picture ploted using command \"%s\"", psPlotCommand);
      msg_box(message);
    }
  }
  else {
    if (!failed) {
      sprintf(message, "Picture written into file \"%s\"", plotFilename);
      msg_box(message);
    }
  }
}

/*****************************************************************************/
FILE *
hardcopy_rent_text_file(void)
{
  char    errmsg [1024];

  if (textfile_rented)
    XtError("hardcopy_rent_text_file - system error - program is a sh...");

  if      (printFilename) {
    if (!textfile) {
      if (!(textfile = fopen(printFilename, "w"))) {
	sprintf(errmsg, "Cannot open Plain Text file: %s\n%s",
		printFilename, strerror(errno));
	msg_box(errmsg);
      }
      else
	textfile_rented = 1;
    }
    else
      textfile_rented = 1;
  }
  else if (textPrintCommand) {
    if (!(textfile = popen(textPrintCommand, "w"))) {
      sprintf(errmsg, "Cannot execute command: %s\n%s",
	      printFilename, strerror(errno));
	msg_box(errmsg);
    }
    else
      textfile_rented = 1;
  }
  else {
    msg_box("Text Print command not specified\nuse control panel");
    textfile_rented = 1;
  }
  return(textfile);
}


/*****************************************************************************/
void
hardcopy_return_text_file(int failed)
{
  char      message [512];

  textfile_rented = 0;

  if (!textfile)
    return;

  fflush(textfile);
  if (!printFilename) {        /* was a pipe to spooler */
    pclose(textfile);
    textfile = (FILE *)NULL;
    if (!failed) {
      sprintf(message, "Text printed using command \"%s\"", textPrintCommand);
      msg_box(message);
    }
  }
  else {
    if (!failed) {
      sprintf(message, "Text written into file \"%s\"", printFilename);
      msg_box(message);
    }
  }
}
