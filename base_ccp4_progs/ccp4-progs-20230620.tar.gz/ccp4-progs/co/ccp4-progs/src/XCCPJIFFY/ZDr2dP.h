/***************************************************************************
  ZDr2dP.h
  Z200592

Private header file for ZDr2d widget
***************************************************************************/
#ifndef _ZDr2dP_h
#define _ZDr2dP_h

/*** ZDr2d class part ***/

typedef struct _ZDr2dClassPart {      /* ZDr2d class part */
  int               ignore;           /* nothing  */
} ZDr2dClassPart;

/*** ZDr2d class record declaration ***/

typedef struct _ZDr2dClassRec{       /* ZDr2d class record declaration */
  CoreClassPart    core_class;       /* inherited core-class part */
  ZDr2dClassPart   zDr2d_class;      /* own part */
} ZDr2dClassRec;

extern ZDr2dClassRec zDr2dClassRec;   /* ZDr2d class record definition */


/**************************************************************************/

#define NPEN 10                      /* # of default pens (GC) */

typedef struct {
  Pixel        color;
  int          linewidth;
} PEN;

/*** instruction data types ***/

#define POLYLINE_TYPE           1
#define CHANGE_PEN_TYPE         2
#define CHANGE_COLOR_TYPE       3
#define CHANGE_LINE_WIDTH_TYPE  4

typedef struct polyline {
  float       x, y;
} POLYLINE;

typedef struct instruction {
  int                  instruction_type;
  struct instruction  *next;
  int                  n_subinstructions;
  union {
    POLYLINE  *poly_line;
    int        pen_num;
    int        color_num;
    Dimension  line_width;
  }                   instrc;
  XtPointer           X11_buf;
} INSTRUCTION;

typedef struct gr_object {
  struct gr_object *next;            /* next object in the same level */
  struct gr_object *sub_object;      /* 1st sub-object */
  XtPointer         objid;           /* User suplied number (ID) of the
					object used for further
					references (= 0 if not necessary) */
  INSTRUCTION      *instructions;    /* -> to chain of instructions */
} GR_OBJECT;

typedef struct _ZDr2dPart {

  /*** resources ***/

  XtPointer     scene_limits;        /* scene limits (if supproted) */
  Dimension     horizMargin;         /* horizontal margin in pixels */
  Dimension     vertMargin;          /* vertical margin in pixels */
  PEN           pen [NPEN];          /* pen descriptor database */
  Pixel         color [NPEN];        /* color database */
  char         *ps_pen [NPEN];       /* Postscript pen descriptor database */
  char         *ps_color [NPEN];     /* Postscript commans to modify color */
  char         *ps_default_attr;     /* Default postscript line attributes */
  float         ps_basic_line_width; /* Basic line width unit for postscript */

/*
  XtCallbackList curs_pos;           * callback *
*/

  /*** Internal data ***/

  String        scene_label;         /* label taken from scene dsc */
  float         min_x, max_x;        /* limits taken from scene dsc or */
  float         min_y, max_y;        /* calculated from data */
  Boolean       abs_scale;           /* coordinates are in [mm] */
  float         scale;               /* coeficient for absolute scale */
  Boolean       shift_to_min;        /* calculate real x, y as x-minx y-miny */
  OriginPosition origin;             /* Position of the origin point (0,0) */
  Boolean       max_scene_size;      /* Scene dimensioned to the worst case */
  float         orientation;         /* scene orientation [deg clockwise] */

  float         tot_scale;           /* total scale */
  float         scene_rot_matrix [2][2]; /* rotation matrix for scene */
  float         scene_shift_vector [2];  /* shift vector for scene */

  long          serverlimit;         /* server limit for max request size */
  float         pixel_to_mm_ratio;   /* current pixels per inch value */
  GC            gc;                  /* graphic context used */

  Boolean       render;              /* when set, actual drawing is done */
  Boolean       limits_from_scene_limits; /* how did we obtain limit values */
  GR_OBJECT    *objects;             /* graphic objects */
  GR_OBJECT    *current_object;      /* object being modified */
  INSTRUCTION  *current_instr;       /* instruction being modified */
  int           current_pen;         /* currently ised pen */
  int           free_slots;          /* free slots in current instruction */
  float         current_pointx;      /* points within current instruction */
  float         current_pointy;
  Boolean       lastwasmove;         /* flag for current instruction */
} ZDr2dPart;

/*** zDr2d record ***/

typedef struct _ZDr2dRec {
   CorePart           core;           /* Inherited Core part */
   ZDr2dPart          zDr2d;          /* own part */
} ZDr2dRec;

#endif /*_ZDr2dP_h */
