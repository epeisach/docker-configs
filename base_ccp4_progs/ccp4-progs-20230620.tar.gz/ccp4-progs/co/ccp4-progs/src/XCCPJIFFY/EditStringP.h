/***********************************************************
  EditStringP.h
  IVersion Z191191

***********************************************************/


#ifndef _EditStringP_h
#define _EditStringP_h

#include <X11/Intrinsic.h>
#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

/*** include superclass private header file ***/

#include <X11/Xaw/TextSinkP.h>
#include <X11/Xaw/AsciiTextP.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/AsciiSrcP.h>

#include "EditString.h"

/*** define unique representation types not found in <X11/StringDefs.h> ***/

/*#define XtRTemplateResource "TemplateResource"*/

typedef struct {
    int empty;
} EditStringClassPart;

typedef struct _EditStringClassRec {
    CoreClassPart	core_class;
    SimpleClassPart	simple_class;
    TextClassPart	text_class;
    AsciiClassPart	ascii_class;
    EditStringClassPart	editString_class;
} EditStringClassRec;

extern EditStringClassRec editStringClassRec;

typedef struct _EditStringPart{
    /* resources */
  String          format_string;
  String          string;
  int             string_length;
  String          new_string;
  Boolean         use_string_in_place;
  float           float_value;
  int             int_value;
  CheckFunction   check_function;
  XtCallbackList  value_change_callback;
  XtCallbackList  leave_callback;
  XtCallbackList  enterpress_callback;
    /* private state */
  String          old_string;
  XawTextBlock    backup;
  XawTextPosition text_position;
  int             data_type;
  Boolean         isright_justified;
} EditStringPart;

typedef struct _EditStringRec {
    CorePart		core;
    SimplePart		simple;
    TextPart		text;
    AsciiPart           ascii;
    EditStringPart	editString;
} EditStringRec;

#endif /* _EditStringP_h */
