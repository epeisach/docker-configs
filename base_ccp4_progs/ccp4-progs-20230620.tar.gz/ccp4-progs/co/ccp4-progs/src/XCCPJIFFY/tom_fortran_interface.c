/******************************************************************************
  tom_fortran_interface.c
  Z270592
******************************************************************************/

#include <stdio.h>
#include "tom_fortran_interface.h"
#include "ZDr2d.h"

char            *fontPath = (char *)NULL;
extern Widget   current_draw_w;
extern String   process_name, app_class;



/************************************************************************/
void
TOM_GFPTH(
       char      *path)
{
  XrmDatabase      opDatabase;
  XrmValue         res_value;
  char            *res_value_class;
  char             txtbuf [1024], txtbuf2 [1024];

  if (!fontPath) {
    opDatabase = XtDatabase(XtDisplay(current_draw_w));
    sprintf(txtbuf, "%s.tomFontPath", process_name);
    sprintf(txtbuf2, "%s.tomFontPath", app_class);
    if (XrmGetResource(opDatabase, txtbuf, txtbuf2,
		       &res_value_class, &res_value))
      fontPath = res_value.addr;
    else {
      sprintf(txtbuf, "%s -- Tom's font file not specified", process_name);
      XtError(txtbuf);
    }
  }
    
  strcpy(path, fontPath);
}


/************************************************************************/
void
TOM_FINISH_GRAPHICS(
		 void)
{
  XZDr2dFinishObject(current_draw_w);
}


/************************************************************************/
void
TOM_START_OBJECT(
	      int    *num)  /* # of object. Tom's actual policy is */
                            /* 1 for axes, 2, 3, ... for each graph curve */
{
  XZDr2dNewObject(current_draw_w, (XtPointer)(*num), *num, (XtPointer)NULL,
		  (ZDR2D_MATRIX *)NULL);
}


/************************************************************************/
void
TOM_FINISH_OBJECT(
	       void)
{
  XZDr2dFinishObject(current_draw_w);
}


/************************************************************************/
void
TOM_GRAPH_MOVE(
	    float *x,
	    float *y)
{
  XZDr2dMoveto(current_draw_w, *x, *y);
}


/************************************************************************/
void
TOM_GRAPH_DRAW(
	    float *x,
	    float *y)
{
  XZDr2dLineto(current_draw_w, *x, *y);
}


/************************************************************************/
void
TOM_GRAPH_COL(                   /* color - which pen is choosen */
	   int   *pen)
{
  XZDr2dChangePen(current_draw_w, *pen);
}


/************************************************************************/
void
TOM_GRAPH_ALPHA(
	     void)
{
}


/************************************************************************/
void
TOM_GRAPH_CURSOR(
	      void)
{
}
