/******************************************************************************
  xloggraph.c

  Reads (ccp4) logfile and displays graphs.

  Application class:             XCCPJiffy
  Default application instance:  xloggraph
******************************************************************************/

#define VERSION "Z010394"

#include <stdio.h>

#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/Viewport.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/AsciiText.h>


#include "log_file.h"
#include "msg_box.h"
#include "hardcopy_ctrl.h"


String           process_name;
String           app_class = "XCCPJiffy";
XtAppContext     appcontext;          /* application context */
XtTranslations   text_translations;

static Widget topLevel,            /* application shell */
              topLabel,            /* label - what is in list */

              showTableB,          /* show selector for tables (button) */
              showKeyTextB,        /* show selector for key text (button) */
              showTextB,           /* show selector for text (button) */
              showSummaryB,        /* show selector for summaries (button) */
              viewFileB,           /* display log file text (button) */
              viewFileShell,       /* this holds file text */

              ctrlPanel,           /* hardcopy control panel */
              ctrlPanelB,          /* hardcopy control panel Button*/

              viewTables,          /* viewport for tables */
              listTables,          /* list of tables */
              viewGraphs,          /* viewport for graph list */
              listGraphs,          /* list of graphs */
              viewTexts,           /* viewport for texts list */
              listTexts,           /* list of texts */
              viewSummaries,       /* viewport for summaries list */
              listSummaries,       /* list of summaries */
              viewKeyTexts,        /* viewport for key texts list */
              listKeyTexts;        /* list of key texts */

static char                 *topLabelTextTable = "Select from Tables:";
static char                 *topLabelTextGraph = "Select from Graphs:";
static char                 *topLabelTextKeyText = "Select from Key Texts:";
static char                 *topLabelTextText = "Select from Texts:";
static char                 *topLabelSummaryText = "Select from Summaries:";
static int                   current_table_num;

static char listw_translations[] = {           /* list - widget transaltions */
  "<Btn1Up>:       Notify() Unset()              \n\
   <Btn2Up>:       Notify() Unset()              \n\
   <Btn3Up>:       Notify() Unset()              \n\
   <Motion>:       Set()                         \n\
   <LeaveNotify>:  Unset()                       \n\
"};

static XtTranslations    internal_listw_translations;

static char ascii_text_translations[] = {  /* ascii-text widget translations */ "<Key>Next:          next-page()                \n\
  Mod1<Key>F:         forward-word()             \n\
  Mod1<Key>B:         backward-word()            \n\
  Mod1<Key>I:         insert-file()              \n\
  Mod1<Key>K:         kill-to-end-of-paragraph() \n\
  Mod1<Key>V:         previous-page()            \n\
  <Key>Prior:         previous-page()            \n\
  Mod1<Key>Z:         scroll-one-line-down()     \n\
  :Mod1<Key>d:        delete-next-word()         \n\
  :Mod1<Key>D:        kill-word()                \n\
  :Mod1<Key>h:        delete-previous-word()     \n\
  :Mod1<Key>H:        backward-kill-word()       \n\
  :Mod1<Key><:        beginning-of-file()        \n\
   <Key>Home:         beginning-of-file()        \n\
  :Mod1<Key>>:        end-of-file()              \n\
   <Key>End:          end-of-file()              \n\
  :Mod1<Key>]:        forward-paragraph()        \n\
  :Mod1<Key>[:        backward-paragraph()       \n\
  ~Shift Mod1<Key>Delete:     delete-previous-word()        \n\
   Shift Mod1<Key>Delete:     backward-kill-word()          \n\
  ~Shift Mod1<Key>BackSpace:  delete-previous-word()        \n\
   Shift Mod1<Key>BackSpace:  backward-kill-word()          \n\
"};

/********************** Manual *********************************/

static void
manual(
       void)
{
fprintf(stderr,
"\
\n\
****************************************************************************\n\
Run %s using command\n\
\n\
%s logfilename &\n\
\n\
    Do not forget about the xccpjiffy2idraw utility, which can convert\n\
    postscript file created by %s into format readable by idraw\n\
    (postscript editor). Use it as\n\
\n\
       xccpjiffy2idraw <ps_file  >idraw_ps_file\n",
process_name, process_name, process_name);


fprintf(stderr, "\n\n\n\n\n\
****************************************************************************\n\
Remarks for application programmers:\n\
\n\
Syntax of Graph description in Log file:\n\n\
$TABLE :table name:\n\
$GRAPHS :graph1 name:graphtype:column_list: \
:graph2 name:graphtype:column_list:\n\
        :graph 3 ...: ... $$\n\
column1_name column2_name ... $$ any_characters $$ numbers $$\n\n");

fprintf(stderr,"\n\
Where:\n\
  table name, graphN name are arbitrary strings (without newline)\n\
  columnN_name            are arbitrary strings without tab, space, newline\n\
  graphtype               is  - A[UTO]   for fully automatic scaling\n\
                                         (e.g. ... :A:1,2,4,5:)\n\
                              - N[OUGHT] for automatic y coordinate scaling,\n\
                                         where y lowest limit is 0\n\
                                         (e.g. ... :N:1,2,4,5:)\n\
                              - XMIN|XMAXxYMIN|YMAX for user defined scaling\n\
                                         where XMIN ... are axis limits\n\
                                         (e.g. ... :0|100x-1|1:1,2,4,5:)\n\
  any_characters           are treated as a comment. They can be eventually\n\
                              used as a human oriented table header\n\
  numbers                  represents the table itself. (See parsing\n\
                              algorithm below)\n");

fprintf(stderr,"\n\
Parsing algorithm for the table:\n\
  Table values (numbers) are read using unformatted read command. This\n\
  implies, that they MUST be separated by space(s) and/or tab(s) and/or\n\
  newline(s). Parsing is performed on a logical line basis, where a logical\n\
  line begins with a newline, followed by a number of values corresponding\n\
  to the number of table columns, an optional comment (any characters)\n\
  up to the next newline delimiter. The term 'logical' is used, because\n\
  this 'logical' line can consist of several 'physical' lines, where\n\
  newlines between values are treated as ordinary delimiters.\n");

fprintf(stderr, "\n\n\
Syntax of the Text description in Log file:\n\
$TEXT :text name: $$ junk (ignored) text $$any text characters$$\n");

fprintf(stderr, "\n\n\
Syntax of the Key Text description in Log file:\n\
$KEYTEXT :text name: $$any text characters$$keyword_with_values$$\n\
  any_characters        - are the descriptive text\n\
  keyword_with_values   - is a keyworded format of data\n");

fprintf(stderr, "\n\n\
Synatx of Summary description:\n\
$SUMMARY :summary_name: $$ any characters $$\n\
     :component_type:component_name: :component_type:component_name: ...$$\n\
  component_type        - is `TEXT` either `KEYTEXT`\n\
  component_name        - is it's name\n\
\n\
  Due to one pass parsing all TEXTs and KEYTEXTs must be defined BEFORE the\n\
  SUMMARY\n");

fprintf(stderr, "\n\n\n\
****************************************************************************\n\
Current error:\n\
%s -- command line must contain exactly one Log_file_name\n",
process_name);
}




/********************** CallBacks ******************************/
/***************************************************************/
static void
topQuitBCallback(
		 Widget     w,
		 XtPointer  garbage1,
		 XtPointer  garbage2)
{
  exit(0);
}

/***************************************************************/
static void
showGraphsCallback(
		  Widget      w,
		  XtPointer   garbage,
		  XtPointer   xtlist)
/*** Paint selected graph ***/
{
  XawListReturnStruct *list;
  char               **newlist;

  list = (XawListReturnStruct *)xtlist;
  current_table_num = list->list_index;
  newlist = log_file_graphs(current_table_num);
  XawListChange(listGraphs, newlist, 0, 0, True);
  XtMapWidget(viewGraphs);
  XtVaSetValues(topLabel,          /* label displayed */
                XtNlabel, topLabelTextGraph,
                NULL);
  XtVaSetValues(showTableB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
}


/***************************************************************/
static void
interpretGraphCallback(
                   Widget     w,
                   XtPointer  garbage1,
                   XtPointer  xtlist)
/*** Display one graph for the given table ***/
{
  interpret_log_graph(current_table_num,
		      ((XawListReturnStruct *)xtlist)->list_index, topLevel);
}


/***************************************************************/
static void
showTablesCallback(
                   Widget     w,
                   XtPointer  garbage1,
                   XtPointer  garbage2)
/*** List table names ***/
{
  XtUnmapWidget(viewGraphs);       /* undisplay graph names */
  XtUnmapWidget(viewKeyTexts);     /* undisplay key text names */
  XtUnmapWidget(viewTexts);        /* undisplay text names */
  XtUnmapWidget(viewSummaries);   /* undisplay summary names */

  XtVaSetValues(showTableB,        /* button sensitivity */
                XtNsensitive, False,
                NULL);
  XtVaSetValues(showKeyTextB,       /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showTextB,          /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showSummaryB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showSummaryB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(topLabel,          /* label displayed */
                XtNlabel, topLabelTextTable,
                NULL);
}


/***************************************************************/
static void
showKeyTextsCallback(
                   Widget     w,
                   XtPointer  garbage1,
                   XtPointer  garbage2)
/*** List table names ***/
{
  XtUnmapWidget(viewGraphs);       /* undisplay graph names */
  XtUnmapWidget(viewTexts);        /* undisplay text names */
  XtUnmapWidget(viewSummaries);   /* undisplay summary names */

  XtMapWidget(viewKeyTexts);

  XtVaSetValues(showTableB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showKeyTextB,        /* button sensitivity */
                XtNsensitive, False,
                NULL);
  XtVaSetValues(showTextB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showSummaryB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(topLabel,          /* label displayed */
                XtNlabel, topLabelTextKeyText,
                NULL);
}


/***************************************************************/
static void
interpretKeyTextCallback(
			 Widget     w,
			 XtPointer  garbage1,
			 XtPointer  xtlist)
/*** Display one graph for the given table ***/
{
  interpret_log_keytext(((XawListReturnStruct *)xtlist)->list_index, topLevel);
}


/***************************************************************/
static void
showTextsCallback(
		  Widget     w,
		  XtPointer  garbage1,
		  XtPointer  garbage2)
/*** List texts names ***/
{
  XtUnmapWidget(viewGraphs);       /* undisplay graph names */
  XtUnmapWidget(viewKeyTexts);     /* undisplay key text names */
  XtUnmapWidget(viewSummaries);   /* undisplay summary names */

  XtMapWidget(viewTexts);

  XtVaSetValues(showTableB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showKeyTextB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showSummaryB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showTextB,        /* button sensitivity */
                XtNsensitive, False,
                NULL);
  XtVaSetValues(topLabel,          /* label displayed */
                XtNlabel, topLabelTextText,
                NULL);
}


/***************************************************************/
static void
interpretTextCallback(
		      Widget     w,
		      XtPointer  garbage1,
		      XtPointer  xtlist)
/*** Display one text ***/
{
  interpret_log_text(((XawListReturnStruct *)xtlist)->list_index, topLevel);
}

/***************************************************************/
static void
showSummariesCallback(
		  Widget     w,
		  XtPointer  garbage1,
		  XtPointer  garbage2)
/*** List texts names ***/
{
  XtUnmapWidget(viewGraphs);       /* undisplay graph names */
  XtUnmapWidget(viewKeyTexts);     /* undisplay key text names */
  XtUnmapWidget(viewTexts);        /* undisplay text names */

  XtMapWidget(viewSummaries);

  XtVaSetValues(showTableB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showKeyTextB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showTextB,        /* button sensitivity */
                XtNsensitive, True,
                NULL);
  XtVaSetValues(showSummaryB,        /* button sensitivity */
                XtNsensitive, False,
                NULL);
  XtVaSetValues(topLabel,          /* label displayed */
                XtNlabel, topLabelSummaryText,
                NULL);
}


/***************************************************************/
static void
interpretSummaryCallback(
		      Widget     w,
		      XtPointer  garbage1,
		      XtPointer  xtlist)
/*** Display one text ***/
{
  interpret_log_summary(((XawListReturnStruct *)xtlist)->list_index, topLevel);
}


/***************************************************************/
static void
showFileCallback(
                   Widget     w,
                   XtPointer  garbage1,
                   XtPointer  garbage2)
/*** Display entire log file ***/
{
  XtVaSetValues(viewFileB, XtNsensitive, False, NULL);
  XtMapWidget(viewFileShell);
}


/***************************************************************/
static void
doneFileBCallback(
                  Widget      w,
                  XtPointer   garbage1,
                  XtPointer   garbage2)
/*** Remove file contens text window ***/
{
  XtUnmapWidget(viewFileShell);
  XtVaSetValues(viewFileB,
                XtNsensitive, True,
                NULL);
}


/***************************************************************/
static void
printFileBCallback(
                  Widget      w,
                  XtPointer   garbage1,
                  XtPointer   garbage2)
{
  FILE  *fp;

  if (!(fp = hardcopy_rent_text_file()))
    hardcopy_return_text_file(True);
  else {
    fprintf(fp, "%s", log_file_text());
    hardcopy_return_text_file(False);
  }
}


/***************************************************************/
static void
ctrlPanelBCallback(
		  Widget      w,
		  XtPointer   garbage1,
		  XtPointer   garbage2)
/*** Display Hardcopy control panel ***/
{
  XtPopup(ctrlPanel, XtGrabNone);
  XtVaSetValues(ctrlPanelB, XtNsensitive, False, NULL);
}

/***************************************************************/
static void
popdownCallback(
		  Widget      w,
		  XtPointer   garbage1,
		  XtPointer   garbage2)
/*** (Un)Display Hardcopy control panel ***/
{
  XtPopdown(ctrlPanel);
  XtVaSetValues(ctrlPanelB, XtNsensitive, True, NULL);
}



/************************* Option description Table *******************/

static Cardinal opTableEntries = 0;
static XrmOptionDescRec opTable [] = {
  { "-psPlotCommand",   ".psPlotCommand",   XrmoptionSepArg,    (caddr_t)NULL},
  { "-tomFontPath",     ".tomFontPath",     XrmoptionSepArg,    (caddr_t)NULL}
};

/********************** MAIN PROGRAM ***************************/
/***************************************************************/

main(
     Cardinal    argc,
     char       *argv[])
{
  Display             *display;
  XrmDatabase          opDatabase;
  XrmValue             res_value;
  char                *res_value_class;
  char                *logfilname;
  int                  ntables;
  char                *errmsg;
  char                 txtbuf [1024], txtbuf2 [1024];
  Widget               topForm,             /* application form */
                       fileLabel,           /* plot84 file name */
                       cmdBar1,             /* command buttons container */
                       topQuitB,            /* application QUIT button */
                       viewFileForm,        /* within view file window */
                       doneFileB,
                       printFileB,
                       textFile;



  process_name = (String)(*argv);

  XtToolkitInitialize();
  appcontext = XtCreateApplicationContext();
  if (!(display = XtOpenDisplay(appcontext, NULL,
			  process_name, app_class,
			  opTable, opTableEntries,
			  &argc, argv))) {
    sprintf(txtbuf, "%s -- cannot open display", process_name);
    XtError(txtbuf);
  }

  if (argc != 2) {
    manual();
    exit(1);
  }


  /*** root application window ***/

  sprintf(txtbuf, "%s %s", process_name, VERSION);
  topLevel = XtVaAppCreateShell(process_name, app_class,
			applicationShellWidgetClass,
			display,
			XtNtitle, txtbuf,
		        NULL);
  msg_box_ini(topLevel);

  logfilname = argv [1];

  if (errmsg = read_log_file(logfilname))
    msg_box(errmsg);

  topForm = XtVaCreateManagedWidget("form", formWidgetClass,
			       topLevel,
			       NULL);

  cmdBar1 = XtVaCreateManagedWidget("cmdBar1", formWidgetClass,
			       topForm,
			       XtNborderWidth, 0,
			       NULL);

  topQuitB = XtVaCreateManagedWidget("Quit", commandWidgetClass,
			       cmdBar1,
			       NULL);
                XtAddCallback(topQuitB,
		               XtNcallback, topQuitBCallback,
			       NULL);


  viewFileB = XtVaCreateManagedWidget("viewFile", commandWidgetClass,
                               cmdBar1,
			       XtNlabel, "View file",
                               XtNfromHoriz, topQuitB,
                               NULL);
                XtAddCallback(viewFileB,
                               XtNcallback, showFileCallback,
                               NULL);

  ctrlPanelB = XtVaCreateManagedWidget("controlPanelButton",commandWidgetClass,
			       cmdBar1,
			       XtNlabel, "Control panel",
			       XtNfromHoriz, viewFileB,
			       NULL);
                XtAddCallback(ctrlPanelB,
		               XtNcallback, ctrlPanelBCallback,
			       NULL);
  showTableB = XtVaCreateManagedWidget("showTableList", commandWidgetClass,
                               cmdBar1,
			       XtNlabel, "Show Table List",
                               XtNsensitive, False,
                               XtNfromVert, topQuitB,
                               NULL);
                XtAddCallback(showTableB,
                               XtNcallback, showTablesCallback,
                               NULL);

  showKeyTextB = XtVaCreateManagedWidget("showKeyTextList", commandWidgetClass,
                               cmdBar1,
			       XtNlabel, "Show Key Text List",
                               XtNfromVert, showTableB,
                               NULL);
                XtAddCallback(showKeyTextB,
                               XtNcallback, showKeyTextsCallback,
                               NULL);

  showTextB = XtVaCreateManagedWidget("showTextList", commandWidgetClass,
                               cmdBar1,
			       XtNlabel, "Show Text List",
                               XtNfromVert, showKeyTextB,
                               NULL);
                XtAddCallback(showTextB,
                               XtNcallback, showTextsCallback,
                               NULL);

  showSummaryB = XtVaCreateManagedWidget("showSummaryList", commandWidgetClass,
                               cmdBar1,
			       XtNlabel, "Show Summary List",
                               XtNfromVert, showTextB,
                               NULL);
                XtAddCallback(showSummaryB,
                               XtNcallback, showSummariesCallback,
                               NULL);

  fileLabel = XtVaCreateManagedWidget("fileLabel", labelWidgetClass,
			       topForm,
			       XtNlabel, logfilname,
			       XtNfromVert, cmdBar1,
			       NULL);

  topLabel = XtVaCreateManagedWidget("topLabel", labelWidgetClass,
			       topForm,
			       XtNlabel, topLabelTextTable,
			       XtNborderWidth, 0,
			       XtNresize, True,
			       XtNresizable, True,
			       XtNfromVert, fileLabel,
			       NULL);

  
  internal_listw_translations = XtParseTranslationTable(listw_translations);


  /***** Graph list ******/

  viewGraphs = XtVaCreateManagedWidget("viewTables", viewportWidgetClass,
			       topForm,
			       XtNforceBars, True,
			       XtNallowHoriz, True,
			       XtNallowVert, True,
			       XtNfromVert, topLabel,
			       XtNmappedWhenManaged, False,
			       NULL);

  listGraphs = XtVaCreateManagedWidget("listGraphs", listWidgetClass,
                               viewGraphs,
			       XtNdefaultColumns, 1,
			       XtNforceColumns, True,
			       NULL);
         XtOverrideTranslations(listGraphs, internal_listw_translations);
         XtAddCallback(listGraphs, XtNcallback, interpretGraphCallback, NULL);


  /***** Key texts list ******/

  viewKeyTexts = XtVaCreateManagedWidget("viewTables", viewportWidgetClass,
			       topForm,
			       XtNforceBars, True,
			       XtNallowHoriz, True,
			       XtNallowVert, True,
			       XtNfromVert, topLabel,
			       XtNmappedWhenManaged, False,
			       NULL);

  listKeyTexts = XtVaCreateManagedWidget("listKeyTexts", listWidgetClass,
                               viewKeyTexts,
			       XtNlist, log_file_keytexts(),
			       XtNdefaultColumns, 1,
			       XtNforceColumns, True,
			       NULL);
      XtOverrideTranslations(listKeyTexts, internal_listw_translations);
      XtAddCallback(listKeyTexts, XtNcallback, interpretKeyTextCallback, NULL);


  /***** Texts list ******/

  viewTexts = XtVaCreateManagedWidget("viewTables", viewportWidgetClass,
			       topForm,
			       XtNforceBars, True,
			       XtNallowHoriz, True,
			       XtNallowVert, True,
			       XtNfromVert, topLabel,
			       XtNmappedWhenManaged, False,
			       NULL);

  listTexts = XtVaCreateManagedWidget("listTexts", listWidgetClass,
                               viewTexts,
			       XtNlist, log_file_texts(),
			       XtNdefaultColumns, 1,
			       XtNforceColumns, True,
			       NULL);
         XtOverrideTranslations(listTexts, internal_listw_translations);
         XtAddCallback(listTexts, XtNcallback, interpretTextCallback, NULL);


  /***** Summary list ******/

  viewSummaries = XtVaCreateManagedWidget("viewTables", viewportWidgetClass,
			       topForm,
			       XtNforceBars, True,
			       XtNallowHoriz, True,
			       XtNallowVert, True,
			       XtNfromVert, topLabel,
			       XtNmappedWhenManaged, False,
			       NULL);

  listSummaries = XtVaCreateManagedWidget("listSummaries", listWidgetClass,
                               viewSummaries,
			       XtNlist, log_file_summaries(),
			       XtNdefaultColumns, 1,
			       XtNforceColumns, True,
			       NULL);
     XtOverrideTranslations(listSummaries, internal_listw_translations);
     XtAddCallback(listSummaries, XtNcallback, interpretSummaryCallback, NULL);

  /***** Table list - shown at the begining ******/

  viewTables = XtVaCreateManagedWidget("viewTables", viewportWidgetClass,
			       topForm,
			       XtNforceBars, True,
			       XtNallowHoriz, True,
			       XtNallowVert, True,
			       XtNfromVert, topLabel,
			       NULL);

  listTables = XtVaCreateManagedWidget("listTables", listWidgetClass,
                               viewTables,
			       XtNlist, log_file_tables(),
			       XtNdefaultColumns, 1,
			       XtNforceColumns, True,
			       NULL);
         XtOverrideTranslations(listTables, internal_listw_translations);
         XtAddCallback(listTables, XtNcallback, showGraphsCallback, NULL);

  /*** Text of the log file ***/

  viewFileShell =  XtVaCreatePopupShell("viewFile", topLevelShellWidgetClass,
                                  topLevel,
                                  NULL);

  viewFileForm = XtVaCreateManagedWidget("form", formWidgetClass,
                               viewFileShell,
                               NULL);

  doneFileB = XtVaCreateManagedWidget("Quit", commandWidgetClass,
                               viewFileForm,
                               NULL);
                XtAddCallback(doneFileB,
                               XtNcallback, doneFileBCallback,
                               NULL);
  printFileB = XtVaCreateManagedWidget("Print", commandWidgetClass,
                               viewFileForm,
                               XtNfromHoriz, doneFileB,
                               NULL);
                XtAddCallback(printFileB,
                               XtNcallback, printFileBCallback,
                               NULL);
  textFile = XtVaCreateManagedWidget("textFile", asciiTextWidgetClass,
                               viewFileForm,
                               XtNeditType, XawtextRead,
                               XtNdisplayCaret, True,
                               XtNstring, log_file_text(),
                               XtNuseStringInPlace, True,
                               XtNscrollVertical, XawtextScrollAlways,
                               XtNscrollHorizontal, XawtextScrollWhenNeeded,
                               XtNfromVert, doneFileB,
                               NULL);
    text_translations = XtParseTranslationTable(ascii_text_translations);
    XtOverrideTranslations(textFile, text_translations);

  ctrlPanel = hardcopy_ctrl(topLevel, True, True, popdownCallback);

  XtRealizeWidget(topLevel);
  XtRealizeWidget(viewFileShell);
  XtAppMainLoop(appcontext);
}
