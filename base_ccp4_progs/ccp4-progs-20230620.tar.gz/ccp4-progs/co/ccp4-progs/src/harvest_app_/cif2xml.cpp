//
//     CIF2XML
//     Copyright (C) 2003 Pryank Patel
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//

// =================================================================
//
//  MacroMolecular Data Base (MMDB)
//
//  File  mmcif_xml.cpp
//
//  Example:
//     Converting mmCIF to XML files.
//
//  07 Nov 2002
//
//  Make:  cc -o mmcif_xml mmcif_xml.cpp mmdb.a -lm -lC
//
//  E. Krissinel
//
// =================================================================
//

#include <string.h>
#include <math.h>

#include "mmdb2/mmdb_xml_.h"

#include "ccp4/ccp4_parser.h"
#include "ccp4/ccp4_general.h"
#include "ccp4/ccp4_program.h"

using namespace CCP4;

void  PrintInstructions ( mmdb::pstr argv0 )  {
  printf ( 
    "\n"
    "Command line syntax:\n"
    "~~~~~~~~~~~~~~~~~~~~\n"
    "\n"
    "%s mmcif_file xml_file\n"
    "\n"
    "where xml_file will be created.\n"
    "\n",argv0
         );
}


int main ( int argc, char ** argv, char ** env )  {
mmdb::mmcif::PData    mmCIF;
mmdb::xml::PXMLObject XML;
int                   rc;


CCP4PARSERTOKEN * token=NULL;
CCP4PARSERARRAY * parser;

ccp4ProgramName ( "CIF2XML" );
ccp4_banner();



  if (argc!=3)  {
    PrintInstructions ( argv[0] );
    return 1;
  }

  //  1.  Make routine initializations, which must always be done
  //      before working with MMDB
  mmdb::InitMatType();

  //  2.  Read mmCIF file.
  mmCIF = new mmdb::mmcif::Data();

  //      Set printing errors and warnings off, so that mmCIF would
  //      notify about everything which is not in order
  mmCIF->SetFlag ( mmdb::mmcif::CIFFL_PrintWarnings );
  rc = mmCIF->ReadMMCIFData ( argv[1] );
  if (rc==mmdb::mmcif::CIFRC_CantOpenFile)  {
    printf ( " **** can't open mmCIF file %s\n",argv[1] );
    delete mmCIF;
    return 1;
  }
  if (rc!=mmdb::mmcif::CIFRC_Ok)  {
    printf ( " **** not a clean mmCIF file %s -- stop.\n",argv[1] );
    delete mmCIF;
    return 2;
  }

  printf ( "\n\n -----------------------------------------------------------\n"
           "  Data block named %s is read from mmCIF file %s .\n",
           mmCIF->GetDataName(),argv[1] );

  XML = mmdb::xml::mmCIF2XML ( mmCIF,&rc );
  if (XML)  {
    if (rc>=0)  {
      printf ( " ... conversion to XML done, total %i XML objects.\n",rc );
      rc = XML->WriteObject ( argv[2],0,2 );
      printf ( " ... XML written to file %s, return code %i.\n",argv[2],rc );
    } else
      printf ( " ... conversion to XML done, return code %i.\n",rc );
    delete XML;
  }

  delete mmCIF;

  return 0;

}



