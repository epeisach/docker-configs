//
//     CROSS_VALIDATE
//     Copyright (C) 2003 Pryank Patel
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//

// =================================================================
//
//  MacroMolecular Data Base (MMDB)
//
//  File  cross_validate.cpp
//
//  Example:
//     Cross-validating more than one harvest file
//
//  06 Jan 2003
//
//  Make:  cc -o cross_validate cross_validate.cpp mmdb.a -lm -lC
//
//  P. Patel
//
// =================================================================

#include <math.h>

#include "mmdb2/mmdb_mmcif_.h"
#include "mmdb2/mmdb_xml_.h"
#include "mmdb2/mmdb_cifdefs.h"

#include "ccp4/ccp4_parser.h"
#include "ccp4/ccp4_general.h"
#include "ccp4/ccp4_program.h"

using namespace CCP4;

void  PrintInstructions ( pstr argv0 )  {
  printf ( 
    "\n"
    "Command line syntax:\n"
    "~~~~~~~~~~~~~~~~~~~~\n"
    "cross_validate HARV_FILE  HARV_FILE...\n"
    "\n"
    "up to a maximum of 5 files.\n"
    "\n"
         );
}

mmdb::pstr  getMMCIFString ( mmdb::mmcif::PStruct mmCIFStruct, mmdb::pstr tag )  {
mmdb::pstr d;
int  rc;
  d = NULL;
  printf ( "\n  %s.%s :  ",mmCIFStruct->GetCategoryName(),tag );
  rc = mmCIFStruct->GetString ( d,tag );
  switch (rc)  {
    case mmdb::mmcif::CIFRC_NoField : printf ( " << no data provided >>\n"  );  break;
    case mmdb::mmcif::CIFRC_NoTag   : printf ( " << no such tag found >>\n" );  break;
    default            : if (!d)  printf ( " << no data >>\n"  );
                            else  printf ( " %s\n",d );
  }
  return d;
}

/* buggy and unused
pstr getInfo ( pstr file, pstr structure, pstr tag ) {
    pstr info;
    PCMMCIFData mmCIF;
    PCMMCIFStruct mmCIFStruct;
    mmCIF->ReadMMCIFData(file);
    mmCIFStruct = mmCIF->GetStructure(structure);
    info = getMMCIFString(mmCIFStruct,tag);
    return info;
}
*/

void compareInfo ( mmdb::pstr category, mmdb::pstr parameter[], int i, int j, int file_no ) {

    if(strcmp(parameter[i],parameter[j])!=0) {
	printf("\n%s between files %i and %i do not match",category,i+1,j+1);
	printf("\n%s of file %i : %s",category,i+1,parameter[i]);
	printf("\n%s of file %i : %s",category,j+1,parameter[j]);
    } else {
	printf("\n%s matches",category);
    }
	    
}

char * copy ( mmdb::pstr string1 ) {
    mmdb::pstr string2;
    char *ptr, *ptr2;
    int len;
    len = strlen(string1) + 1;
    string2 = (char * ) malloc(len);
    if (!string2)
    {
	printf("\ncant do it\n");
	return NULL;
    }
    memset(string2,'\0',len);
    ptr = string1;
    ptr2 = string2;
    while (*ptr != '\0')
    {
	if (32 != (int)*ptr)
	{
            *ptr2 = *ptr;
            ++ptr2;
        }
	++ptr; 
    }
    return string2;
    printf("\n%s\n\n",string2);
}


int main ( int argc, char ** argv, char ** env )  {

    mmdb::mmcif::PData mmCIF;
    mmdb::mmcif::PStruct mmCIFStruct;
    mmdb::mmcif::PCategory mmCIFCat;
    int file_no,a,b,c,d[5],e,f[5][10],g,h,i,j,o[5],p,RC;
    mmdb::pstr file[5],category[13][5];
    mmdb::pstr entryData[5];
    mmdb::pstr diffrnData[5];
    mmdb::pstr cell_a[5],cell_b[5],cell_c[5],cell_alpha[5],cell_beta[5],cell_gamma[5];
    mmdb::cpstr core_cats[10] = { "_audit", "_cell", "_diffrn", "_diffrn_reflns", "_entry", "_refln", "_reflns", "_software", "_Symmetry", "_Symmetry_equiv" };
    mmdb::pstr date[5];
    mmdb::pstr spaceGroup[5],intTablesNumber[5];
    mmdb::pstr reflnData[5];
    mmdb::pstr *ptr_spaceGroup;
    char line[201],*key;
    int ntok=0;
    int cross_value=0;

	
    CCP4PARSERTOKEN * token=NULL;
    CCP4PARSERARRAY * parser;

//General CCP4 initializations

    ccp4ProgramName    ( "CROSS_VALIDATE" );
    ccp4_banner();

    if (argc<2) {
	PrintInstructions (argv[0]);
	return 1;
    }

    file_no = argc-1;

    parser = (CCP4PARSERARRAY *) ccp4_parse_start(20);

    if (parser == NULL) ccperror ( 1,"Couldn't create parser array" );

    key    = parser->keyword;
    token  = parser->token;

    RC  = 0;

    while (!RC) {
      
      line[0] = '\0';
      
      ntok = ccp4_parser(line,200,parser,1);

      if (ntok < 1) {

	RC = 111;
	printf("file_no = %i\n",file_no);
      } else {

	if (ccp4_keymatch("CROSS",key)) {
	  printf("CROSS KEY FOUND - will cross validate specified files\n");
	  cross_value = 1;
	} else if (ccp4_keymatch("END",key)) {
	  RC = 111;
	} else {
	  printf("UNRECOGNISED KEYWORD\n");
	}
      }
    }
    
    mmdb::InitMatType();

    for (a=0; a<file_no; a++) {
	b = a+1;
        mmCIF = new mmdb::mmcif::Data();
        mmCIF->SetFlag ( mmdb::mmcif::CIFFL_PrintWarnings );
	c = mmCIF->ReadMMCIFData(argv[b]);
        if (c==mmdb::mmcif::CIFRC_CantOpenFile) {
	    printf("****Cannot Open mmCIF File %s****\n",argv[b]);
	    return 5;
	}
        if (c!=mmdb::mmcif::CIFRC_Ok) {
	    printf("****The file %s is not a clean mmCIF File -- Stop****\n",argv[b]);
	    return 6;
	}
	else {
	    printf("\nFile %s is ok\n",argv[b]);
	}

	file[a] = argv[b];
	
	d[a] = mmCIF->GetNumberOfCategories();

	for(e=0;e<d[a];e++) {
	    mmCIFCat = mmCIF->GetCategory(e);
	    if(mmCIFCat) {
		category[e][a] = mmCIFCat->GetCategoryName();
		printf("\nCategory:  %s",category[e][a]);
	    }
	}
	printf("\n\n       --------------------         \n");
	for (g=0;g<10;g++) {
	    f[a][g] = mmCIF->CheckData(core_cats[g],NULL);
	}
    }

    p=0;
    for(h=0;h<file_no;h++) {
	printf("\nFile: %s",file[h]);
	    if(f[h][0]==1) {
  		mmCIF->ReadMMCIFData(file[h]);
  		mmCIFStruct = mmCIF->GetStructure(core_cats[0]);
  		date[h] = getMMCIFString(mmCIFStruct,"creation_date");
  	    }
	    if(f[h][1]==1) {
		mmCIF->ReadMMCIFData(file[h]);
		mmCIFStruct = mmCIF->GetStructure(core_cats[1]);
		cell_a[h] = getMMCIFString(mmCIFStruct,"length_a");
		cell_b[h] = getMMCIFString(mmCIFStruct,"length_b");
		cell_c[h] = getMMCIFString(mmCIFStruct,"length_c");
		cell_alpha[h] = getMMCIFString(mmCIFStruct,"angle_alpha");
		cell_beta[h] = getMMCIFString(mmCIFStruct,"angle_beta");
		cell_gamma[h] = getMMCIFString(mmCIFStruct,"angle_gamma");
	    }

	    if(f[h][2]==1) {
		mmCIF->ReadMMCIFData(file[h]);
/*	nResNames */	mmCIFStruct = mmCIF->GetStructure(core_cats[2]);
		diffrnData[h] = getMMCIFString(mmCIFStruct,"id");
	    }
	    
	    //put diffrn_reflns here

	    //put entry here
	    if(f[h][4]==1) {
		mmCIF->ReadMMCIFData(file[h]);
		mmCIFStruct = mmCIF->GetStructure(core_cats[4]);
		entryData[h] = getMMCIFString(mmCIFStruct,"id");
	    }

	    //put refln here
	    if(f[h][5]==1) {
		mmCIF->ReadMMCIFData(file[h]);
		mmCIFStruct = mmCIF->GetStructure(core_cats[5]);
		reflnData[h] = getMMCIFString(mmCIFStruct,"");
	    }

	    //put reflns here


	    //put software here

	    //put symmetry here

	    if(f[h][8]==1) {
		mmCIF->ReadMMCIFData(file[h]);
		mmCIFStruct = mmCIF->GetStructure(core_cats[8]);
		spaceGroup[h] = getMMCIFString(mmCIFStruct,"space_group_name_H-M");
		spaceGroup[h] = copy(spaceGroup[h]);
		intTablesNumber[h] = getMMCIFString(mmCIFStruct,"Int_tables_number");
	    } else if (f[h][8]==-3) {
		spaceGroup[h] = "?";
		intTablesNumber[h] = "?";
	    }


	    if(f[h][9]==2) {
		//printf("\n\nequiv present %i\n\n",h);
		o[p] = h;
		++p;
	    }
    }

    //    if(file_no==argc-2) {
    if (cross_value==1) {

      for (i=0;i<1;i++) {
	for(j=1;j<file_no;j++) {
	    compareInfo("date",date,i,j,file_no);
	    compareInfo("cell length a",cell_a,i,j,file_no);
	    compareInfo("cell length b",cell_b,i,j,file_no);
	    compareInfo("cell length c",cell_c,i,j,file_no);
	    compareInfo("cell alpha angle",cell_alpha,i,j,file_no);
	    compareInfo("cell beta angle",cell_beta,i,j,file_no);
	    compareInfo("cell gamma angle",cell_gamma,i,j,file_no);
	    compareInfo("diffrn.id",diffrnData,i,j,file_no);
	    
	    //put diffrn_reflns here
	    
	    //put entry here
	    compareInfo("id",entryData,i,j,file_no);
	    
	    //put refln here
	    
	    //put reflns here
	    
	    //put software here
	    
	    //put symmetry here
	    compareInfo("Space Groups",spaceGroup,i,j,file_no);
	    compareInfo("Int tables number",intTablesNumber,i,j,file_no);
	    
	}
      }
    }

    printf("\n\n");
}





