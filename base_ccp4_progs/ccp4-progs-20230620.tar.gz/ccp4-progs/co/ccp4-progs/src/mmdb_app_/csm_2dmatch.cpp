//
//  =================================================================
//
//    05.03.10   <--  Date of Last Modification.
//                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  -----------------------------------------------------------------
//
//  **** Module  :  csm_2dmatch  <implementation>
//       ~~~~~~~~~
//  **** Project :  Chemical Structure Matching (CSM)
//       ~~~~~~~~~
//  **** Classes :  CSM2DMatch  - 2D graph matching
//       ~~~~~~~~~
//
//  (C) E. Krissinel 2010
//
//  =================================================================
//


#include "csm_2dmatch.h"

CSM2DMatch::CSM2DMatch()  {
  Init();
}

CSM2DMatch::~CSM2DMatch()  {
  FreeMemory();
}

void CSM2DMatch::Init()  {
  GM = NULL;
}

void CSM2DMatch::FreeMemory()  {
  if (GM)  {
    delete GM;
    GM = NULL;
  }
}

void CSM2DMatch::matchStructures ( PCSMStructure CS1,
                                   PCSMStructure CS2,
                                   int maxNofUmatchedAtoms )  {
mmdb::math::PGraph G1,G2;
int                minMatch;

  G1 = CS1->get2DGraph();
  G2 = CS2->get2DGraph();

  if ((!G1) || (!G2))  {
    FreeMemory();
    return;
  }

  minMatch = mmdb::IMax ( 1,
                mmdb::IMin(G1->GetNofVertices(),G2->GetNofVertices()) -
                maxNofUmatchedAtoms );

  if (!GM)  GM = new mmdb::math::GraphMatch();

  GM->MatchGraphs ( G1,G2,minMatch,true,mmdb::math::EXTTYPE_Ignore );

}

int  CSM2DMatch::getNofMatches()  {
  if (GM)  return GM->GetNofMatches();
  return -1;
}

void CSM2DMatch::printMatch ( int matchNo, PCSMStructure CS1,
                                           PCSMStructure CS2 )  {
mmdb::math::PGraph G1,G2;
mmdb::ivector      F1,F2;
mmdb::realtype     p1,p2;
int                nVertices,i;

  if (!GM)  {
    printf ( "\n **** 2D graph matching was not performed\n" );
    return;
  }

  if (matchNo>=GM->GetNofMatches())  {
    printf ( "\n ++++ wrong match number (%i, maximum %i)\n",
             matchNo,GM->GetNofMatches() );
    return;
  }

  G1 = CS1->get2DGraph();
  G2 = CS2->get2DGraph();

  GM->GetMatch ( matchNo, F1,F2, nVertices, p1,p2 );

  printf ( "\n ======= Match #%i\n",matchNo+1 );
  for (i=1;i<=nVertices;i++)  {
    printf ( " %3i: %s  <=>  %3i: %s\n",
             F1[i],G1->GetVertex(F1[i])->GetName(),
             F2[i],G2->GetVertex(F2[i])->GetName() );
  }

}

