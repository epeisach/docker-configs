//
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//
// =========================================================================
//
//
//  21.09.2001 - 12.05.2017
//
//
// =========================================================================
//

#include <stdlib.h>
#include <iostream>
#include <string>
#include <math.h>
#include "ccp4/ccp4_general.h"
#include "ccp4/ccp4_parser.h"

using namespace CCP4;

#ifndef  __PCUR_Funcs__
#include "pcur_funcs.h"
#endif


// ------------------- input drivers  -------------------------

void summarise ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("SUMMARISE",token[0].word))  {
    RC = summariseModel ( MMDB );
  }
}

void delsolvent ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELSOLVENT",token[0].word))  {
    printf ( "\n   Deleting solvent molecules from model. \n" );
    RC = MMDB.DeleteSolvent();
    if (RC) {
      printf ( "   %d solvent molecules deleted from model. \n\n", RC );
      RC = 0;
    } else {
      printf ( "   No solvent molecules found in model. \n\n" );
    }
  }
}

void delhydrogen ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELHYDROGEN",token[0].word))  {
    printf ( "\n   Deleting hydrogen atoms from model. \n" );
    RC = deleteAtom ( MMDB,mmdb::pstr("[H]:*") );
    if (RC) {
      printf ( "   No hydrogen atoms in model! \n\n" );
      RC = 0;
    }
  }
}

void mostprob ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("MOSTPROB",token[0].word))  {
    std::string chain_to_keep("A");
    if (ntok>1) chain_to_keep = token[1].fullstring ;
    RC = selectMostProbable ( MMDB, chain_to_keep );
    if (!RC) {
      printf ( "   Model has been modified. \n" );
      printf ( "   Only most probable conformations kept, as judged by occupancy.\n" );
      std::cout << "   Where occupancies equal, conformer " << chain_to_keep << " kept. \n\n";
    } else {
      printf ( "   No alternate conformations found. \n" );
      RC = 0;
    }
  }
}

void cutoffocc ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
mmdb::realtype cutoff = 0.0;

  if (ccp4_keymatch("CUTOCC",token[0].word))  {
    if (token[1].isnumber) cutoff = token[1].value;
    RC = setOccupancyCutoff ( MMDB, cutoff );
    if (!RC) {
      printf ( "   Model has been modified. \n" );
      printf ( "   Atoms with occupancy less than or equal to %5.2f have been removed. \n\n", cutoff);
    } else {
      printf ( "   No appropriate atoms found. \n" );
      RC = 0;
    }
  }
}

void delanisou ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {

  if (ccp4_keymatch("NOANISOU",token[0].word))  {
    RC = removeAnisou ( MMDB );
    if (!RC) {
      printf ( "   Model has been modified. \n" );
      printf ( "   Anisotrommdb::Pic U lines have been removed \n\n" );
    } else {
      printf ( "   No appropriate atoms found. \n" );
      RC = 0;
    }
  }
}

void renchain ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RENCHAIN",token[0].word))  {
    if (ntok<3) {
      ccperror ( 1,"RENCHAIN: selection statement(s) not found" );
      RC = Err_RENCHAIN;
    } else
      RC = renameChain ( MMDB,token[1].fullstring,token[2].fullstring );
  }
}

void renresidue ( CCP4PARSERTOKEN * token, int ntok,
                  mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RENRESIDUE",token[0].word))  {
    if (ntok<3) {
      ccperror ( 1,"RENRESIDUE: selection statement(s) not found" );
      RC = Err_RENRESIDUE;
    } else
      RC = renameResidue ( MMDB,token[1].fullstring,token[2].fullstring );
  }
}

void renatom ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RENATOM",token[0].word))  {
    if (ntok<3) {
      ccperror ( 1,"RENATOM: selection statement(s) not found" );
      RC = Err_RENATOM;
    } else
      RC = renameAtom ( MMDB,token[1].fullstring,token[2].fullstring );
  }
}

void renelement ( CCP4PARSERTOKEN * token, int ntok,
                  mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RENELEMENT",token[0].word))  {
    if (ntok<3) {
      ccperror ( 1,"RENELEMENT: selection statement(s) not found" );
      RC = Err_RENELEMENT;
    } else
      RC = renameElement ( MMDB,token[1].fullstring,token[2].fullstring );
  }
}

void delmodel ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELMODEL",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"DELMODEL: selection statement(s) not found" );
      RC = Err_DELMODEL;
    } else
      RC = deleteModel ( MMDB,token[1].fullstring );
  }
}

void delchain ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELCHAIN",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"DELCHAIN: selection statement(s) not found" );
      RC = Err_DELCHAIN;
    } else
      RC = deleteChain ( MMDB,token[1].fullstring );
  }
}

void delresidue ( CCP4PARSERTOKEN * token, int ntok,
                  mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELRESIDUE",token[0].word))  {
    if (ntok<2)  {
      ccperror ( 1,"DELRESIDUE: selection statement(s) not found" );
      RC = Err_DELRESIDUE;
    } else
      RC = deleteResidue ( MMDB,token[1].fullstring );
  }
}

void delatom ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELATOM",token[0].word))  {
    if (ntok<2)  {
      ccperror ( 1,"DELATOM: selection statement(s) not found" );
      RC = Err_DELATOM;
    } else
      RC = deleteAtom ( MMDB,token[1].fullstring );
  }
}

void remchain ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RMCHAIN",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"RMCHAIN: selection statement(s) not found" );
      RC = Err_DELCHAIN;
    } else
      RC = removeChain ( MMDB,token[1].fullstring );
  }
}

void remresidue ( CCP4PARSERTOKEN * token, int ntok,
                  mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RMRESIDUE",token[0].word))  {
    if (ntok<2)  {
      ccperror ( 1,"RMRESIDUE: selection statement(s) not found" );
      RC = Err_DELRESIDUE;
    } else
      RC = removeResidue ( MMDB,token[1].fullstring );
  }
}

void rematom ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("RMATOM",token[0].word))  {
    if (ntok<2)  {
      ccperror ( 1,"RMATOM: selection statement(s) not found" );
      RC = Err_DELATOM;
    } else
      RC = removeAtom ( MMDB,token[1].fullstring );
  }
}

void deldist ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("DELDIST",token[0].word))  {
    if (ntok<5)  {
      ccperror ( 1,"DELDIST: not enough parameters, see documentation" );
      RC = Err_DELDIST;
    } else
      RC = deleteDist ( MMDB,token[1].value,token[2].value,
                             token[3].value,token[4].value );
  }
}

void lvmodel ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("LVMODEL",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"LVMODEL: selection statement(s) not found" );
      RC = Err_LVMODEL;
    } else
      RC = leaveModel ( MMDB,token[1].fullstring );
  }
}

void lvchain ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("LVCHAIN",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"LVCHAIN: selection statement(s) not found" );
      RC = Err_LVCHAIN;
    } else
      RC = leaveChain ( MMDB,token[1].fullstring );
  }
}

void lvresidue ( CCP4PARSERTOKEN * token, int ntok,
                 mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("LVRESIDUE",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"LVRESIDUE: selection statement(s) not found" );
      RC = Err_LVRESIDUE;
    } else
      RC = leaveResidue ( MMDB,token[1].fullstring );
  }
}

void lvatom ( CCP4PARSERTOKEN * token, int ntok,
              mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("LVATOM",token[0].word))  {
    if (ntok<2) {
      ccperror ( 1,"LVATOM: selection statement(s) not found" );
      RC = Err_LVATOM;
    } else
      RC = leaveAtom ( MMDB,token[1].fullstring );
  }
}

void lvdist ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("LVDIST",token[0].word))  {
    if (ntok<5)  {
      ccperror ( 1,"LVDIST: not enough parameters, see documentation" );
      RC = Err_LVDIST;
    } else
      RC = leaveDist ( MMDB,token[1].value,token[2].value,
                             token[3].value,token[4].value );
  }
}

void genter ( CCP4PARSERTOKEN * token, int ntok,
              mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("GENTER",token[0].word))  {
    RC = MMDB.PDBCleanup ( mmdb::PDBCLEAN_TER );
    if (!RC)
         printf ( "   PDB 'TER' cards have been generated\n" );
    else printf ( " ***** UNKNOWN 'genter' CARD ERROR; REPORT AS A BUG\n" );
  }
}

void delter ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  mmdb::PPAtom  A;
  int           nAtoms,i,n;
  if (ccp4_keymatch("DELTER",token[0].word))  {
    MMDB.GetAtomTable ( A,nAtoms );
    n = 0;
    for (i=0;i<nAtoms;i++)
      if (A[i])  {
        if (A[i]->isTer())  {
          delete A[i];
          A[i] = NULL;
          n++;
        }
      }
    RC = MMDB.FinishStructEdit();
    if (!RC)
         printf ( "   %i PDB 'TER' cards have been removed\n",n );
    else printf ( " ***** UNKNOWN 'delter' CARD ERROR; REPORT AS A BUG\n" );
  }
}

void sernum ( CCP4PARSERTOKEN * token, int ntok,
              mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("SERNUM",token[0].word))  {
    RC = MMDB.PDBCleanup ( mmdb::PDBCLEAN_SERIAL );
    if (!RC)
         printf ( "   Atom serial numbers have been generated\n" );
    else printf ( " ***** UNKNOWN SERIAL NUMBER ERROR;"
                      " REPORT AS A BUG\n" );
  }
}

void mvsolvent ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("MVSOLVENT",token[0].word))  {
    RC = MMDB.PDBCleanup ( mmdb::PDBCLEAN_SOLVENT );
    if (!RC)  printf ( "   Solvent chain(s) moved to the "
                       "end of model(s).\n" );
        else  printf ( " ***** UNKNOWN ERROR; REPORT AS A BUG\n" );
  }
}

void write ( CCP4PARSERTOKEN * token, int ntok,
             int & FType,  int & RC )  {
  if (ccp4_keymatch("WRITE",token[0].word))  {
    RC = 0;
    if (ntok<2) {
      ccperror ( 1,"WRITE: Output file type is not found" );
      RC = Err_WRITE;
    } else if (!strcasecmp(token[1].fullstring,"PDB"))  {
      FType = mmdb::MMDB_FILE_PDB;
      printf ( "   PDB output file type has been set.\n" );
    } else if (!strcasecmp(token[1].fullstring,"CIF"))  {
      FType = mmdb::MMDB_FILE_CIF;
      printf ( "   mmCIF output file type has been set.\n" );
    } else if (!strcasecmp(token[1].fullstring,"BIN"))  {
      FType = mmdb::MMDB_FILE_Binary;
      printf ( "   MMDB binary output file type has been set.\n" );
    } else  {
      RC = Err_WRITE_TYPE;
      ccperror ( 1,"Unknown file type" );
    }
  }
}

void symmetry ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  mmdb::pstr line, int & RC )  {
int  n;
char symGroup[500];
  if (ccp4_keymatch("SYMMETRY",token[0].word)) {
    RC = 0;
    if (ntok<2) {
      ccperror ( 1,"SYMMETRY requires argument, e.g. P 21 21 21" );
      RC = Err_SYMMETRY;
    } else {
      n = token[ntok-1].iend - token[1].ibeg + 1;
      mmdb::strcpy_ncss ( symGroup,&line[token[1].ibeg],n );
      symGroup[n] = char(0);
      // previously symGroup was converted to uppercase, but this
      // causes problems with mirror planes
      n = MMDB.SetSpaceGroup ( symGroup );
      switch (n)  {
        case mmdb::SYMOP_NoLibFile         :
                ccperror ( 1,"symop.lib file not found" );
                RC = Err_SYMMETRY_NOLIB;
              break;
        case mmdb::SYMOP_UnknownSpaceGroup :
                ccperror ( 1,"Unknown space symmetry group" );
                RC = Err_SYMMETRY_SPGRP;
              break;
        case mmdb::SYMOP_NoSymOps          :
                ccperror ( 1,"no symmetry operations found found" );
                RC = Err_SYMMETRY_NOSYMOP;
              break;
        default : ;
      }
    }
  }
}

void geometry ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  int & RC )  {
int i;
  if (ccp4_keymatch("GEOMETRY",token[0].word)) {
    RC = 0;
    if (ntok!= 7)  {
      ccperror ( 1,"GEOMETRY requires 6 parameters:"
                   " a b c alpha beta gamma" );
      RC = Err_GEOMETRY;
    } else  {
      i = 1;
      while ((i<ntok) && token[i].isnumber && (token[i].value>0.0)) i++;
      if (i<ntok) {
        printf ( "%ith GEOMETRY parameter is not numerical "
                 "or positive",i );
        RC = Err_GEOMETRY_FORMAT;
      } else
        MMDB.SetCell ( token[1].value,token[2].value,token[3].value,
                       token[4].value,token[5].value,token[6].value,0 );
    }
  }
}

void genunit ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("GENUNIT",token[0].word))  {
    RC = MMDB.GenerateSymMates();
    if (RC==1)  {
      ccperror ( 1,"No symmetry operations defined" );
      RC = Err_GENUNIT_NOSYMOP;
    } else if (RC==2)  {
      ccperror ( 1,"Fractionalization/Orthogonalization is not defined" );
      RC = Err_GENUNIT_TRANSFORM;
    } else if (RC==3)  {
      ccperror ( 1,"No cell parameters were set up" );
      RC = Err_GENUNIT_CELL;
    }
  }
}

void symop ( CCP4PARSERTOKEN * token, int ntok,
             mmdb::RGenSym   GenSym,   int & RC )  {
int  Nop,i;
char S[500];
  if (ccp4_keymatch("SYMOP",token[0].word))  {
    RC = 0;
    if (ntok<4)  {
      ccperror ( 1,"SYMOP requires argument -"
                   " the symmetry operation X,Y,Z" );
      RC = Err_SYMOP;
    } else {
      sprintf ( S,"%s,%s,%s",token[1].fullstring,
                             token[2].fullstring,
                             token[3].fullstring );
      GenSym.AddSymOp ( S );
      Nop = GenSym.GetNofSymOps()-1;
      for (i=5;i<ntok;i+=2)
        GenSym.AddRenChain ( Nop,token[i-1].fullstring,
                                 token[i].fullstring );
    }
  }
}

void symcommit ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB,  mmdb::RGenSym GenSym, int & RC )  {
  if (ccp4_keymatch("SYMCOMMIT",token[0].word))  {
    RC = MMDB.GenerateSymMates ( &GenSym );
    switch (RC)  {
      case 0 : printf ( " symmetry operations applied\n" );
             break;
      case 1 : ccperror ( 1,"SYMCOMMIT: No symmetry operations have been "
                            "declared with SYMOP" );
               RC = Err_SYMCOMMIT_NOSYMOP;
             break;
      case 2 : ccperror ( 1,"SYMCOMMIT: Fractionalization/Orthogonalization "
                            "is not defined" );
               RC = Err_SYMCOMMIT_TRANSFORM;
             break;
      case 3 : ccperror ( 1,"SYMCOMMIT: No cell parameters were set up" );
               RC = Err_SYMCOMMIT_CELL;
             break;
      default : ccperror ( 1,"SYMCOMMIT: unknown return\n" );
                RC = Err_SYMCOMMIT_UNKNOWN;
    }
    GenSym.FreeMemory();
  }
}

void mkchainids ( CCP4PARSERTOKEN * token, int ntok,
                  mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("MKCHAINIDS",token[0].word))  {
    RC = MMDB.PDBCleanup ( mmdb::PDBCLEAN_CHAIN );
    if (RC)  {
      ccperror ( 1,"MKCHAINIDS: too many chain generated" );
      RC = Err_MKCHAINIDS;
    }
  }
}


void _splittochains ( mmdb::RManager MMDB, mmdb::cpstr fpath,
                      bool jsonOnly, int & RC )  {
// Special function for jsCoFE. 1st model is split in chains, each one is
// output in separate file named fname_A.pdb (where fname is the original
// file name), and chain annotation is output in fname.json:
//  {
//    cryst: {
//        spaceGroup: 'P 31 2 1',
//        a     : 64.720,
//        b     : 64.720,
//        c     : 69.570,
//        alpha : 90.00,
//        beta  : 90.00,
//        gamma : 120.00
//      },
//    xyz: [
//      { 'model':1,
//        'chains': [
//          { 'id'  : 'A', 'file': 'fname_A.pdb', 'type': 'AA',
//            'seq' : 'ASDFJHGKJHLKJHJHYFTFYRDS',
//            'size': 100, 'ligands': ['DG1','DG2'] }, // aminoacids
//          { 'id': 'B', 'file': 'fname_B.pdb', 'type': 'DNA',
//            'seq' : 'ASDFJHGKJHLKJ',
//            'size': 50,  'ligands': ['LLL'] },       // DNA
//          { 'id': 'C', 'file': 'fname_C.pdb', 'type': 'RNA',
//            'seq' : 'ASDFJHGKJHLKJ',
//            'size': 50,  'ligands': ['PNY'] }        // RNA
//                  ]
//      }
//    ],
//    ligands: ['HET','HEM','ATP']
//  }
//

  mmdb::PModel    model;
  mmdb::PPChain   chains  = NULL;
  mmdb::PPResidue res;
  mmdb::pstr      fbase   = NULL;
  mmdb::pstr      fchain  = NULL;
  mmdb::pstr      json    = NULL;
  mmdb::pstr      p,rn;
  mmdb::pstr      ligands = NULL;
  mmdb::pstr      ligs    = NULL;
  mmdb::pstr      seq     = NULL;
  mmdb::realtype  cell_a,cell_b,cell_c;
  mmdb::realtype  cell_alpha,cell_beta,cell_gamma,vol;
  char            chType[100];
  char            L[1000];
  char            code1[10];
  int             OrthCode;
  int             nm, nLigs,nLigsAlloc,nRes;
  int             fileType = MMDB.GetFileType();
  int             nChains  = 0;
  int             nModels  = MMDB.GetNumberOfModels();
  bool            newModel;

  RC = 0;

  MMDB.DeleteSolvent();

  mmdb::CreateCopy ( fbase,fpath );
  p = mmdb::LastOccurence ( fbase,'.' );
  if (p)  *p = char(0);
  
  mmdb::CreateCopy ( ligands,"" );

  for (nm=1;nm<=nModels;nm++)  {
    
    model = MMDB.GetModel ( nm );
    if (model)  {
   
      model->DeleteSolventChains();
      model->GetChainTable ( chains,nChains );
      mmdb::CreateCopy ( fchain,fpath );
      newModel = true;

      for (int i=0;i<nChains;i++)
        if (chains[i]->GetNumberOfResidues()>0)  {
          
          if (!jsonOnly)  {
            mmdb::PManager M   = new mmdb::Manager();
            mmdb::PModel   mdl = new mmdb::Model();
            M->Copy ( &MMDB,mmdb::MMDBFCM_Cryst );
            mdl->AddChain ( chains[i] );
            M->AddModel ( mdl );
            mdl->GetChain(0)->SetChainID ( chains[i]->GetChainID() );
            sprintf ( L,"_%i_%s",nm,chains[i]->GetChainID() );
            if (fileType==mmdb::MMDB_FILE_PDB)  {
              mmdb::CreateCopCat ( fchain,fbase,L,".pdb" );
              M->WritePDBASCII ( fchain );
              printf ( " ... written PDB file %s\n",fchain );
            } else if (fileType==mmdb::MMDB_FILE_CIF)  {
              mmdb::CreateCopCat ( fchain,fbase,L,".cif" );
              M->WritePDBASCII ( fchain );
              printf ( " ... written MMCIF file %s\n",fchain );
            } else
              printf ( " +++ unknown file type %i\n",fileType );
            delete M;
          }
          
          if (newModel)  {
            if (!json)
              sprintf ( L,"[\n  { 'model':%i,\n    'chains': [\n",nm );
            else
              sprintf ( L,"\n              ]\n  },\n"
                          "  { 'model':%i,\n    'chains': [\n",nm );
            mmdb::CreateConcat ( json,L );
            newModel = false;
          } else
            mmdb::CreateConcat ( json,",\n" );
          
          if (chains[i]->isAminoacidChain())  strcpy ( chType,"AA" );
          else if (chains[i]->isNucleotideChain())  {
            if (chains[i]->GetResidue(0)->isDNARNA()==1)
                  strcpy ( chType,"DNA" );
            else  strcpy ( chType,"RNA" );
          } else
            strcpy ( chType,"UNK" );

          mmdb::CreateCopy ( ligs,"" ); 
          chains[i]->GetResidueTable ( res,nRes );
          for (int j=0;j<nRes;j++)  {
            rn = res[j]->GetResName();
            mmdb::Get1LetterCode ( rn,code1 );
            if (code1[0]=='X')  {
              if (!res[j]->isSolvent())  {
                if (!ligands[0])
                  mmdb::CreateCopCat ( ligands,"'",rn,"'" );
                else if (!strstr(ligands,rn))
                  mmdb::CreateConcat ( ligands,",'",rn,"'" );
                if (!ligs[0])
                  mmdb::CreateCopCat ( ligs,"'",rn,"'" );
                else if (!strstr(ligs,rn))
                  mmdb::CreateConcat ( ligs,",'",rn,"'" );
              }
            }
          }

          chains[i]->GetCoordSequence ( seq );
          sprintf ( L,"      { 'id':'%s', 'file':'%s', 'type':'%s',\n"
                      "        'seq':'%s',\n"
                      "        'size':%i, 'ligands':[%s] }",
                      chains[i]->GetChainID(),
                      mmdb::io::GetFName(fchain,mmdb::io::syskey_all),
                      chType,seq,chains[i]->GetNumberOfResidues(),ligs
                  );
          mmdb::CreateConcat ( json,L );
          
        }
        
    }
    
  }
  
  if (json)  {
  
    if (MMDB.isSpaceGroup())
          strcpy ( chType,MMDB.GetSpaceGroup() );
    else  chType[0] = char(0);

    MMDB.GetCell ( cell_a,cell_b,cell_c,
                   cell_alpha,cell_beta,cell_gamma,
                   vol,OrthCode );

    sprintf ( L,
      "{\n"
      "  'cryst' : {\n"
      "      'spaceGroup': '%s',\n"
      "      'a'     : %.3f,\n"
      "      'b'     : %.3f,\n"
      "      'c'     : %.3f,\n"
      "      'alpha' : %.2f,\n"
      "      'beta'  : %.2f,\n"
      "      'gamma' : %.2f\n"
      "    },\n"
      "  'xyz' : ",
      chType,cell_a,cell_b,cell_c,cell_alpha,cell_beta,cell_gamma
    );
  
    mmdb::CreateConcat ( json,"\n              ]\n  }\n],\n  'ligands': [",
                              ligands,"]\n" );
 
    mmdb::CreateCopCat ( fchain,fbase,".json" );

    mmdb::io::File f;
    f.assign ( fchain,true,false );
    f.rewrite();
    f.Write  ( L     );
    f.Write  ( json  );
    f.Write  ( "}\n" );
    f.shut();

  } else
    RC = Err_SPLITTOCHAINS;

  if (fbase)   delete[] fbase;
  if (fchain)  delete[] fchain;
  if (ligands) delete[] ligands;
  if (ligs)    delete[] ligs;
  if (seq)     delete[] seq;

}


void splittochains ( CCP4PARSERTOKEN * token, int ntok,
                     mmdb::RManager MMDB, mmdb::cpstr fpath, int & RC )  {
// Special function for jsCoFE. 1st model is split in chains, each one is
// output in separate file named fname_A.pdb (where fname is the original
// file name), and chain annotation is output in fname.json:
//  {
//    cryst: {
//        spaceGroup: 'P 31 2 1',
//        a     : 64.720,
//        b     : 64.720,
//        c     : 69.570,
//        alpha : 90.00,
//        beta  : 90.00,
//        gamma : 120.00
//      },
//    xyz: [
//      { 'model':1,
//        'chains': [
//          { 'id': 'A', 'file': 'fname_A.pdb', 'type': 'AA',  'size': 100 }, // aminoacids
//          { 'id': 'B', 'file': 'fname_B.pdb', 'type': 'DNA', 'size': 50 },  // DNA
//          { 'id': 'C', 'file': 'fname_C.pdb', 'type': 'RNA', 'size': 50 }   // RNA
//                  ]
//      }
//    ]
//  }

  if (ccp4_keymatch("SPLITTOCHAINS",token[0].word))
    _splittochains ( MMDB,fpath,false,RC );

}


void pdb_meta ( CCP4PARSERTOKEN * token, int ntok,
                mmdb::RManager MMDB, mmdb::cpstr fpath, int & RC )  {
// Same as splittochain(), however, only generates json annotation, without
// actual splitting into files.
//  {
//    cryst: {
//        spaceGroup: 'P 31 2 1',
//        a     : 64.720,
//        b     : 64.720,
//        c     : 69.570,
//        alpha : 90.00,
//        beta  : 90.00,
//        gamma : 120.00
//      },
//    xyz: [
//      { 'model':1,
//        'chains': [
//          { 'id': 'A', 'file': 'fname_A.pdb', 'type': 'AA',  'size': 100 }, // aminoacids
//          { 'id': 'B', 'file': 'fname_B.pdb', 'type': 'DNA', 'size': 50 },  // DNA
//          { 'id': 'C', 'file': 'fname_C.pdb', 'type': 'RNA', 'size': 50 }   // RNA
//                  ]
//      }
//    ]
//  }

  if (ccp4_keymatch("PDB_META",token[0].word))
    _splittochains ( MMDB,fpath,true,RC );

}


void rotate ( CCP4PARSERTOKEN * token, int ntok,
              mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("ROTATE",token[0].word))  {
    if ((ntok!=8) && (ntok!=6))       RC = Err_ROTATE1;
    else if ((!token[2].isnumber) || (!token[3].isnumber) ||
             (!token[4].isnumber))    RC = Err_ROTATE2;
    else if (ntok==6)  {
      if (!ccp4_keymatch("CENTER",token[5].word))
            RC = Err_ROTATE3;
      else  RC = EulerRotation ( MMDB,token[1].fullstring,
                                      token[2].value,token[3].value,
                                      token[4].value );
    } else  {
      if ((!token[5].isnumber) || (!token[6].isnumber) ||
          (!token[7].isnumber))
            RC = Err_ROTATE4;
      else  RC = EulerRotation ( MMDB,token[1].fullstring,
                                      token[2].value,token[3].value,
                                      token[4].value,token[5].value,
                                      token[6].value,token[7].value );
    }
    if ((RC>=Err_ROTATE4) && (RC<=Err_ROTATE1))
      ccperror ( 1,"ROTATE requires 5 or 7 parameters:\n"
                   " a) selection alpha beta gamma CENTER\n"
                   " b) selection alpha beta gamma x y z\n"
                   "where alpha, beta and gamma are angles in degrees" );
  }
}

void translate ( CCP4PARSERTOKEN * token, int ntok,
                 mmdb::RManager MMDB,  int & RC )  {
  if (ccp4_keymatch("TRANSLATE",token[0].word))  {
    RC = 0;
    if (ntok!=6)       RC = Err_TRANSLATE1;
    else if ((!token[3].isnumber) || (!token[4].isnumber) ||
             (!token[5].isnumber))    RC = Err_TRANSLATE2;
    else if (ccp4_keymatch("ORTH",token[2].word))  {
      RC = OrthTranslation (MMDB,token[1].fullstring,token[3].value,
                            token[4].value, token[5].value);
    } else {
      RC = FracTranslation (MMDB,token[1].fullstring,token[3].value,
                            token[4].value, token[5].value);
    }
  }
}

void vrotate ( CCP4PARSERTOKEN * token, int ntok,
               mmdb::RManager MMDB,  int & RC )  {
int i;
  if (ccp4_keymatch("VROTATE",token[0].word))  {
    if ((ntok!=9) && (ntok!=7) && (ntok!=5))  RC = Err_VROTATE1;
    else if (!token[2].isnumber)              RC = Err_VROTATE2;
    else if (ntok==9)  {
      i = 3;
      while ((i<ntok) && token[i].isnumber) i++;
      if (i<ntok)
            RC = Err_VROTATE3;
      else  RC = VectorRotation ( MMDB,token[1].fullstring,
                                       token[2].value,token[3].value,
                                       token[4].value,token[5].value,
                                       token[6].value,token[7].value,
                                       token[8].value );
    } else if (ntok==7)  {
      if ((!token[3].isnumber) || (!token[4].isnumber) ||
          (!token[5].isnumber))
            RC = Err_VROTATE4;
      else if (!ccp4_keymatch("CENTER",token[6].word))
            RC = Err_VROTATE5;
      else  RC = VectorRotation ( MMDB,token[1].fullstring,
                                       token[2].value,token[3].value,
                                       token[4].value,token[5].value );
    } else
      RC = VectorRotation ( MMDB,token[1].fullstring,
                                 token[2].value,token[3].fullstring,
                                 token[4].fullstring );
    if ((RC>=Err_VROTATE5) && (RC<=Err_VROTATE1))
      ccperror ( 1,"VROTATE requires 4, 6 or 8 parameters:\n"
                   " a) selection alpha atom1 atom2\n"
                   " b) selection alpha vx vy vz CENTER\n"
                   " c) selection alpha vx vy vz x y z\n"
                   "where alpha is the rotation angle in degrees" );
  }
}


// -------------------  summariseModel  --------------------------

int  summariseModel ( mmdb::RManager MMDB )  {
  int nmod,nchain;
  int nres,nres_aminoacid,nres_nucleotide,nres_with_altloc;
  int imod,ichain,ires,iires,i;
  int nspans,ispan,spanstart[8],spanend[8];
  int resCount[n_pc_ResNames+1];
  mmdb::PChain chain;
  mmdb::PResidue residue;
  mmdb::ResName resName;

  nmod = MMDB.GetNumberOfModels();
  printf("\n       ==== SUMMARY OF MODEL === \n\n");
  printf(" Number of models = %d \n",nmod);

  for (imod=1;imod<=nmod;imod++) {
    nchain = MMDB.GetNumberOfChains(imod);
    printf("\n   Model %d has %d chains\n\n",imod,nchain);

    for (ichain=0;ichain<nchain;ichain++) {
      chain = MMDB.GetChain(imod,ichain);
      nres = chain->GetNumberOfResidues();

      // initialise residue count
      for (iires=0;iires<=n_pc_ResNames;iires++) resCount[iires] = 0;
      nspans=0;
      ispan=-9999;
      nres_with_altloc=0;
      nres_aminoacid=0;
      nres_nucleotide=0;

      for (ires=0;ires<nres;ires++) {
        residue = chain->GetResidue(ires);

        if (residue->GetNofAltLocations() > 1) nres_with_altloc++;
        if (residue->isAminoacid()) nres_aminoacid++;
        if (residue->isNucleotide()) nres_nucleotide++;

        if (abs(residue->seqNum-ispan) > 1) {
          if (nspans>0 && nspans<9) spanend[nspans-1]=ispan;
          if (nspans<8) spanstart[nspans]=residue->seqNum;
          nspans++;
        }
        ispan=residue->seqNum;

        strcpy(resName,residue->name);
        // residue defaults to other
        ++resCount[n_pc_ResNames];
        for (iires=0;iires<n_pc_ResNames;iires++) {
          if (!strcmp(resName,pc_ResidueName[iires])) {
                ++resCount[iires];
                --resCount[n_pc_ResNames];
                break;
          }
        }
      }
      printf("     Chain \"%s\" has %d residues, of which %d are amino acids and %d are nucleotides \n",chain->GetChainID(),nres,nres_aminoacid,nres_nucleotide);
      if (nspans<9) spanend[nspans-1]=ispan;
      printf("     in %d spans:",nspans);
      for (ispan=0;ispan<nspans && ispan<8;ispan++)
        printf(" %d-%d",spanstart[ispan],spanend[ispan]);
      if (nspans>8) printf(" ...");
      printf("\n");

      printf("     %d residues have alternative conformations\n",nres_with_altloc);

      printf("     Composition: %s %d %s %d %s %d %s %d \n",pc_ResidueName[0],resCount[0],pc_ResidueName[1],resCount[1],pc_ResidueName[2],resCount[2],pc_ResidueName[3],resCount[3]);
      for (i=1;i<=((n_pc_ResNames-4)/4);i++)
        printf("                  %s %d %s %d %s %d %s %d \n",pc_ResidueName[i*4],resCount[i*4],pc_ResidueName[i*4+1],resCount[i*4+1],pc_ResidueName[i*4+2],resCount[i*4+2],pc_ResidueName[i*4+3],resCount[i*4+3]);
      printf("                  ");
      for (i=0;i<(n_pc_ResNames%4);i++)
        printf("%s %d ",pc_ResidueName[(n_pc_ResNames/4)*4+i],resCount[(n_pc_ResNames/4)*4+i]);
      printf("Other %d\n",resCount[n_pc_ResNames]);
    }
  }
  printf("\n");

  return 0;

}

/*
int  summariseModel_json ( mmdb::RManager MMDB )  {
  int nmod,nchain;
  int nres,nres_aminoacid,nres_nucleotide,nres_with_altloc;
  int imod,ichain,ires,iires,i;
  int nspans,ispan,spanstart[8],spanend[8];
  int resCount[n_pc_ResNames+1];
  mmdb::PChain chain;
  mmdb::PResidue residue;
  mmdb::ResName resName;

  nmod = MMDB.GetNumberOfModels();

  printf ( "{\n \"models\": [\n" );

  for (imod=1;imod<=nmod;imod++) {

    nchain = MMDB.GetNumberOfChains(imod);

    if (imod>1)
      printf ( "  },\n" );
    printf ( "    {\n      \"serNo\" : %i\n",imod );
    printf ( "       \"chains\" : [\n" );

    for (ichain=0;ichain<nchain;ichain++) {

      chain = MMDB.GetChain(imod,ichain);
      nres = chain->GetNumberOfResidues();

      if (ichain>0)
        printf ( "      },\n" );
      printf ( "      {\n" );

      // initialise residue count
      for (iires=0;iires<=n_pc_ResNames;iires++)
       resCount[iires] = 0;

      nspans=0;
      ispan=-9999;
      nres_with_altloc=0;
      nres_aminoacid=0;
      nres_nucleotide=0;

      for (ires=0;ires<nres;ires++) {
        residue = chain->GetResidue(ires);

        if (residue->GetNofAltLocations() > 1) nres_with_altloc++;
        if (residue->isAminoacid()) nres_aminoacid++;
        if (residue->isNucleotide()) nres_nucleotide++;

        if (abs(residue->seqNum-ispan) > 1) {
          if (nspans>0 && nspans<9) spanend[nspans-1]=ispan;
          if (nspans<8) spanstart[nspans]=residue->seqNum;
          nspans++;
        }
        ispan=residue->seqNum;

        strcpy(resName,residue->name);
        // residue defaults to other
        ++resCount[n_pc_ResNames];
        for (iires=0;iires<n_pc_ResNames;iires++) {
          if (!strcmp(resName,pc_ResidueName[iires])) {
                ++resCount[iires];
                --resCount[n_pc_ResNames];
                break;
          }
        }
      }

      printf ( "     \"id\"       : \"%s\"\n",chain->GetChainID() );
      printf ( "     \"nres\"     : %i\n",nres );
      printf ( "     \"nres_aa\"  : %i\n",nres_aminoacid  );
      printf ( "     \"nres_na\"  : %i\n",nres_nucleotide );

      if (nspans<9) spanend[nspans-1]=ispan;
      printf ( "     \"n_spans\"  : %i\n",nspans );

//      for (ispan=0;ispan<nspans && ispan<8;ispan++)
 //       printf(" %d-%d",spanstart[ispan],spanend[ispan]);
  //    if (nspans>8) printf(" ...");
//      printf("\n");

      printf ( "     \"nres_altloc\" : %i\n",nres_with_altloc );

//      printf("     Composition: %s %d %s %d %s %d %s %d \n",pc_ResidueName[0],resCount[0],pc_ResidueName[1],resCount[1],pc_ResidueName[2],resCount[2],pc_ResidueName[3],resCount[3]);
//      for (i=1;i<=((n_pc_ResNames-4)/4);i++)
//        printf("                  %s %d %s %d %s %d %s %d \n",pc_ResidueName[i*4],resCount[i*4],pc_ResidueName[i*4+1],resCount[i*4+1],pc_ResidueName[i*4+2],resCount[i*4+2],pc_ResidueName[i*4+3],resCount[i*4+3]);
//      printf("                  ");
//      for (i=0;i<(n_pc_ResNames%4);i++)
//        printf("%s %d ",pc_ResidueName[(n_pc_ResNames/4)*4+i],resCount[(n_pc_ResNames/4)*4+i]);
//      printf("Other %d\n",resCount[n_pc_ResNames]);

    }

    printf ( "        }\n    ]\n" );

  }

  printf ( "    }\n  ]\n}\n" );

  return 0;

}
*/

// ------------------- selectMostProbable   --------------------------

// Notes on implementation
// MMDBManager::DeleteAltLocs() performs a similar function.
// I believe in the case of 0.5:0.5 conformers it simply retains
// the first. This function gives more control. Also, the mmdb
// version doesn't reset the occupancy or altloc ID.
// Conversely, DeleteAltLocs() is much faster, probably because
// it doesn't use selection handles. So this function should
// maybe be re-coded.

int  selectMostProbable ( mmdb::RManager MMDB, std::string chain_to_keep )  {
int   selHnd,selHnd2,selHnd_del,selHnd_keep;
int   nSelAtoms,nSelAtoms2,nSelAtoms_keep;
int   i,j,ikeep;
mmdb::realtype max_occ;
char    atomID[100];
mmdb::PPAtom selAtom,selAtom2,selAtom_keep;
bool foundAltConf = false;

  // handle for delete selection
  selHnd_del = MMDB.NewSelection();
  // handle for modify & keep selection
  selHnd_keep = MMDB.NewSelection();

  // select all atoms for primary loop
  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd,mmdb::STYPE_ATOM,"*",mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );
  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++) {
      selAtom[i]->GetAtomID(atomID);
      j=0;
      while (atomID[j] != ':' && atomID[j] != '\0') j++;
      atomID[j] = ':';
      atomID[j+1] = '*';
      atomID[j+2] = '\0';

      // do second selection based on atomID with any alt loc ID
      selHnd2 = MMDB.NewSelection();
      MMDB.Select      ( selHnd2,mmdb::STYPE_ATOM,atomID,mmdb::SKEY_OR );
      MMDB.GetSelIndex ( selHnd2,selAtom2,nSelAtoms2 );

      // only if have alternate atoms, do check for most probable
      if (nSelAtoms2 > 1) {
        foundAltConf = true;
        ikeep = 0;
        max_occ = selAtom2[0]->occupancy;

        // this loop selects the conformer to keep
        for (j=1;j<nSelAtoms2;j++)
          if ( fabs(selAtom2[j]->occupancy - 0.5) < 0.0001 &&
               selAtom2[j]->altLoc == chain_to_keep ) {
            // if we have dual conformation with occupancies = 0.5
            // then keep that with requested alt ID
            ikeep = j;
            max_occ = selAtom2[ikeep]->occupancy;
          } else if (selAtom2[j]->occupancy > max_occ) {
            // else if unequal occupancies, label highest occupancy
            // with ikeep
            ikeep = j;
            max_occ = selAtom2[ikeep]->occupancy;
          }

    // add rejected atoms to selHnd_del
        for (j=0;j<nSelAtoms2;j++) {
          if (j != ikeep)
            MMDB.SelectAtom( selHnd_del,selAtom2[j],mmdb::SKEY_OR );
    }
      }
      // delete selection handle
      MMDB.DeleteSelection ( selHnd2 );
    }
  }

  // we seem to need to delete selHnd before we delete atoms from model
  MMDB.DeleteSelection ( selHnd );
  // delete the selected atoms from the model
  MMDB.DeleteSelObjects( selHnd_del );

  // For those that have been kept, set occ=1.0 and remove alt loc
  // This is done for all atoms. It could be done for just checked
  // atoms by constructing selHnd_keep as for selHnd_del above.
  MMDB.Select      ( selHnd_keep,mmdb::STYPE_ATOM,"*",mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd_keep,selAtom_keep,nSelAtoms_keep );
  if (nSelAtoms_keep>0)
    for (i=0;i<nSelAtoms_keep;i++) {
      selAtom_keep[i]->occupancy = 1.0;
      strcpy(selAtom_keep[i]->altLoc,"");
    }

  MMDB.DeleteSelection ( selHnd_keep );
  MMDB.DeleteSelection ( selHnd_del );
  //  update internal references
  MMDB.FinishStructEdit();
  if (foundAltConf) return 0;
  else return EMPTY_SELECTION;

}

// -------------------  setOccupancyCutoff  --------------------------

int  setOccupancyCutoff ( mmdb::RManager MMDB, mmdb::realtype cutoff )  {
int   selHnd,nSelAtoms,i,n_deleted=0;
mmdb::PPAtom selAtom;

  // select all atoms for primary loop
  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd,mmdb::STYPE_ATOM,"*",mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );
  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++) {
      if (selAtom[i]->occupancy <= cutoff) {
        delete selAtom[i];
        selAtom[i] = NULL;
        ++n_deleted;
      }
    }
  }

  if (n_deleted) {
    //  update internal references
    MMDB.FinishStructEdit();
    return 0;
  } else {
    return EMPTY_SELECTION;
  }

}

// -------------------  removeAnisou  --------------------------

int  removeAnisou ( mmdb::RManager MMDB )  {
int   selHnd,nSelAtoms,i;
bool anisou = false;
mmdb::PPAtom selAtom;

  // select all atoms for primary loop
  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd,mmdb::STYPE_ATOM,"*",mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );
  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++) {
      if (selAtom[i]->WhatIsSet & mmdb::ASET_Anis_tFac) {
        anisou = true;
        selAtom[i]->WhatIsSet &= ~mmdb::ASET_Anis_tFac;
      }
    }
  }
  if (anisou) {
    MMDB.FinishStructEdit();
    return 0;
  }
  else {
    return EMPTY_SELECTION;
  }

}

// -------------------  renameChain  --------------------------

int  renameChain ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName )  {
int      selHnd,nSelChains,i;
 mmdb::PPChain selChain;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_CHAIN,oldName, mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selChain,nSelChains );

  if (nSelChains>0)  {
    for (i=0;i<nSelChains;i++)
      selChain[i]->SetChainID ( newName );
    printf ( "    %i chain(s) were assigned the chain ID '%s'\n",
             nSelChains,newName );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO CHAINS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  renameResidue  ------------------------

int  renameResidue ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName )  {
int        selHnd,nSelResidues,i;
mmdb::PPResidue selResidue;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_RESIDUE,oldName, mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selResidue,nSelResidues   );

  if (nSelResidues>0)  {
    for (i=0;i<nSelResidues;i++)
      selResidue[i]->SetResName ( newName );
    printf ( "    %i residues were assigned the residue name '%s'\n",
             nSelResidues,newName );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO RESIDUES SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  renameAtom  ------------------------

int  renameAtom ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName )  {
int     selHnd,nSelAtoms,i;
mmdb::PPAtom selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,oldName, mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++)
      selAtom[i]->SetAtomName ( newName );
    printf ( "    %i atoms were assigned the atom name '%s'\n",
             nSelAtoms,newName );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  renameElement  ------------------------

int  renameElement ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName )  {
int     selHnd,nSelAtoms,i;
mmdb::PPAtom selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,oldName, mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++)
      selAtom[i]->SetElementName ( newName );
    printf ( "    %i atoms were assigned the chemical element name '%s'\n",
             nSelAtoms,selAtom[0]->element );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  deleteModel  --------------------------

int  deleteModel ( mmdb::RManager MMDB, mmdb::pstr selection )  {
int      selHnd,nSelModels,i;
mmdb::PPModel selModel;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_MODEL,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selModel,nSelModels );

  if (nSelModels>0)  {
    for (i=0;i<nSelModels;i++)  {
      delete selModel[i];
      selModel[i] = NULL;
    }
    printf ( "    %i model(s) were deleted.\n",nSelModels );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO MODELS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  deleteChain  --------------------------

int  deleteChain ( mmdb::RManager MMDB, mmdb::pstr selection )  {
int      selHnd,nSelChains,i;
 mmdb::PPChain selChain;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_CHAIN,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selChain,nSelChains );

  if (nSelChains>0)  {
    for (i=0;i<nSelChains;i++)  {
      delete selChain[i];
      selChain[i] = NULL;
    }
    printf ( "    %i chain(s) were deleted.\n",nSelChains );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO CHAINS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  removeChain  --------------------------

int rmChain ( mmdb::RManager MMDB, mmdb::RPChain chain )  {
  if (chain)  {
    mmdb::PModel model = chain->GetModel();
    if (model && (model->GetNumberOfChains()<=1))  {
      MMDB.DeleteModel ( model->GetSerNum() );
      return 1;
    } else  {
      delete chain;
      chain = NULL;
      if (model)
        model->TrimChainTable();
    }
  }
  return 0;
}

int  removeChain ( mmdb::RManager MMDB, mmdb::pstr selection )  {
mmdb::PPChain selChain;
int           selHnd,nSelChains,i,im;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_CHAIN,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selChain,nSelChains );

  if (nSelChains>0)  {
    im = 0;
    for (i=0;i<nSelChains;i++)
      im += rmChain ( MMDB,selChain[i] );
    printf ( "    %i chain(s) and %i models were removed.\n",
             nSelChains,im );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO CHAINS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  deleteResidue  ------------------------

int  deleteResidue ( mmdb::RManager MMDB, mmdb::pstr selection )  {
mmdb::PPResidue selResidue;
int             selHnd,nSelResidues,i;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_RESIDUE,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selResidue,nSelResidues   );

  if (nSelResidues>0)  {
    for (i=0;i<nSelResidues;i++)  {
      delete selResidue[i];
      selResidue[i] = NULL;
    }
    printf ( "    %i residues were deleted.\n",nSelResidues );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO RESIDUES SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  removeResidue  ------------------------

int  rmResidue ( mmdb::RManager MMDB, mmdb::RPResidue res )  {
  if (res)  {
    mmdb::PChain chain = res->GetChain();
    if (chain && (chain->GetNumberOfResidues()<=1))  {
      rmChain ( MMDB,chain );
      return 1;
    } else  {
      delete res;
      res = NULL;
      if (chain)
        chain->TrimResidueTable();
    }
  }
  return 0;
}

int  removeResidue ( mmdb::RManager MMDB, mmdb::pstr selection )  {
mmdb::PPResidue selResidue;
int             selHnd,nSelResidues,i,ic;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_RESIDUE,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selResidue,nSelResidues   );

  if (nSelResidues>0)  {
    ic = 0;
    for (i=0;i<nSelResidues;i++)
      ic += rmResidue ( MMDB,selResidue[i] );
    printf ( "    %i residues and %i chains were removed.\n",
             nSelResidues,ic );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO RESIDUES SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  deleteAtom  ------------------------

int  deleteAtom ( mmdb::RManager MMDB, mmdb::pstr selection )  {
mmdb::PPAtom selAtom;
int          selHnd,nSelAtoms,i;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++)  {
      delete selAtom[i];
      selAtom[i] = NULL;
    }
    printf ( "    %i atoms were deleted.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    //  update internal references
    MMDB.FinishStructEdit();
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}

// -------------------  removeAtom  ------------------------

int  rmAtom ( mmdb::RManager MMDB, mmdb::RPAtom atom )  {
  if (atom)  {
    mmdb::PResidue res = atom->GetResidue();
    delete atom;
    atom = NULL;
    if (res)  {
      if (res->GetNumberOfAtoms(false)<1)  {
        rmResidue ( MMDB,res );
        return 1;
      }
      res->TrimAtomTable();
    }
  }
  return 0;
}

int  removeAtom ( mmdb::RManager MMDB, mmdb::pstr selection )  {
mmdb::PPAtom selAtom;
int          selHnd,nSelAtoms,i,ir;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    ir = 0;
    for (i=0;i<nSelAtoms;i++)
      ir += rmAtom ( MMDB,selAtom[i] );
    printf ( "    %i atoms and %i residues were removed.\n",
             nSelAtoms,ir );
    MMDB.DeleteSelection ( selHnd );
    //  update internal references
    MMDB.FinishStructEdit();
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}

// -------------------  deleteDist  ------------------------

int  deleteDist ( mmdb::RManager MMDB, mmdb::realtype x0, mmdb::realtype y0,
                                      mmdb::realtype z0, mmdb::realtype R0 )  {
int     selHnd,nSelAtoms,i;
mmdb::PPAtom selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,0,"*",mmdb::ANY_RES,"*",mmdb::ANY_RES,"*","*",
                     "*","*","*","*","*",-1.0,-1.0,x0,y0,z0,R0, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++)  {
      delete selAtom[i];
      selAtom[i] = NULL;
    }
    printf ( "    %i atoms were deleted.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    //  update internal references
    MMDB.FinishStructEdit();
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return EMPTY_SELECTION;
  }

}


// -------------------  leaveModel  --------------------------

int  leaveModel ( mmdb::RManager MMDB, mmdb::pstr selection )  {
int           selHnd,nSelModels1,nSelModels,i;
mmdb::PPModel selModel;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_MODEL,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selModel,nSelModels1 );

  if (!nSelModels1)  {
    printf ( " ***** NO MODELS SELECTED.\n" );
// --- change made on 16.01.2013 (report by PavolSkubak)
//    MMDB.DeleteSelection ( selHnd );
//    return EMPTY_SELECTION;
  }

  MMDB.Select      ( selHnd, mmdb::STYPE_MODEL,"/*", mmdb::SKEY_XOR );
  MMDB.GetSelIndex ( selHnd,selModel,nSelModels );

  if (nSelModels>0)  {
    for (i=0;i<nSelModels;i++)  {
      delete selModel[i];
      selModel[i] = NULL;
    }
    printf ( "    %i model(s) were deleted, %i left.\n",
             nSelModels,nSelModels1 );
  } else  {
    printf ( " ***** NO MODELS SELECTED FOR DELETION.\n" );
  }
  MMDB.DeleteSelection ( selHnd );
  return 0;

}


// -------------------  leaveChain  --------------------------

int  leaveChain ( mmdb::RManager MMDB, mmdb::pstr selection )  {
int      selHnd,nSelChains1,nSelChains,i;
 mmdb::PPChain selChain;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_CHAIN,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selChain,nSelChains1 );

  if (!nSelChains1)  {
    printf ( " ***** NO CHAINS SELECTED.\n" );
// --- change made on 16.01.2013 (report by PavolSkubak)
//    MMDB.DeleteSelection ( selHnd );
//    return EMPTY_SELECTION;
  }

  MMDB.Select      ( selHnd, mmdb::STYPE_CHAIN,"/*/*", mmdb::SKEY_XOR );
  MMDB.GetSelIndex ( selHnd,selChain,nSelChains );

  if (nSelChains>0)  {
    for (i=0;i<nSelChains;i++)  {
      delete selChain[i];
      selChain[i] = NULL;
    }
    printf ( "    %i chain(s) were deleted, %i left.\n",
             nSelChains,nSelChains1 );
  } else  {
    printf ( " ***** NO CHAINS SELECTED FOR DELETION.\n" );
  }
  MMDB.DeleteSelection ( selHnd );
  return 0;

}


// -------------------  leaveResidue  ------------------------

int  leaveResidue ( mmdb::RManager MMDB, mmdb::pstr selection )  {
int        selHnd,nSelResidues,nSelResidues1,i;
mmdb::PPResidue selResidue;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_RESIDUE,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selResidue,nSelResidues1 );

  if (!nSelResidues1)  {
    printf ( " ***** NO RESIDUES SELECTED.\n" );
// --- change made on 16.01.2013 (report by PavolSkubak)
//    MMDB.DeleteSelection ( selHnd );
//    return EMPTY_SELECTION;
  }

  MMDB.Select      ( selHnd, mmdb::STYPE_RESIDUE,"/*/*/*", mmdb::SKEY_XOR );
  MMDB.GetSelIndex ( selHnd,selResidue,nSelResidues  );

  if (nSelResidues>0)  {
    for (i=0;i<nSelResidues;i++)  {
      delete selResidue[i];
      selResidue[i] = NULL;
    }
    printf ( "    %i residues were deleted, %i left.\n",
             nSelResidues,nSelResidues1 );
  } else  {
    printf ( " ***** NO RESIDUES SELECTED FOR DELETION.\n" );
  }
  MMDB.DeleteSelection ( selHnd );
  return 0;

}


// -------------------  leaveAtom  ------------------------

int  leaveAtom ( mmdb::RManager MMDB, mmdb::pstr selection )  {
int          selHnd,nSelAtoms,nSelAtoms1,i;
mmdb::PPAtom selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms1 );

  if (!nSelAtoms1)  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
// --- change made on 16.01.2013 (report by PavolSkubak)
//    MMDB.DeleteSelection ( selHnd );
//    return EMPTY_SELECTION;
  }

  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,"/*/*/*/*:*", mmdb::SKEY_XOR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++)  {
      delete selAtom[i];
      selAtom[i] = NULL;
    }
    printf ( "    %i atoms were deleted, %i left.\n",
             nSelAtoms,nSelAtoms1 );
  } else  {
    printf ( " ***** NO ATOMS SELECTED FOR DELETION.\n" );
  }
  MMDB.DeleteSelection ( selHnd );
  return 0;

}

// -------------------  leaveDist  ------------------------

int  leaveDist ( mmdb::RManager MMDB, mmdb::realtype x0, mmdb::realtype y0,
                                      mmdb::realtype z0, mmdb::realtype R0 )  {
int     selHnd,nSelAtoms,nSelAtoms1,i;
mmdb::PPAtom selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,0,"*",mmdb::ANY_RES,"*",mmdb::ANY_RES,"*","*",
                     "*","*","*","*","*",-1.0,-1.0,x0,y0,z0,R0, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms1 );

  if (!nSelAtoms1)  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
// --- change made on 16.01.2013 (report by PavolSkubak)
//    MMDB.DeleteSelection ( selHnd );
//    return EMPTY_SELECTION;
  }

  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,"/*/*/*/*:*", mmdb::SKEY_XOR );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++)  {
      delete selAtom[i];
      selAtom[i] = NULL;
    }
    printf ( "    %i atoms were deleted, %i left.\n",
             nSelAtoms,nSelAtoms1 );
  } else  {
    printf ( " ***** NO ATOMS SELECTED FOR DELETION.\n" );
  }
  MMDB.DeleteSelection ( selHnd );
  return 0;

}

// -------------------  EulerRotation  --------------------------

int  EulerRotation ( mmdb::RManager MMDB, mmdb::pstr selection,
                     mmdb::realtype alpha, mmdb::realtype beta, mmdb::realtype gamma )  {
mmdb::realtype xmc,ymc,zmc, F;
int      selHnd,nSelAtoms;
mmdb::PPAtom  selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {

    GetMassCenter ( selAtom,nSelAtoms,xmc,ymc,zmc );
    F = mmdb::Pi/180.0;
    EulerRotation ( selAtom,nSelAtoms,alpha*F,beta*F,gamma*F,
                         xmc,ymc,zmc );

    printf ( "    %i atom(s) rotated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  }

}

int  EulerRotation ( mmdb::RManager MMDB, mmdb::pstr selection,
                     mmdb::realtype alpha, mmdb::realtype beta, mmdb::realtype gamma,
                     mmdb::realtype x0,    mmdb::realtype y0,   mmdb::realtype z0 )  {
mmdb::realtype F;
int      selHnd,nSelAtoms;
mmdb::PPAtom  selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {

    F = mmdb::Pi/180.0;
    EulerRotation ( selAtom,nSelAtoms,alpha*F,beta*F,gamma*F,
                         x0,y0,z0 );

    printf ( "    %i atom(s) rotated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  }

}

int  FracTranslation ( mmdb::RManager MMDB, mmdb::pstr selection,
                     mmdb::realtype x,    mmdb::realtype y,   mmdb::realtype z )  {
int      selHnd,nSelAtoms,i;
mmdb::PPAtom  selAtom;
mmdb::realtype xo,yo,zo;
mmdb::mat33 ident = {1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0};
mmdb::vect3 trans;

 MMDB.Frac2Orth(x,y,z,xo,yo,zo);
 trans[0] = xo;
 trans[1] = yo;
 trans[2] = zo;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {

    // there doesn't seem to be a function to apply a transformation
    // or translation to an array or selection of atoms
    for (i=0;i<nSelAtoms;i++) {
      selAtom[i]->Transform(ident,trans);
    }

    printf ( "    %i atom(s) translated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  }

}

int  OrthTranslation ( mmdb::RManager MMDB, mmdb::pstr selection,
                     mmdb::realtype x,    mmdb::realtype y,   mmdb::realtype z )  {
int      selHnd,nSelAtoms,i;
mmdb::PPAtom  selAtom;
mmdb::mat33 ident = {1.0,0.0,0.0,0.0,1.0,0.0,0.0,0.0,1.0};
mmdb::vect3 trans;

 trans[0] = x;
 trans[1] = y;
 trans[2] = z;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {
    for (i=0;i<nSelAtoms;i++) {
      selAtom[i]->Transform(ident,trans);
    }

    printf ( "    %i atom(s) translated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  }

}


int  VectorRotation ( mmdb::RManager MMDB, mmdb::pstr selection, mmdb::realtype alpha,
                      mmdb::realtype vx, mmdb::realtype vy, mmdb::realtype vz,
                      mmdb::realtype x,  mmdb::realtype y,  mmdb::realtype z )  {
int      selHnd,nSelAtoms;
mmdb::PPAtom  selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {

    VectorRotation ( selAtom,nSelAtoms,alpha*mmdb::Pi/180.0,
                          vx,vy,vz,x,y,z );

    printf ( "    %i atom(s) rotated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  }

}

int  VectorRotation ( mmdb::RManager MMDB, mmdb::pstr selection, mmdb::realtype alpha,
                      mmdb::realtype vx, mmdb::realtype vy, mmdb::realtype vz )  {
mmdb::realtype xmc,ymc,zmc;
int      selHnd,nSelAtoms;
mmdb::PPAtom  selAtom;

  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {

    GetMassCenter  ( selAtom,nSelAtoms,xmc,ymc,zmc );
    VectorRotation ( selAtom,nSelAtoms,alpha*mmdb::Pi/180.0,
                          vx,vy,vz,xmc,ymc,zmc );

    printf ( "    %i atom(s) rotated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  }

}

int  VectorRotation ( mmdb::RManager MMDB, mmdb::pstr selection, mmdb::realtype alpha,
                      mmdb::pstr atom1, mmdb::pstr atom2 )  {
mmdb::realtype x1,y1,z1, x2,y2,z2;
int      selHnd,nSelAtoms;
mmdb::PPAtom  selAtom;

  selHnd = MMDB.NewSelection();

  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,atom1, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );
  if (nSelAtoms==0)  {
    printf ( " ***** ATOM '%s' NOT FOUND.\n",atom1 );
    MMDB.DeleteSelection ( selHnd );
    return 1;
  } else if (nSelAtoms>1)  {
    printf ( " ***** '%s' GIVES MORE THAN ONE ATOM.\n",atom1 );
    MMDB.DeleteSelection ( selHnd );
    return 2;
  }
  x1 = selAtom[0]->x;
  y1 = selAtom[0]->y;
  z1 = selAtom[0]->z;

  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,atom2, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );
  if (nSelAtoms==0)  {
    printf ( " ***** ATOM '%s' NOT FOUND.\n",atom2 );
    MMDB.DeleteSelection ( selHnd );
    return 3;
  } else if (nSelAtoms>1)  {
    printf ( " ***** '%s' GIVES MORE THAN ONE ATOM.\n",atom2 );
    MMDB.DeleteSelection ( selHnd );
    return 4;
  }
  x2 = selAtom[0]->x;
  y2 = selAtom[0]->y;
  z2 = selAtom[0]->z;

  MMDB.Select      ( selHnd, mmdb::STYPE_ATOM,selection, mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd,selAtom,nSelAtoms );

  if (nSelAtoms>0)  {

    VectorRotation ( selAtom,nSelAtoms,alpha*mmdb::Pi/180.0,
                          x2-x1,y2-y1,z2-z1,x1,y1,z1 );

    printf ( "    %i atom(s) rotated.\n",nSelAtoms );
    MMDB.DeleteSelection ( selHnd );
    return 0;
  } else  {
    printf ( " ***** NO ATOMS SELECTED.\n" );
    MMDB.DeleteSelection ( selHnd );
    return 5;
  }

}
