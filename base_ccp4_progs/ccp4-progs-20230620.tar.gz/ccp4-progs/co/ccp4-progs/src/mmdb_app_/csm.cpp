//
//  =================================================================
//
//    05.03.10   <--  Date of Last Modification.
//                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  -----------------------------------------------------------------
//
//  **** Module  :  csm  <implementation>
//       ~~~~~~~~~
//  **** Project :  Chemical Structure Matching (CSM)
//       ~~~~~~~~~
//  **** Classes :  Main program.
//       ~~~~~~~~~
//
//  (C) E. Krissinel 2010
//
//  =================================================================
//

#ifndef  __STRING_H
#include <string.h>
#endif

#ifndef  __STDLIB_H
#include <stdlib.h>
#endif

#include "csm_2dmatch.h"

void printInstructions ( mmdb::pstr argv0 )  {

  printf (
  "\n"
  " Chemical Structure Matching\n"
  " ---------------------------\n"
  "\n"
  " USAGE:\n"
  " ~~~~~~\n"
  "\n"
  " 1. Matching a pair of residue selections\n"
  "\n"
  " %s s1.pdb [-s CID1] s2.pdb [-s CID2] [-sym {on|off}] \\\n"
  "   [-h {on|off}] [-p min:max]\n"
  "\n"
  " where [-s CID1/2] are optional selection strings in "
  "SCOP convention:\n"
  "  \"*\", \"(all)\"            - take all file\n"
  "  \"-\"                     - take chain without chain ID\n"
  "  \"a:Ni-Mj,b:Kp-Lq,...\"   - take chain a residue number N\n"
  "                           insertion code i to residue numberM\n"
  "                           insertion code j plus chain b\n"
  "                           residue number K insertion code p to\n"
  "                           residue number L insertion code q\n"
  "                           and so on.\n"
  "  \"a:,b:...\"              - take whole chains a and b and so on\n"
  "  \"a:,b:Kp-Lq,...\"        - any combination of the above.\n"
  "\n"
  " Optional parameters:\n"
  "   -sym off      - excludes chemically equivalent matches.\n"
  "                   Default: -sym on\n"
  "   -h   off      - excludes hydrogens prior matching.\n"
  "                   Default: -h off\n"
  "   -p  min:max   - persistence level. CSM looks for maximum\n"
  "                   common substructures, first with 'min' atoms\n"
  "                   less than the smaller structure, and if no\n"
  "                   matches are found, repeats matching with\n"
  "                   gradual increase in allowed number of unmatched\n"
  "                   atoms up to 'max' atoms unmatched.\n"
  "                   Default: -p 0:2\n"
  "\n"
  "\n"
  " 2. Matching a residue selection to the content of SRS\n"
  "\n"
  " %s s1.pdb [-s CID1] -srs srs_dir [-sym {on|off}] \\\n"
  "   [-h {on|off}] [-p min:max]\n"
  "\n"
  " where 'srs_dir' is path to directory with *.srs files, and other\n"
  " parameters have the same meaining as above."
  "\n"
  " Based on graph-matching algorithm published in\n"
  "  E. Krissinel and K. Henrick (2004). Common subgraph isomorphism\n"
  "  detection by backtracking search. Software: Practice and\n"
  "  Experience, 34, Iss. 6, p.591-607.\n"
  ,argv0,argv0
   );

}

PCSMStructure getStructure ( mmdb::cpstr fileName,
                             mmdb::cpstr selection )  {
PCSMStructure CS;
int           rc;

  CS  = new CSMStructure();

  rc  = CS->loadStructure ( fileName );
  if (!rc)
    rc = CS->construct2DGraph ( selection );

  if (rc)   {
    delete CS;
    CS = NULL;
  }

  return CS;

}

void getParameters ( mmdb::pstr & fname1, mmdb::pstr & sel1,
                     mmdb::pstr & fname2, mmdb::pstr & sel2,
                     mmdb::pstr & srs_dir,
                     bool & sym, bool & H,
                     int & pmin, int & pmax,
                     mmdb::pstr argv[], int argc )  {
char       S[100];
mmdb::pstr p;
int        argc1,argNo;

  mmdb::CreateCopy ( fname1,""  );
  mmdb::CreateCopy ( sel1  ,"*" );
  mmdb::CreateCopy ( fname2,""  );
  mmdb::CreateCopy ( sel2  ,"*" );

  sym  = true;
  H    = false;
  pmin = 0;
  pmax = 2;

  argc1 = argc - 1;
  argNo = 1;

  if (argNo<argc1)  {
    mmdb::CreateCopy ( fname1,argv[argNo++] );
    if (argNo<argc1)  {
      if (!strcasecmp(argv[argNo],"-s"))  {
        argNo++;
        mmdb::CreateCopy ( sel1,argv[argNo++] );
      }
    }
  }

  if (argNo<argc)  {
    mmdb::CreateCopy ( fname2,argv[argNo++] );
    if (!strcmp(fname2,"-srs"))  {
      delete[] fname2;
      delete[] sel2;
      fname2 = NULL;
      sel2   = NULL;
      if (argNo<argc)
        mmdb::CreateCopy ( srs_dir,argv[argNo++] );
    } else if (argNo<argc1)  {
      if (!strcasecmp(argv[argNo],"-s"))  {
        argNo++;
        mmdb::CreateCopy ( sel2,argv[argNo++] );
      }
    }
  }

  while (argNo<argc1)  {
    if (!strcmp(argv[argNo],"-sym"))  {
      argNo++;
      if (!strcasecmp(argv[argNo],"on"))   sym = true;
      if (!strcasecmp(argv[argNo],"off"))  sym = false;
    } else if (!strcmp(argv[argNo],"-h"))  {
      argNo++;
      if (!strcasecmp(argv[argNo],"on"))   H = true;
      if (!strcasecmp(argv[argNo],"off"))  H = false;
    } else if (!strcmp(argv[argNo],"-p"))  {
      argNo++;
      strcpy ( S,argv[argNo] );
      p = mmdb::FirstOccurence ( S,':' );
      if (p) *p = char(0);
      pmin = atoi(S);
      if (p)  {
        p++;
        pmax = atoi(p);
      }
    } else
      printf ( "\n !! '%s': parameter not understood\n",argv[argNo] );
    argNo++;
  }

  if (pmax<pmin)  pmax = pmin;

}

int main ( int argc, char *argv[] )  {
PCSMStructure CS1,CS2;
CSM2DMatch    CSMatch;
mmdb::pstr    fname1,sel1, fname2,sel2, srs_dir;
int           pmin,pmax, i;
bool          sym,H;

  if (argc<3)  {
    printInstructions ( argv[0] );
    return 1;
  }

  if ((!strcmp(argv[1],"-?")) || (!strcasecmp(argv[1],"-help")) ||
      (!strcasecmp(argv[1],"--help")))  {
    printInstructions ( argv[0] );
    return 1;
  }

  mmdb::InitMatType();

  fname1  = NULL;
  sel1    = NULL;
  fname2  = NULL;
  sel2    = NULL;
  srs_dir = NULL;
  CS1     = NULL;
  CS2     = NULL;

  getParameters ( fname1,sel1,fname2,sel2,srs_dir,
                  sym,H, pmin,pmax, argv,argc );

  printf (
    "\n"
    " ======= Getting data and options:\n\n"
    " Structure #1: '%s' from '%s'\n"
    " Structure #2: '%s' from '%s'\n"
    ,sel1,fname1,sel2,fname2
    );
  printf ( " Symmetry    : " );
  if (sym)  printf ( "reduce\n" );
      else  printf ( "disregard\n" );
  printf ( " Hydrogens   : " );
  if (H)  printf ( "keep\n" );
    else  printf ( "disregard\n" );
    printf ( " Persistence : from %i to %i unmatched atoms\n\n",
             pmin,pmax );

  CS1 = getStructure ( fname1,sel1 );
  if (CS1)  {
    if (!H)
      CS1->removeHydrogens();
    CS2 = getStructure ( fname2,sel2 );
    if (CS2 && (!H))
      CS2->removeHydrogens();
  }

  //  ---------------------------------------------------------------

  if (CS1)
    printf ( " .. Structure in '%s' read and understood,\n"
             "    %i atoms selected\n",
             CS1->getFileName(),CS1->getNofAtoms() );
  else
    printf ( " ** Cannot read structure from '%s'\n",fname1 );

  if (CS2)
    printf ( " .. Structure in '%s' read and understood,\n"
             "    %i atoms selected\n",
             CS2->getFileName(),CS2->getNofAtoms() );
  else
    printf ( " ** Cannot read structure from '%s'\n",fname2 );

  //  ---------------------------------------------------------------

  if (CS1 && CS2)  {

    if (sym)  {
      CS1->makeSymmetryRelief();
      CS2->makeSymmetryRelief();
    }

    CS1->build2DGraph ( false );
    CS2->build2DGraph ( false );

    i = pmin;
    do {
      CSMatch.matchStructures ( CS1,CS2,i );
      i++;
    } while ((i<=pmax) && (CSMatch.getNofMatches()<=0));

    printf ( "\n ======= Total matches found: %i\n",
             CSMatch.getNofMatches() );

    for (i=0;i<CSMatch.getNofMatches();i++)
      CSMatch.printMatch ( i,CS1,CS2 );

  }

  if (CS1)     delete CS1;
  if (CS2)     delete CS2;
  if (fname1)  delete[] fname1;
  if (fname2)  delete[] fname2;
  if (sel1)    delete[] sel1;
  if (sel2)    delete[] sel2;
  if (srs_dir) delete[] srs_dir;

  return 0;

}
