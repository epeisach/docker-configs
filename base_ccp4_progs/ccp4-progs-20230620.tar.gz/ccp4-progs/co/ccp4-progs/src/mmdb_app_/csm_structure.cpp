//
//  =================================================================
//
//    05.03.10   <--  Date of Last Modification.
//                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  -----------------------------------------------------------------
//
//  **** Module  :  csm_structure  <implementation>
//       ~~~~~~~~~
//  **** Project :  Chemical Structure Matching (CSM)
//       ~~~~~~~~~
//  **** Classes :  CSMStructure  - chemical structure
//       ~~~~~~~~~
//
//  (C) E. Krissinel 2010
//
//  =================================================================
//

#include "csm_structure.h"

#include "mmdb2/mmdb_tables.h"

CSMStructure::CSMStructure()  {
  Init();
}

CSMStructure::~CSMStructure()  {
  FreeMemory();
}

void CSMStructure::Init()  {
  M     = NULL;
  G2    = NULL;
  fname = NULL;
  sel   = NULL;
}

void CSMStructure::FreeMemory()  {
  if (M)      delete M;
  if (G2)     delete G2;
  if (fname)  delete[] fname;
  if (sel)    delete[] sel;
  M     = NULL;
  G2    = NULL;
  fname = NULL;
  sel   = NULL;
}

int CSMStructure::loadStructure ( mmdb::cpstr fileName )  {

  mmdb::CreateCopy ( fname,fileName );

  if (!M)  M = new mmdb::Manager();

  M->SetFlag ( mmdb::MMDBF_PrintCIFWarnings );
  return M->ReadCoorFile ( fileName );

}

int CSMStructure::construct2DGraph ( mmdb::cpstr selection )  {
// 'selection' string is of the following format:
//    "*", "(all)"            - take all file
//    "-"                     - take chain without chain ID
//    "a:Ni-Mj,b:Kp-Lq,..."   - take chain a residue number N
//                             insertion code i to residue numberM
//                             insertion code j plus chain b
//                             residue number K insertion code p to
//                             residue number L insertion code q
//                             and so on.
//    "a:,b:..."              - take whole chains a and b and so on
//    "a:,b:Kp-Lq,..."        - any combination of the above.
//
mmdb::PPAtom atom;
int          selHnd,nAtoms;

  mmdb::CreateCopy ( sel,selection );

  if (!M)  return CSM_noStructure;

  selHnd = M->NewSelection();

  M->DeleteAltLocs();
  M->SelectDomain ( selHnd,selection,mmdb::STYPE_ATOM,mmdb::SKEY_NEW, 1 );

  M->GetSelIndex ( selHnd,atom,nAtoms );

  if (nAtoms<=0)  {
    M->DeleteSelection ( selHnd );
    return CSM_noAtomsSelected;
  }

  if (!G2)  G2 = new mmdb::math::Graph();
      else  G2->Reset();

  if (G2->MakeGraph(atom,nAtoms)!=mmdb::math::MKGRAPH_Ok)  {
    M->DeleteSelection ( selHnd );
    return CSM_cantMakeGraph;
  }

  M->DeleteSelection ( selHnd );

  return CSM_Ok;

}

void  CSMStructure::removeHydrogens()  {
  if (G2)
    G2->ExcludeType ( mmdb::getElementNo("H") );
}

void  CSMStructure::makeSymmetryRelief()  {
  if (G2)
    G2->MakeSymmetryRelief ( false );
}

void  CSMStructure::build2DGraph ( bool bondOrder )  {
  G2->Build ( bondOrder );
}

int  CSMStructure::getNofAtoms()  {
  if (G2)  return G2->GetNofVertices();
  return -1;
}
