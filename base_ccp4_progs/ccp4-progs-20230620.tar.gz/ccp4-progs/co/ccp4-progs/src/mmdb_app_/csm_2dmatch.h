//
//  =================================================================
//
//    05.03.10   <--  Date of Last Modification.
//                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  -----------------------------------------------------------------
//
//  **** Module  :  csm_2dmatch  <interface>
//       ~~~~~~~~~
//  **** Project :  Chemical Structure Matching (CSM)
//       ~~~~~~~~~
//  **** Classes :  CSM2DMatch  - 2D graph matching
//       ~~~~~~~~~
//
//  (C) E. Krissinel 2010
//
//  =================================================================
//

#ifndef CSM_2DMATCH_H
#define CSM_2DMATCH_H

#include "csm_structure.h"

class CSM2DMatch  {

  public:
    CSM2DMatch();
    ~CSM2DMatch();

    void matchStructures ( PCSMStructure CS1, PCSMStructure CS2,
                           int maxNofUmatchedAtoms );
    int  getNofMatches   ();
    void printMatch      ( int matchNo, PCSMStructure CS1,
                                        PCSMStructure CS2 );

  protected:
    mmdb::math::PGraphMatch  GM;

    void  Init      ();
    void  FreeMemory();

};

#endif // CSM_2DMATCH_H
