//
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//
// =========================================================================
//
//
//
//  10 September 2001
//
//
// =========================================================================
//

#ifndef  __PCUR_Funcs__
#define  __PCUR_Funcs__


#include "mmdb2/mmdb_manager.h"
#include "mmdb2/mmdb_tables.h"

#define  END_OF_INPUT              111
#define  EMPTY_SELECTION            11

#define  Err_RENCHAIN             -100
#define  Err_RENRESIDUE           -101
#define  Err_RENATOM              -102
#define  Err_RENELEMENT           -103
#define  Err_DELMODEL             -104
#define  Err_DELCHAIN             -105
#define  Err_DELRESIDUE           -106
#define  Err_DELATOM              -107
#define  Err_LVMODEL              -108
#define  Err_LVCHAIN              -109
#define  Err_LVRESIDUE            -110
#define  Err_LVATOM               -111
#define  Err_WRITE                -112
#define  Err_WRITE_TYPE           -113
#define  Err_SYMMETRY             -114
#define  Err_SYMMETRY_NOLIB       -115
#define  Err_SYMMETRY_SPGRP       -116
#define  Err_SYMMETRY_NOSYMOP     -117
#define  Err_GEOMETRY             -118
#define  Err_GEOMETRY_FORMAT      -119
#define  Err_GENUNIT_NOSYMOP      -120
#define  Err_GENUNIT_TRANSFORM    -121
#define  Err_GENUNIT_CELL         -122
#define  Err_SYMOP                -123
#define  Err_SYMCOMMIT_NOSYMOP    -124
#define  Err_SYMCOMMIT_TRANSFORM  -125
#define  Err_SYMCOMMIT_CELL       -126
#define  Err_SYMCOMMIT_UNKNOWN    -127
#define  Err_MKCHAINIDS           -128
#define  Err_SPLITTOCHAINS        -129
#define  Err_ROTATE1              -130
#define  Err_ROTATE2              -131
#define  Err_ROTATE3              -132
#define  Err_ROTATE4              -133
#define  Err_VROTATE1             -134
#define  Err_VROTATE2             -135
#define  Err_VROTATE3             -136
#define  Err_VROTATE4             -137
#define  Err_VROTATE5             -138
#define  Err_TRANSLATE1           -139
#define  Err_TRANSLATE2           -140
#define  Err_DELDIST              -141
#define  Err_LVDIST               -142
#define  Err_KEYWORD              -200

#define n_pc_ResNames  28
mmdb::cpstr const pc_ResidueName[n_pc_ResNames] = {
  "ALA", "ARG", "ASN", "ASP", "CYS", "CYH", "GLN",
  "GLU", "GLY", "HIS", "ILE", "LEU", "LYS", "MET",
  "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
  "HEM", "WAT", "HOH", "TIP", "SUL", "END", "DUM"
};


// ------------------- input drivers  -------------------------

extern void summarise ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB,  int & RC );

extern void delsolvent   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void delhydrogen  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void mostprob  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void cutoffocc  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void delanisou  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void renchain   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void renresidue ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void renatom    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void renelement ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void delmodel   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void delchain   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void delresidue ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void delatom    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void remchain   ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB,  int & RC );

extern void remresidue ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB,  int & RC );

extern void rematom    ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB,  int & RC );

extern void deldist    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void lvmodel    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void lvchain    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void lvresidue  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void lvatom     ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void lvdist     ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void genter     ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB,  int & RC );

extern void delter     ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB,  int & RC );

extern void sernum     ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void mvsolvent  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void write      ( CCP4PARSERTOKEN * token, int ntok,
                         int & FType,  int & RC );

extern void symmetry   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  mmdb::pstr line, int & RC );

extern void geometry   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void genunit    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void symop      ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RGenSym   GenSym,   int & RC );

extern void symcommit  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  mmdb::RGenSym GenSym, int & RC );

extern void mkchainids ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void splittochains ( CCP4PARSERTOKEN * token, int ntok,
                        mmdb::RManager MMDB, mmdb::cpstr fpath, int & RC );

extern void pdb_meta   ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB, mmdb::cpstr fpath, int & RC );

extern void rotate     ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void translate  ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );

extern void vrotate    ( CCP4PARSERTOKEN * token, int ntok,
                         mmdb::RManager MMDB,  int & RC );


// -----------------  action functions  -----------------------

extern int summariseModel      ( mmdb::RManager MMDB );
extern int summariseModel_json ( mmdb::RManager MMDB );

extern int selectMostProbable  ( mmdb::RManager MMDB, std::string chain_to_keep );

extern int setOccupancyCutoff  ( mmdb::RManager MMDB, mmdb::realtype cutoff );

extern int removeAnisou   ( mmdb::RManager MMDB );

extern int renameChain    ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName );
extern int renameResidue  ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName );
extern int renameAtom     ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName );
extern int renameElement  ( mmdb::RManager MMDB, mmdb::pstr oldName, mmdb::pstr newName );

extern int deleteModel    ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int deleteChain    ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int deleteResidue  ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int deleteAtom     ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int deleteDist     ( mmdb::RManager MMDB, mmdb::realtype x0, mmdb::realtype y0,
                                      mmdb::realtype z0, mmdb::realtype R0 );

extern int removeChain    ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int removeResidue  ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int removeAtom     ( mmdb::RManager MMDB, mmdb::pstr selection );

extern int leaveModel     ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int leaveChain     ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int leaveResidue   ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int leaveAtom      ( mmdb::RManager MMDB, mmdb::pstr selection );
extern int leaveDist      ( mmdb::RManager MMDB, mmdb::realtype x0, mmdb::realtype y0,
                                      mmdb::realtype z0, mmdb::realtype R0 );

extern int EulerRotation  ( mmdb::RManager MMDB, mmdb::pstr selection,
                            mmdb::realtype alpha, mmdb::realtype beta, mmdb::realtype gamma );
extern int EulerRotation  ( mmdb::RManager MMDB, mmdb::pstr selection,
                            mmdb::realtype alpha, mmdb::realtype beta, mmdb::realtype gamma,
                            mmdb::realtype x0,    mmdb::realtype y0,   mmdb::realtype z0 );

extern int FracTranslation ( mmdb::RManager MMDB, mmdb::pstr selection,
                              mmdb::realtype x, mmdb::realtype y, mmdb::realtype z );

extern int OrthTranslation ( mmdb::RManager MMDB, mmdb::pstr selection,
                              mmdb::realtype x, mmdb::realtype y, mmdb::realtype z );

extern int VectorRotation ( mmdb::RManager MMDB, mmdb::pstr selection,
                            mmdb::realtype alpha,
                            mmdb::realtype vx, mmdb::realtype vy, mmdb::realtype vz,
                            mmdb::realtype x,  mmdb::realtype y,  mmdb::realtype z );

extern int VectorRotation ( mmdb::RManager MMDB, mmdb::pstr selection,
                            mmdb::realtype alpha,
                            mmdb::realtype vx, mmdb::realtype vy, mmdb::realtype vz );

extern int VectorRotation ( mmdb::RManager MMDB, mmdb::pstr selection,
                            mmdb::realtype alpha,
                            mmdb::pstr atom1, mmdb::pstr atom2 );

#endif
