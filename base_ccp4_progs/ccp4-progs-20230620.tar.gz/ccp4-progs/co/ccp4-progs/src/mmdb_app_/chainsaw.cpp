//
//     CHAINSAW
//     Copyright (C) 2005 Norman Stein
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//
//
// file: chainsaw.cpp
//
// The aim is, given a trial model for MR and an alignment
// between that model and the target sequence, adjust the
// model to be a better representation of the target.
// This means:
//    1. Remove residues that are not in the target
//      at all (gaps in the alignment)
//    2. Where there is an alignment, truncate the 
//      side chain to either the gamma atom or the 
//      largest common set of atoms
//    3. Correct the torsion angles of the side chain
//      to be more appropriate for the target
//
// Molrep does 1 and 2, but uses its own alignment, rather
// than taking a more accurate external alignment.
//
// Compile as for $CPROG/mmdb_app_/coord_format.cpp
//
// Run as:
//  chainsaw XYZIN model.pdb ALIGNIN align.pir XYZOUT model_out.pdb
//

#include <string>
#include <algorithm>
#include <stdlib.h>
#include <math.h>
#include <stdio.h>
#include <stddef.h>

#include "mmdb2/mmdb_manager.h"
#include "mmdb2/mmdb_tables.h"
#include "mmdb2/mmdb_math_align.h"
#include "ccp4/ccp4_parser.h"
#include "ccp4/ccp4_general.h"
#include "ccp4/ccp4_program.h"

#include "chainsaw.h"

using namespace CCP4;

template <typename T>
T **matrix(int nr, int nc) {
// allocate a matrix
	T **m;
	m = new T*[nr];
	for (int k=0; k<nr; k++) m[k] = new T[nc];
	return m;
}

template <typename T>
void free_matrix(T **m, int nr, int nc) {
// delete a matrix 
	for (int k=0; k<nr; k++) delete [] m[k];
	delete [] m;
}


int main ( int argc, char ** argv, char ** env )  {
mmdb::Manager   MMDBManager;
int            RC,lcount;
char           S[500];

// input parser parameters
int           ntok=0;
char          line[201],*key;
CCP4PARSERTOKEN * token=NULL;
CCP4PARSERARRAY * parser;

int nmod,nchain,nres;
int imod,ichain,ires;
mmdb::PChain chain;
mmdb::PResidue residue;
//ResName resName;
char model_res3name[4];
char model_res1name, target_res1name;
char mode[5];
int nblanks, nblanks2, offset;

 std::string align;
 std::string target_seq;
 std::string model_seq;
 std::string pdb_seq;
 // example of MMDB alignment

 // CFile        f;
 // CAlignment alignment;
 // f.assign("mmdb_out.ali");
 // f.rewrite();
 // alignment.Align(target_seq,model_seq);
 // alignment.OutputResults(f,target_seq,model_seq);

  //  1.  General CCP4 initializations
  ccp4fyp         ( argc,argv );
  ccp4ProgramName ( "CHAINSAW"   );
  ccp4RCSDate     ( "$Date$" ); 
  ccp4_banner();

  printf("Chainsaw reference:  ");
  printf("\n$TEXT:Reference1: $$ comment $$\n");
  printf("N Stein, \"CHAINSAW: a program for mutating pdb files used \n");
  printf("as templates in molecular replacement\", J. Appl. Cryst. 41, 641-643 (2008).\n"); 
  printf("$$\n");
  strcpy(mode,"MIXS");

  //  2.  Make routine initializations, which must always be done
  //      before working with MMDB
  mmdb::InitMatType();

  // 3. Keyworded input

  /* Initialise a parser array used by cparser
     This is used to return the tokens and associated info
     Set maximum number of tokens per line to 20 */
  parser = (CCP4PARSERARRAY *) ccp4_parse_start(20);

  if (parser == NULL) ccperror ( 1,"Couldn't create parser array" );
  
  /* Set some convenient pointers to members of the parser array */
  key   = parser->keyword;
  token = parser->token;

  /* Read lines from stdin until END/end keyword is entered or
     EOF is reached */
  RC   = 0;

  while (!RC) {

    /* Always blank the line before calling cparser
       to force reading from stdin */
    line[0] = '\0';

    /* Call cparser to read input line and break into tokens
       Returns the number of tokens, or zero for eof */
    ntok = ccp4_parser(line,200,parser,1);

    if (ntok < 1) {

      /* End of file encountered */
      RC = 111;

    } else {      

      /* Keyword interpretation starts here */
      if (ccp4_keymatch("END",key))  {

        /* End of keyworded input */
        RC = 111;

      }
	  else if (ccp4_keymatch("MODE",key))  {
	    if (token[1].isstring) strtoupper(mode, token[1].word);
	  }
    }
  }

  if (RC==111)  RC = 0;  // normal return from the parser loop

  /* Clean up parser array */
  ccp4_parse_end ( parser );

  // ##### READ INPUT MODEL FILE #####
  // This is XREAD in mutate.f

  // 4.1 Set slack flags for reading 
  MMDBManager.SetFlag ( mmdb::MMDBF_IgnoreDuplSeqNum |
                        mmdb::MMDBF_IgnoreBlankLines |
                        mmdb::MMDBF_IgnoreRemarks    |
                        mmdb::MMDBF_IgnoreNonCoorPDBErrors |
                        mmdb::MMDBF_IgnoreSegID |
                        mmdb::MMDBF_IgnoreElement |
                        mmdb::MMDBF_IgnoreCharge);

  // 4.2 Read coordinate file by its logical name
  RC = MMDBManager.ReadCoorFile1 ( "XYZIN" );

  // 4.3 Check for possible errors:
  if (RC) {
    //  An error was encountered. MMDB provides an error messenger
    //  function for easy error message printing.
      printf ( " ***** ERROR #%i READ:\n\n %s\n\n",RC,mmdb::GetErrorDescription((mmdb::ERROR_CODE)RC) );
    //  Location of the error may be identified as precise as line
    //  number and the line itself (PDB only. Errors in mmCIF are
    //  located by category/item name. Errors of reading BINary files
    //  are not locatable and the files are not editable). This
    //  information is now retrieved from MMDB input buffer:
    MMDBManager.GetInputBuffer ( S,lcount );
    if (lcount>=0) 
      printf ( "       LINE #%i:\n%s\n\n",lcount,S );
    else if (lcount==-1)
      printf ( "       CIF ITEM: %s\n\n",S );
    //  now quit
    ccperror ( 1,"Error reading XYZIN." );
  } else  {
    //  MMDB allows to identify the type of file that has been just
    //  read:
    switch (MMDBManager.GetFileType())  {
      case mmdb::MMDB_FILE_PDB    : printf ( " PDB"         );  break;
      case mmdb::MMDB_FILE_CIF    : printf ( " mmCIF"       );  break;
      case mmdb::MMDB_FILE_Binary : printf ( " MMDB binary" );  break;
      default : printf ( " Unknown format (report as a bug!)" );
    }
    printf ( " file %s has been read in.\n",getenv("XYZIN") );
  }

  // ##### READ INPUT ALIGNMENT FILE #####

  // Read alignment file. These come in various formats.
  // To start with, let's assume a single chain in the model.
  // E.g. alignment of P06632 (trial model 1a80.pdb) to Q46857 (target)

  // target MANPTVIKLQDGNVMPQLGLGVWQASNEEVITAIQKALEVGYRSIDTAAAYKNEEGVGKA
  // 1a80_   TVPSIV-LNDGNSIPQLGYGVFKVPPADTQRAVEEALEVGYRHIDTAAIYGNEEGVGAA
  // 
  // target LKNASVNREELFITTKLWNDDH--KRPREALLDSLKKLQLDYIDLYLMHWPVPAIDHYVE
  // 1a80_  IAASGIARDDLFITTKLWNDRHDGDEPAAAIAESLAKLALDQVDLYLVHWPTPAADNYVH
  // 
  // target AWKGMIELQKEGLIKSIGVCNFQIHHLQRLIDETGVTPVINQIELHPLMQQRQLHAWNAT
  // 1a80_  AWEKMIELRAAGLTRSIGVSNHLVPHLERIVAATGVVPAVNQIELHPAYQQREITDWAAA 
  // 
  // target HKIQTESWSPLAQGGKGVFDQKVIRDLADKYGKTPAQIVIRWHLDSGLVVIPKSVTPSRI
  // 1a80_  HDVKIESWGPLGQGKYDLFGAEPVTAAAAAHGKTPAQAVLRWHLQKGFVVFPKSVRRERL 
  // 
  // target AENFDVWDFRLDKDELGEIAKLDQGK---RLGPDPDQFGG 
  // 1a80_  EENLDVFDFDLTDTEIAAIDAMDPGDGSGRVSAHPDEVD 

  // The alignment can then be translated into a character
  // array align[maxres], where the index is the residue
  // position in the trial model, and the value is the 1-letter
  // amino acid code (with X for gap). With this example, we get
  // (note the Xs for target gaps):

  // "ANPTVILQDGNVMPQLGLGVWQASNEEVITAIQKALEVGYRSIDTAAAYKNEEGVGKALKNASVNREELFITTKLWNDDHXXKRPREALLDSLKKLQLDYIDLYLMHWPVPAIDHYVEAWKGMIELQKEGLIKSIGVCNFQIHHLQRLIDETGVTPVINQIELHPLMQQRQLHAWNATHKIQTESWSPLAQGGKGVFDQKVIRDLADKYGKTPAQIVIRWHLDSGLVVIPKSVTPSRIAENFDVWDFRLDKDELGEIAKLDQGKXXXRLGPDPDQFG"
   
  FILE *filein;
  int i;
  int itarget=0;
  int imodel=0;
  int ialign;
  int ins;
  int nconserve;
  int nmutate;
  int ndelete;
  float seqid;
  mmdb::PResidue res;
  mmdb::PAtom Ghostatom;

  char *filename;
  char *extension;
  filename = getenv("ALIGNIN");
  printf(" Alignment file %s has been read in.\n", filename);

  if (!(filein = fopen(filename, "r")))
    ccperror(1, "Failed to open alignment file");
  
  extension = ccp4_utils_extension(filename);

  int filetype;

  if (!strncmp(extension,"aln",3)) {               // Clustal format
	  filetype=1;        
	  read_clustal(filein, model_seq, target_seq, filetype);
  }
  else if (!strncmp(extension,"msf",3)) {          // MSF format
	  filetype=2;   
	  read_clustal(filein, model_seq, target_seq, filetype);
  }
  else if (!strncmp(extension,"phy",3)) {          // Phylip format
	  read_phylip(filein, model_seq, target_seq);
  }
  else if (!strncmp(extension,"bla",3)) {          // Blast format
      read_blast(filein, model_seq, target_seq);
  }
  else if (!strncmp(extension,"pir",3)) {          // PIR format
	  read_pir(filein, model_seq, target_seq);
  }
  else if (!strncmp(extension,"oca",3)) {          // OCA format
	  read_oca(filein, model_seq, target_seq);
  }
  else if (!strncmp(extension,"fas",3)) {          // Fasta format
	  read_fasta(filein, model_seq, target_seq);
  }
  else {
	  ccperror(1,"Unrecognised file extension");
  }

  itarget = target_seq.size();
  imodel = model_seq.size();

  // some alignment files may use dots instead of dashes for gaps
  // could perhaps generalise to any non alphabetic character
  for (i=0; i<imodel; i++) {
	  if (model_seq[i] == '.') model_seq[i] = '-';
  }
  for (i=0; i<itarget; i++) {
	  if (target_seq[i] == '.') target_seq[i] = '-';
  }

  printf("\ntarget_seq =\n%s\n\nmodel_seq =\n%s\n\n",target_seq.c_str(),model_seq.c_str());
  printf("itarget = %d imodel = %d\n\n", itarget,imodel);
  if (itarget == 0 || imodel == 0) {
	  ccperror(1, "Failed to read sequences");
  }

  // print out target and model sequences using asterisks to indicate conserved residues
  print_alignment(model_seq, target_seq, itarget);

  // print out target sequence in pdb format
  print_target(target_seq, itarget);


  nblanks = 0;
  for (i=0; i<imodel; i++) {
	  if (model_seq[i] != '-') break;
	  nblanks++;
  }

  // ##### DO THE BUSINESS #####

  // Here, we cycle over models, chains and residues

  nmod = MMDBManager.GetNumberOfModels();
  printf("Number of models = %d.\n",nmod);

  // Delete waters
  MMDBManager.DeleteSolvent();
  MMDBManager.FinishStructEdit();

  // Select most probable conformation, using DeleteAltLocs. This does not reset the occupancy to 1
  // or remove the AltLoc, so do these at the end.
  // Could use SelectMostProbable from pdbcur, but this is slow.
  MMDBManager.DeleteAltLocs();
  MMDBManager.FinishStructEdit();



  for (imod=1;imod<=nmod;imod++) {
    nchain = MMDBManager.GetNumberOfChains(imod);
    printf("Number of chains in model %d = %d.\n",imod, nchain);


    for (ichain=0;ichain<nchain;ichain++) {

	  pdb_seq.erase();
	  align.erase();
      chain = MMDBManager.GetChain(imod,ichain);
      nres = chain->GetNumberOfResidues();
      printf("<!--SUMMARY_BEGIN-->\n");
      printf("Number of residues in chain %s = %d.\n",chain->GetChainID(), nres);

	  // exclude short chains - they are probably just hetatms
	  if (float(nres)/float(imodel) < 0.1) {
		  printf("*** Deleting chain %s because it is too short ***\n", chain->GetChainID());
		  MMDBManager.DeleteChain(imod,ichain);
		  continue;
	  }
 
        printf("<!--SUMMARY_END-->\n");
	  for (ires=0;ires<nres;ires++) {   
        residue = chain->GetResidue(ires);

        strncpy(model_res3name,residue->name,3);
        model_res3name[3] = '\0';
            mmdb::Get1LetterCode (model_res3name, &model_res1name);
		//printf("%c\n",model_res1name);
		pdb_seq += model_res1name;
		//printf("pdb_seq = \n%s\n",pdb_seq.c_str()); 

	  }

	  // remove hetams from end of pdb sequence
      int ix = 0;
	  ires = nres-1;
	  while (pdb_seq[ires] == 'X') {
		  ix++;
		  ires--;
	  }
	  if (ix > 0) {
	      pdb_seq.erase(nres-ix,ix);
	      printf("%d X deleted\n", ix);
	  }

	  if (ix == nres) {
	          printf("<!--SUMMARY_BEGIN-->\n");
		  printf("*** No residues left in chain %s ***\n\n", chain->GetChainID());
	          printf("<!--SUMMARY_END-->\n");
		  MMDBManager.DeleteChain(imod,ichain);
		  continue;
	  } 


      // check if model and pdb sequences are the same
	  // if so, no need to align them
	  bool sameseq = true;
	  int j = 0;
	  for (int i=0; i<model_seq.length(); i++) {
		  if (model_seq[i] == '-') {
			  //printf("ignoring -\n");
		  }
		  else if (j >= pdb_seq.length() ) {
			  //printf("length exceeded\n");
			  sameseq = false;
			  break;
		  }
		  else if(model_seq[i] != pdb_seq[j]) {
			  //printf("difference detected\n");
			  sameseq = false;
			  break;
		  }
		  else {
			  //printf("same char %c\n",model_seq[i]);
			  j++;
		  }
	  }

	  if (sameseq) {
		  printf("\npdb_seq is the same as model_seq\n\n");
		  pdb_seq = model_seq;
		  offset = 0;
	  }
	  else {
	      // align model sequence with pdb sequence
	      // offset is the number of extra blanks introduced at beginning of model sequence
	      printf("\nOriginal pdb_seq = \n%s\n\n",pdb_seq.c_str());
	      printf("\nmodel_seq = \n%s\n\n",model_seq.c_str());
	      basic_align(model_seq, pdb_seq, nblanks2);
	      printf("\nAligned pdb_seq = \n%s\n\n",pdb_seq.c_str());
	      offset = nblanks2 - nblanks;
	      //printf("offset = %d\n",offset);
	  }

	  ialign = 0;
	  nmutate = 0;
	  nconserve = 0;
	  ndelete = 0;
      
	  // create an alignment between target and pdb sequences
	  for (ins=0; ins<itarget; ins++) {  
	    if (pdb_seq[ins+offset] != '-' && target_seq[ins] == '-') {
		  align += 'X';
	    }
	    else if (pdb_seq[ins+offset] != '-') {
		  align += target_seq[ins];
	    }
      }
      //printf("\n%s\n",align.c_str());
	  int nalign = align.size();

	  // delete any surplus residues at start of chain
      for (ires=0; ires<offset; ires++) {
		  chain->DeleteResidue(ires);
	  }

      // delete/mutate/conserve subsequent residues
      for (ires=offset; ires<nalign+offset; ires++) {
        residue = chain->GetResidue(ires);

        strncpy(model_res3name,residue->name,3);
        model_res3name[3] = '\0';
            mmdb::Get1LetterCode (model_res3name, &model_res1name);

        target_res1name = align[ires-offset];

        if (model_res1name == target_res1name) {

          // residues the same - nothing to do
          printf("Residue %c at position %d conserved.\n",model_res1name,ires+1-offset);
		  nconserve++;

        } 
		else if (target_res1name == 'X') {

          // model residue doesn't exist in target, so delete
          printf("Deleting residue %c at position %d.\n",model_res1name,ires+1-offset);
          chain->DeleteResidue(ires);
		  ndelete++;

	    } 
		else if (model_res1name == 'X') {

		  // have found hetatm instead of Amino Acid, so mark for deletion
          //ccperror(2, "X found in pdb file");
		  printf("$TEXT:Warning: $$");
                  printf("$$\n");
		  printf("WARNING: X found in pdb file\n");
                  printf("$$\n");
		  residue->SetResName("GHO");
		  //chain->DeleteResidue(ires);
		  ndelete++;
		}
		else {

          // else need to mutate
          printf("Mutating residue %c at position %d to %c.\n",
                model_res1name,ires+1-offset,target_res1name);
		  if (!strncmp(mode,"MIXA",4)) {
			  do_mutate(residue,target_res1name,1);
		  }
		  else if (!strncmp(mode,"MAXI",4)) {
			  max_mutate(residue,target_res1name);
		  }
		  else {
              do_mutate(residue,target_res1name,0);
		  }
		  nmutate++;
	    }
      }
	  // delete any surplus residues at end of chain
      for (ires=nalign+offset; ires<nres; ires++) {
		  chain->DeleteResidue(ires);
	  }
	  // output statistics
          printf("<!--SUMMARY_BEGIN-->\n");
	  printf("\n%d deleted, %d conserved, %d mutated\n", ndelete,nconserve,nmutate);
	  if ( ndelete+nconserve+nmutate > 0 ) {
          seqid = float(nconserve)/float(ndelete+nconserve+nmutate);
          printf("Estimated sequence identity: %4.2f\n\n",seqid);
          printf("<!--SUMMARY_END-->\n");
	  }

	  nres = chain->GetNumberOfResidues();
	 
	  // Add in ghost residues. These come in two types: GRR if there is a gap in both target and pdb sequences and GHO
	  // if only the pdb sequence has a gap. Will later delete GRR's, renumber, delete GHO's. Would have thought can manage
	  // without GRR's but doing so seems to mess up the numbering.

	  for ( ires=offset; ires < std::min( pdb_seq.length(), target_seq.length()+offset ) ; ires++ ) {
		  if (pdb_seq[ires] == '-'){ 
                      res = new mmdb::Residue();
			  int testnres = chain->InsResidue(res,ires);
			  if (target_seq[ires-offset] != '-') {
        		  res->SetResID("GHO",ires,"Z");
			  }
			  else {
				  res->SetResID("GRR",ires,"Z");
			  }
                          Ghostatom = new mmdb::Atom();
	          int natoms = res->AddAtom(Ghostatom);
			  Ghostatom->SetAtomName(" CA");
		      Ghostatom->SetElementName("C");
			  Ghostatom->SetCoordinates(0.0, 0.0, 0.0, 0.0, 0.0);			  
		  }
	  }
    }
  }

  MMDBManager.FinishStructEdit();

  // Finish off alt locs

  mmdb::PAtom atomi, atomj;
  mmdb::realtype occupancy;
  int natoms;
  mmdb::realtype Bfactor;
  float x,y,z;

  for (imod=1;imod<=nmod;imod++) {
    nchain = MMDBManager.GetNumberOfChains(imod);
    for (ichain=0;ichain<nchain;ichain++) {
      chain = MMDBManager.GetChain(imod,ichain);
      nres = chain->GetNumberOfResidues();
      for (ires=0;ires<nres;ires++) {
		  residue = chain->GetResidue(ires);
		  natoms = residue->GetNumberOfAtoms();
          for (i=0;i<natoms;i++) {
			  atomi = residue->GetAtom(i);
			  occupancy = atomi->GetOccupancy();
			  if (occupancy < 0.999) {
				  strcpy(atomi->altLoc,"");
				  atomi->occupancy = 1.0;
			  }
			  // some residues may have been HETATMs before mutation (e.g. MSE). Need to convert to ATOMs
			  // do this by deleting original atom and adding new one 
			  if (atomi->Het) {
				  char namestring[5], elementstring[3];
                                  mmdb::pstr name = atomi->GetAtomName();
                  mmdb::pstr element = atomi->GetElementName();
				  //printf("NAME: %s\n",name);
				  strncpy(namestring, name, 4);
				  strncpy(elementstring, element, 2);
				  // need to null terminate before can use as arguments to SetAtomName etc
				  namestring[4] = '\0';
				  elementstring[2] = '\0';
			      x = atomi->x;
	              y = atomi->y;
	              z = atomi->z;
	              Bfactor = atomi->tempFactor;
	              residue->DeleteAtom(i);
                      atomj = new mmdb::Atom();
	              residue->AddAtom(atomj);
				  atomj->SetAtomName(namestring);
				  atomj->SetElementName(elementstring);
				  atomj->SetCoordinates(x, y, z, 1.0, Bfactor);
			  }
		  }
	  }
	}
  }
		  


  // Delete ghost residues of type GRR
  for (imod=1;imod<=nmod;imod++) {
    nchain = MMDBManager.GetNumberOfChains(imod);
    for (ichain=0;ichain<nchain;ichain++) {
      chain = MMDBManager.GetChain(imod,ichain);
      nres = chain->GetNumberOfResidues();
      for (ires=0;ires<nres;ires++) {
		  residue = chain->GetResidue(ires);
		  if (!strncmp(residue->GetResName(),"GRR",3)) { 
		      chain->DeleteResidue(ires);
		  }
	  }
	}
  }

  // This tidies up internal tables
  
  MMDBManager.FinishStructEdit();
  MMDBManager.PDBCleanup ( mmdb::PDBCLEAN_INDEX );
  MMDBManager.PDBCleanup ( mmdb::PDBCLEAN_SERIAL );
  MMDBManager.PDBCleanup ( mmdb::PDBCLEAN_SEQNUM );

// Delete ghost residues of type GHO, leaving gaps in the numbering
  for (imod=1;imod<=nmod;imod++) {
    nchain = MMDBManager.GetNumberOfChains(imod);
    for (ichain=0;ichain<nchain;ichain++) {
      chain = MMDBManager.GetChain(imod,ichain);
      nres = chain->GetNumberOfResidues();
      for (ires=0;ires<nres;ires++) {
		  residue = chain->GetResidue(ires);
		  if (!strncmp(residue->GetResName(),"GHO",3)) { 
		      chain->DeleteResidue(ires);
		  }
	  }
	}
  }

  // ##### WRITE OUTPUT MODEL FILE #####

  MMDBManager.FinishStructEdit();

  // delete header from pdb file as it is not appropriate to the target
  MMDBManager.Delete ( mmdb::MMDBFCM_Top );
  MMDBManager.PutPDBString("REMARK 999 ");
  MMDBManager.PutPDBString("REMARK 999 This file was created by the CCP4 program chainsaw");
  MMDBManager.PutPDBString("REMARK 999 Any remaining header information should be ignored/deleted");
  MMDBManager.PutPDBString("REMARK 999 ");
  printf ( " ...writing PDB file %s\n",getenv("XYZOUT") );
  RC = MMDBManager.WritePDBASCII1 ( "XYZOUT" );

  ccperror ( 0,"Normal termination" );

  return 0;

}


// mutate a residue "residue" to a residue type specified by "target_type"

int do_mutate(mmdb::PResidue residue, char target_type, int mode) {

// mode = 0 means truncate to gamma atom
// mode = 1 means truncate to beta atom

  int i;
  char target_res3name[4];
  mmdb::pstr template_res3name;
  mmdb::PAtom CAatom, Catom, Natom, atomi;
  mmdb::PAtom CBatom;
  mmdb::PAtom Gatom;
  float b[3], c[3], aa[3], a[3];
  mmdb::realtype Bfactor;
  float x,y,z;
  mmdb::pstr name;
  char name2[5];
  int natoms;
  int imax;
  bool glycine = false;
  bool foundG = false;
  bool foundN = false;
  bool foundCA = false;
  bool foundC = false;

  template_res3name = residue->GetResName();
  natoms = residue->GetNumberOfAtoms();
  //printf("natoms = %d\n",natoms);

  if (!strcmp(template_res3name,"GLY")) {
	  //printf("GLYCINE IN TEMPLATE\n");
	  glycine = true;
	  for (i=0;i<natoms;i++) {
          atomi = residue->GetAtom(i);
		  name = atomi->GetAtomName();
		  if (!strcmp(name, " N  ")) {
			  Natom = residue->GetAtom(i);
			  //printf("found N\n");
			  foundN = true;
		  }
		  if (!strcmp(name, " CA ")) {
			  CAatom = residue->GetAtom(i);
			  //printf("found CA\n");
			  foundCA = true;
		  }
		  if (!strcmp(name, " C  ")) {
			  Catom = residue->GetAtom(i);
			  //printf("found C\n");
			  foundC = true;
		  }
		  if (!strcmp(name, " OT1")) atomi->SetAtomName(" O  ");
          // Model C terminal will not in general be target C terminal, so delete
		  if (!strcmp(name, " OXT") || !strcmp(name, " OT2") || atomi->Ter) residue->DeleteAtom(i);
	  }

	  if (foundN && foundCA && foundC) {
	      Bfactor= CAatom->tempFactor;

	      b[0] = Natom->x - CAatom->x;
	      b[1] = Natom->y - CAatom->y;
	      b[2] = Natom->z - CAatom->z;
	      c[0] = Catom->x - CAatom->x;
	      c[1] = Catom->y - CAatom->y;
	      c[2] = Catom->z - CAatom->z;
	      //printf ("b  %8.3f %8.3f %8.3f\n", b[0], b[1], b[2]);
	      //printf ("c  %8.3f %8.3f %8.3f\n", c[0], c[1], c[2]);

	      vnorm(b);
	      vnorm(c);
	      //printf ("b  %8.3f %8.3f %8.3f\n", b[0], b[1], b[2]);
	      //printf ("c  %8.3f %8.3f %8.3f\n", c[0], c[1], c[2]);
	      cross(b,c,aa);
	      //printf ("aa %8.3f %8.3f %8.3f\n", aa[0], aa[1], aa[2]);

	      // Choose the L solution (D solution has opposite sign on sqrt)
	      for (i=0; i<3; i++) {
		      a[i] = -0.5*(b[i] + c[i] - sqrt(3.0)*aa[i]);
		      a[i] *= 1.5;    // C-C bond length assumed to be 1.5 Angstroms
	      }
	      //printf ("a  %8.3f %8.3f %8.3f\n", a[0], a[1], a[2]);
	      a[0] += CAatom->x;
	      a[1] += CAatom->y;
	      a[2] += CAatom->z;

              CBatom = new mmdb::Atom();
	      natoms = residue->AddAtom(CBatom);
	      //printf("Added CB atom. natoms = %d\n",natoms);

	      CBatom->SetAtomName(" CB");
	      CBatom->SetElementName("C");
	      CBatom->SetCoordinates(a[0], a[1], a[2], 1.0, Bfactor);
	  }
  }


  // rename residue
  for (i=0;i<mmdb::nResNames;i++) {
    if (target_type == mmdb::ResidueName1[i]) {
      strncpy(target_res3name,mmdb::ResidueName[i],3);
      target_res3name[3] = '\0';
      break;
    }
  }
  residue->SetResName(target_res3name);

  // remove excess atoms
  // THIS IS THE IMPORTANT BIT

  if (glycine) return(0);

  bool deleteB = false;
  bool deleteG = false;

  if (target_type == 'G') {
	  deleteB = true;
	  deleteG = true;
  }
  if (target_type == 'A') {
	  deleteG = true;
  }
  if (mode == 1) {
	  deleteG = true;
  }
  //natoms = residue->GetNumberOfAtoms();
  imax = natoms;
  for (i=0;i<imax;i++) {
      atomi = residue->GetAtom(i);
	  name = atomi->GetAtomName();
	  strcpy(name2,name);
	  // MMDB doesn't like atom name OT1 from Moleman2 - fudge by renaming
	  if (!strcmp(name, " OT1")) atomi->SetAtomName(" O  ");
	  //printf("atom %c%c%c%c\n",*name,*(name+1),*(name+2),*(name+3));
	  //printf("excess atoms\n");
	  //printf("%d %s\n",strlen(name), name);
	  if (strcmp(name, " N  ") && strcmp(name, " CA ") && strcmp(name, " C  ") && strcmp(name, " O  ")  &&
		  (strcmp(name, " CB ") || deleteB == true) && (strcmp(name, " SG ") || deleteG == true) &&
		  (strncmp(name, " OG", 3) || deleteG == true) && (strncmp(name, " CG", 3) || deleteG == true) ) {

	      natoms -= residue->DeleteAtom(i);
		  //printf("deleting atom\n");
	  }
	  if (!strcmp(name2, " CB ")) deleteB = true;
	  if (!strcmp(name2, " SG ") || !strncmp(name2, " OG", 3) || !strncmp(name2, " CG", 3)) deleteG = true;
  }
  residue->TrimAtomTable();
  
  // Set Gamma atom to be the correct type
  // Deleting and adding back in ensures any conformation label is removed

  if (target_type != 'A' && target_type != 'G' && mode == 0) {
      for (i=0;i<natoms;i++) {	
          atomi = residue->GetAtom(i);
	      name = atomi->GetAtomName();
	      if (!strcmp(name, " SG ") || !strncmp(name, " OG", 3) || !strncmp(name, " CG", 3)) {
		      //printf("found gamma atom\n");
		      foundG = true;
     	      Gatom = residue->GetAtom(i);
    	      x = Gatom->x;
	          y = Gatom->y;
	          z = Gatom->z;
	          Bfactor = Gatom->tempFactor;
	          residue->DeleteAtom(i);
                  Gatom = new mmdb::Atom();
	          residue->AddAtom(Gatom);

              if (target_type == 'C') {
		          Gatom->SetAtomName(" SG");
  	              Gatom->SetElementName("S");
	          }
	          else if (target_type == 'S') {
		          Gatom->SetAtomName(" OG");
		          Gatom->SetElementName("O");
	          }
	          else if (target_type == 'T') {
		          Gatom->SetAtomName(" OG1");
		          Gatom->SetElementName("O");
	          }
	          else if (target_type == 'I' || target_type == 'V') {
		          Gatom->SetAtomName(" CG1");
		          Gatom->SetElementName("C");
	          }
	          else {
		          Gatom->SetAtomName(" CG");
		          Gatom->SetElementName("C");
	          }
	          Gatom->SetCoordinates(x, y, z, 1.0, Bfactor);
		      break;
          }
      }
  }

  // correct torsions
  // This is less important, but might be useful
  // Not done at present

  return 0;
}


int max_mutate(mmdb::PResidue residue, char target_type) {

  int i,j;
  char target_res3name[4];
  mmdb::pstr template_res3name;
  mmdb::PAtom CAatom, Catom, Natom, atomi;
  mmdb::PAtom CBatom;
  float b[3], c[3], aa[3], a[3];
  mmdb::realtype Bfactor;
  mmdb::pstr name;
  int natoms;
  int itarget = 0;
  int imodel = 0;
  bool glycine = false;
  bool foundG = false;
  bool foundN = false;
  bool foundCA = false;
  bool foundC = false;

  template_res3name = residue->GetResName();
  natoms = residue->GetNumberOfAtoms();
  //printf("natoms = %d\n",natoms);

  for (i=0;i<mmdb::nResNames;i++) {
    if (target_type == mmdb::ResidueName1[i]) {
      strncpy(target_res3name,mmdb::ResidueName[i],3);
      target_res3name[3] = '\0';
	  itarget = i;
      break;
    }
  }

  for (i=0;i<mmdb::nResNames;i++) {
    if (!strcmp(template_res3name, mmdb::ResidueName[i])) {
	  imodel = i;
      break;
    }
  }
  //printf("itarget = %d, imodel = %d\n",itarget,imodel);

  if (!strcmp(template_res3name,"GLY")) {
	  //printf("GLYCINE IN TEMPLATE\n");
	  glycine = true;
	  for (i=0;i<natoms;i++) {
          atomi = residue->GetAtom(i);
		  name = atomi->GetAtomName();
		  if (!strcmp(name, " N  ")) {
			  Natom = residue->GetAtom(i);
			  foundN = true;
		  }
		  if (!strcmp(name, " CA ")) {
			  CAatom = residue->GetAtom(i);
			  foundCA = true;
		  }
		  if (!strcmp(name, " C  ")) {
			  Catom = residue->GetAtom(i);
			  foundC = true;
		  }
		  if (!strcmp(name, " OT1")) atomi->SetAtomName(" O  ");
		  if (!strcmp(name, " OXT") || !strcmp(name, " OT2") || atomi->Ter) residue->DeleteAtom(i);
	  }

	  if (foundN && foundCA && foundC) {
	      Bfactor= CAatom->tempFactor;

	      b[0] = Natom->x - CAatom->x;
	      b[1] = Natom->y - CAatom->y;
	      b[2] = Natom->z - CAatom->z;
	      c[0] = Catom->x - CAatom->x;
	      c[1] = Catom->y - CAatom->y;
	      c[2] = Catom->z - CAatom->z;

	      vnorm(b);
	      vnorm(c);
	      cross(b,c,aa);

	      // Choose the L solution (D solution has opposite sign on sqrt)
	      for (i=0; i<3; i++) {
		      a[i] = -0.5*(b[i] + c[i] - sqrt(3.0)*aa[i]);
		      a[i] *= 1.5;    // C-C bond length assumed to be 1.5 Angstroms
	      }
	      a[0] += CAatom->x;
	      a[1] += CAatom->y;
	      a[2] += CAatom->z;

              CBatom = new mmdb::Atom();
	      natoms = residue->AddAtom(CBatom);
	      //printf("Added CB atom. natoms = %d\n",natoms);

	      CBatom->SetAtomName(" CB");
	      CBatom->SetElementName("C");
	      CBatom->SetCoordinates(a[0], a[1], a[2], 1.0, Bfactor);
	  }
  }

  // remove excess atoms
  // THIS IS THE IMPORTANT BIT

  if (glycine) {
	  residue->SetResName(target_res3name);
	  return(0);
  }

  for (i=0;i<natoms;i++) {
      atomi = residue->GetAtom(i);
	  name = atomi->GetAtomName();
	  if (strcmp(name, " N  ") && strcmp(name, " CA ") && strcmp(name, " C  ") && strcmp(name, " O  "))  {
          bool retain = false;
	      for (j=0;j<7;j++) {
			  //printf("%d %s %s %s\n", j,name,RR[itarget][0][j], RR[itarget][imodel+1][j]);
		      if (!strcmp(name,RR[itarget][imodel+1][j]) && strcmp(RR[itarget][0][j],"    ")) {
			      //printf("Renaming %s to %s\n",name,RR[itarget][0][j]);
			      atomi->SetAtomName(RR[itarget][0][j]);
				  if (!strncmp(RR[itarget][0][j], " O",2)) {
					  atomi->SetElementName("O");
				  }
				  else if (!strncmp(RR[itarget][0][j], " N",2)) {
					  atomi->SetElementName("N");
				  }
				  else if (!strncmp(RR[itarget][0][j], " S",2)) {
					  atomi->SetElementName("S");
				  }
				  else {
                      atomi->SetElementName("C");
				  }
			      retain = true;
			      break;
		      }
	      }
		  if (!strcmp(name, " OT1")) atomi->SetAtomName(" O  ");
	      if (!retain) residue->DeleteAtom(i);
	  }
  }
  
  // rename residue

  residue->SetResName(target_res3name);

  // correct torsions
  // This is less important, but might be useful
  // Not done at present

  return 0;
}

void print_alignment(std::string &model_seq, std::string &target_seq, int itarget)
{
  // print out alignment using asterisks to indicate conserved residues
  int i,j,jstart,jfinish,deltaj;
  jstart = 0;
  jfinish = 60;   // 60 residues per line
  deltaj = 0;
  if (itarget<60) jfinish = itarget;
  int nlines = itarget/60;
  if (itarget%60 != 0) nlines++;
  for(i=1;i<=nlines;i++) {
	  printf("Target");
	  for(j=jstart;j<jfinish;j++) {
		  if (j%10 == 0) printf(" ");
		  printf("%c", target_seq[j]);
	  }
	  if (i==nlines) {
		  for (j=0;j<deltaj;j++) {
			  printf(" ");
		  }
	  }
	  printf("%6d\n      ",jfinish);
	  for(j=jstart;j<jfinish;j++) {
		  if (j%10 == 0) printf(" ");
		  if (target_seq[j] == model_seq[j]) printf("*");
		  else printf(" ");
	  }
	  printf("\nModel ");
	  for(j=jstart;j<jfinish;j++) {
          if(j%10 == 0) printf(" ");
		  printf("%c", model_seq[j]);
	  }
	  printf("\n\n");
	  jstart += 60;
	  jfinish += 60;
	  if (jfinish > itarget) {
		  deltaj = jfinish - itarget;
		  // add on a bit to account for spaces every ten residues
		  deltaj += deltaj/10;
		  jfinish = itarget;
	  }
  }
}


void print_target(std::string &target_seq, int itarget)
{
  // print target sequence in pdb format
  int i,n;
  int linenum=0;
  char name[4];
  int target_length;
  int resnumber = 0;
  target_length = itarget;

  // calculate sequence length by subtracting number of dashes from itarget
  for (n=0;n<itarget;n++) {
	  if (target_seq[n] == '-') target_length--;
  }

  printf("\nTarget sequence in pdb format:\n");
  for (n=0;n<itarget;n++) {
    // need to skip over the dashes
	if (target_seq[n] != '-') {
    // 13 residues per line 
	if (resnumber%13 == 0) printf("\nSEQRES%4d A %4d ",++linenum,target_length);
      for (i=0;i<mmdb::nResNames;i++) {
        if (target_seq[n] == mmdb::ResidueName1[i]) {
          strncpy(name,mmdb::ResidueName[i],3);
          name[3] = '\0';
		  printf(" %s",name);
		  resnumber++;
          break;
        }
	  }
	}
  }
  printf("\n\n");
}


void read_clustal(FILE *filein, std::string &model_seq, std::string &target_seq, int filetype)
{
  char str[201];
  char seqfrag[201];
  int length;
  int iseqend;
  int iseqbeg;
  char c;
  int i,j;
  int target=1;
  int header=0;

  while (!feof(filein)) {
	  iseqend = 0;
	  iseqbeg = -1;  // position of first space in string; initialise to -1 as there may not be one
	  if (fgets(str,200,filein) == NULL) break;  // assume eof not detected
      length = strlen(str);
	  if (header == 0 && length > 1 && filetype == 1) {
		  for (i=0; i<length-7; i++) {
			  if (!strncmp(str+i,"CLUSTAL",7)) {
				  printf("CLUSTAL HEADER FOUND\n\n");
				  header = 1;
				  break;
			  }
		  }
	  }
	  else if (header == 0 && length > 1 && filetype == 2) {
		  for (i=0; i<length-2; i++) {
			  if (!strncmp(str+i,"//",2)) {
				  printf("MSF HEADER FOUND\n\n");
				  header = 1;
				  break;
			  }
		  }
	  }
	  else if(length >1) {

          for (i=length-1; i>=0; i--) {
			  if (filetype == 2 && (str[i] == '.' || str[i] == '~')) str[i] = '-';
		      c = str[i];
		      if (c == '-' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
			      iseqend = i;
			      break;
		      }
	      }
	      for (i=iseqend-1; i>=0; i--) {
			  if (filetype == 2 && (str[i] == '.' || str[i] == '~')) str[i] = '-';
		      c = str[i];
		      if (c == ' ') {
			      iseqbeg = i;
		      }
	      }
	      //printf("%d %d %d\n",length,iseqbeg,iseqend);
	      if (iseqend > 0 ) {
			  j = 0;
			  for (i=iseqbeg+1; i<=iseqend; i++) {
			      if (str[i] != ' ') seqfrag[j++] = str[i];
			  }
			  seqfrag[j] = '\0';
			      
			  if (target == 1) {
				  target_seq += seqfrag;
				  //printf("Add to target %s\n",seqfrag);
				  target = 0;
			  }
			  else {
				  model_seq += seqfrag;
				  //printf("Add to model  %s\n",seqfrag);
				  target = 1;
			  }
	      }
      }
  }
}


void read_phylip(FILE *filein, std::string &model_seq, std::string &target_seq)
{
  char str[201];
  char seqfrag[201];
  int length;
  int iseqend;
  int iseqbeg;
  char c;
  int i, j, ilast, nblocks;
  int target = 1;
  int nlines = 0;

  while (!feof(filein)) {
	  iseqend = 0;
	  iseqbeg = -1;  // position of first space in string; initialise to -1 as there may not be one
	  if (fgets(str,200,filein) == NULL) break;  // assume eof not detected
      length = strlen(str);
	  nblocks = 0;
	  
	  if (length > 1) {

          for (i=length-1; i>=0; i--) {
		      c = str[i];
		      if (c == '-' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
			      iseqend = i;
			      break;
		      }
	      }
		  // phylip output from clustalw may contain header lines of numbers. ignore these
		  if (iseqend > 0) nlines++;
		  if (nlines < 3) {
	          for (i=iseqend-1; i>=0; i--) {
		          c = str[i];
		          if (c == ' ') {
				      ilast = iseqbeg;
			          iseqbeg = i;
				      nblocks++;
					  //printf("*** %d %d %d\n", nblocks, ilast, iseqbeg);
					  // phylip sequence name may contain a space. check if we've found one.
					  // sequence data forms 1 block or else several blocks of 10 chars each
				      if (nblocks > 1 && ilast-iseqbeg != 11) {
					      iseqbeg = ilast;
					      break;
				      }	
		          }
	          }
		  }
	      //printf("%d %d %d\n",length,iseqbeg,iseqend);
		  if (iseqend > 0 ) {
			  j = 0;
			  for (i=iseqbeg+1; i<=iseqend; i++) {
			      if (str[i] != ' ') seqfrag[j++] = str[i];
			  }
			  seqfrag[j] = '\0';
			  if (target == 1) {
				  target_seq += seqfrag;
				  //printf("Add to target %s\n",seqfrag);
				  target = 0;
			  }
			  else {
				  model_seq += seqfrag;
				  //printf("Add to model  %s\n",seqfrag);
				  target = 1;
			  }
	      }
      }
  }
}

void read_blast(FILE *filein, std::string &model_seq, std::string &target_seq)
{
  char str[201];
  char seqfrag[201];
  int length;
  int iseqend;
  int iseqbeg;
  char c;
  int i;
  int nscore=0;

  while (!feof(filein)) {
	  iseqend = 0;
	  iseqbeg = 0;
	  if (fgets(str,200,filein) == NULL) break;  // assume eof not detected
      length = strlen(str);

	  for (i=0; i<length-7; i++) {
          if (!strncmp(str+i,"Score",5)) {
			  nscore++;
			  break;
		  }
	  }


	  if(length > 1 && nscore < 2) {

          for (i=length-1; i>=0; i--) {
		      c = str[i];
		      if (c == '-' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
			      iseqend = i;
			      break;
		      }
	      }
	      for (i=iseqend-1; i>=0; i--) {
		      c = str[i];
		      if (c == ' ') {
			      iseqbeg = i;
			      break;
		      }
	      }
	      //printf("%d %d %d\n",length,iseqbeg,iseqend);
	      if (iseqend > 0 ) {
		      strncpy(seqfrag, str+iseqbeg+1, iseqend-iseqbeg);
		      seqfrag[iseqend-iseqbeg] = '\0';
	          //printf("%s\n",seqfrag);
			  if (!strncmp(str,"Query",5)) {
				  target_seq += seqfrag;
			  }
			  else if (!strncmp(str,"Sbjct",5)) {
				  model_seq += seqfrag;
			  }
	      }
      }
  }
  if (nscore > 0) {
      printf("$TEXT:Warning: $$ $$");
	  printf("\n\nWARNING: Alignment file contains multiple fragments.\n"); 
	  printf("Chainsaw has ignored all except the first.\n\n");
          printf("$$\n");
  } 

}

void read_pir(FILE *filein, std::string &model_seq, std::string &target_seq) 
{
  int linenumber=0;
  int counting=0;
  int numberpasses=1;
  char c;
  int nummodel=0;
  int numtarget=0;

  while (!feof(filein)) {
      c = fgetc(filein);
	  if (c == '>') counting = 1;
	  if (c == '\n' && counting) linenumber++;
	  if (c == '*') {
		  linenumber = 0;
		  counting = 0;
		  numberpasses++;
	  }
	  if (linenumber>=2 && c != ' ' && c != '\n' && c != '\r') {
		  if (numberpasses == 1) {
			  target_seq += toupper(c);
			  numtarget++;
		  }
		  else if (numberpasses == 2) {
			  model_seq += toupper(c);
			  nummodel++;
		  }
		  else {
			  ccperror(1, "Too many sequences");
		  }
	  }
  }
  if (numtarget != nummodel) ccperror(1, "Aligned sequences are not of same length");
}

void read_fasta(FILE *filein, std::string &model_seq, std::string &target_seq) 
{
  int linenumber=0;
  int counting=0;
  int numberpasses=0;
  char c;
  int nummodel=0;
  int numtarget=0;

  while (!feof(filein)) {
      c = fgetc(filein);
	  if (c == '>') {
		  counting = 1;
		  linenumber = 0;
		  numberpasses++;
	  }
	  if (c == '\n' && counting) linenumber++;

	  if ( linenumber>=1 && (c == '-' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ) ) {
		  if (numberpasses == 1) {
			  target_seq += toupper(c);
			  numtarget++;
		  }
		  else if (numberpasses == 2) {
			  model_seq += toupper(c);
			  nummodel++;
		  }
		  else {
			  ccperror(1, "Too many sequences");
		  }
	  }
  }
  if (numtarget != nummodel) ccperror(1, "Aligned sequences are not of same length");
}

void read_oca(FILE *filein, std::string &model_seq, std::string &target_seq) 
{
  char str[201];
  char seqfrag[201];
  int length;
  int iseqend, iseqend2;
  int iseqbeg, iseqbeg2;
  char c;
  int i;
  while (!feof(filein)) {
	iseqend = 0;
	iseqbeg = -1;  // position of first space in string; initialise to -1 as there may not be one
	if (fgets(str,200,filein)==NULL) break;
    length = strlen(str);
	  
	if (!strncmp(str,"SEARCH",6) || !strncmp(str,"Seqenc",6)) {

        for (i=length-1; i>=0; i--) {
		    c = str[i];
		    if (c == '-' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
			    iseqend = i;
			    break;
		    }
	    }
	    for (i=iseqend-1; i>=0; i--) {
		    c = str[i];
		    if (c == ' ') {
			    iseqbeg = i;
			    break;
		    }
	    }
	    //printf("%d %d %d\n",length,iseqbeg,iseqend);
	    if (iseqend > 0 ) {
		    strncpy(seqfrag, str+iseqbeg+1, iseqend-iseqbeg);
		    seqfrag[iseqend-iseqbeg] = '\0';
			target_seq += seqfrag;
		    //printf("Add to target %s\n",seqfrag);
		}

        seqfrag[0] = '\0';
		if (fgets(str,200,filein) != NULL && fgets(str,200,filein) != NULL) {
			length = strlen(str);
			//printf("length = %d\n%s\n",length,str);
            for (i=length-1; i>=0; i--) {
		        c = str[i];
		        if (c == '-' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) {
			        iseqend2 = i;
			        break;
		        }
	        }
	        for (i=iseqend2-1; i>=0; i--) {
		        c = str[i];
				//printf("%c",c);
		        if (c == ' ') {
			        iseqbeg2 = i;
			        break;
		        }
	        }
			//printf("beg %d end %d\n",iseqbeg2,iseqend2);
			if (iseqend2 == iseqend && iseqbeg2 < iseqbeg) {
				strncpy(seqfrag, str+iseqbeg+1, iseqend-iseqbeg);
			}
			else if (iseqend2 == iseqend) {
				for (i=iseqbeg; i<iseqbeg2; i++) {
					strcat(seqfrag,"-");
				}
				strncat(seqfrag, str+iseqbeg2+1, iseqend2-iseqbeg2);
			}
			else if (iseqend2 > iseqend) {
                strncpy(seqfrag, str+iseqbeg+1, iseqend-iseqbeg);
			}
			else {
				//printf("string is:\n",str);
				//printf("\n%d %d\n",iseqend2-iseqbeg2,iseqend-iseqend2);
				strncat(seqfrag, str+iseqbeg2+1, iseqend2-iseqbeg2);
				for (i=iseqend2-iseqbeg2; i<iseqend-iseqbeg2; i++) {
					strcat(seqfrag,"-");
				}
			}
			seqfrag[iseqend-iseqbeg] = '\0';
			model_seq += seqfrag;
		    //printf("Add to model  %s\n",seqfrag);
		}
		else {
            for (i=iseqbeg; i<iseqend; i++) {
				model_seq += "-";
			}
		}
	}
  }
}

/*
Simple global sequence alignment algorithm from pseudocode in Eidhammer, Jonassen and Taylor, 
Protein Bioinformatics (Wiley, 2004). Storage required is order N**2. Could reduce to order N 
by using Hirschberg's divide and conquer strategy.
*/

void basic_align(std::string &model_seq, std::string &pdb_seq, int &nblanks)
{
	int i,j,k,m,n;
	int g = 1;       // gap penalty
	int R;           // score
	char res1,res2;
	int **h;         // dynamic programming matrix
	int mingaps = 9999;

	m = model_seq.size();
	n = pdb_seq.size();

	char *B0 = new char[m+n];   // aligned model sequence  
	char *B1 = new char[m+n];   // aligned pdb sequence
	std::string bestB0;
	std::string bestB1;

	h = matrix<int>(m+1, n+1);

// h is nominally an m x n matrix, but row and column 0 used for initialisation
// initial conditions chosen to give zero penalty for gaps at start of sequence

	for (i=0; i<=m; i++) {
		h[i][0] = 0;     
	}
	for (j=0; j<=n; j++) {
		h[0][j] = 0;
	}
	for (i=1; i<=m; i++) {
		for (j=1; j<=n; j++) {
			res1 = model_seq[i-1];
			res2 = pdb_seq[j-1];
			if (res1 == res2) {
				R = 2;          // score 2 if residues match, otherwise 0
			}
			else {
				R = 0;
			}
			h[i][j] = std::max( h[i-1][j] - g, h[i][j-1] - g );
			h[i][j] = std::max( h[i][j], h[i-1][j-1] + R );
		}
	}
// backtrack is called recursively
	k = 0;
	backtrack(m, n, k, g, model_seq, pdb_seq, B0, B1, h, mingaps, bestB0, bestB1);
	
    revstring(bestB0);
	revstring(bestB1);
	pdb_seq = bestB1;
	//printf("pdb_seq = \n%s\n",pdb_seq);

    nblanks = 0;
    for (i=0; i<bestB0.size(); i++) {
	    if (bestB0[i] != '-') break;
	    nblanks++;
    }

	delete [] B0;
	delete [] B1;
	free_matrix(h, m+1, n+1);
	return;
}

void backtrack(int i, int j, int k, int g, std::string &model_seq, std::string &pdb_seq, char *B0, char *B1, int **h, 
			   int &mingaps, std::string &bestB0, std::string &bestB1)
{
	// backtrack through matrix h to find alignments giving highest score
	// if there is more than one, choose the one giving fewest gaps in B1
	int R;
	char res1,res2;
	int ngaps;

	if (i == 0) {
		while (j > 0) {
			B0[k] = '-';
			B1[k] = pdb_seq[j-1];
			k++;
			j--;
		}		
		countgaps(k, B0, B1, ngaps);
		if (ngaps <= mingaps) {
			mingaps = ngaps;
			// B0 and B1 are not null terminated. Doing so would mess up subsequent calls to backtrack.
			// However must remember to "null terminate" bestB0 and bestB1 by restricting them to k characters
			bestB0 = B0;
			bestB1 = B1;
			bestB0.erase(k);
			bestB1.erase(k);
		}
		//printf("ngaps = %d  mingaps = %d\n", ngaps,mingaps);
	}
	else if (j == 0) {
		while (i > 0) {
			B0[k] = model_seq[i-1];
			B1[k] = '-';
			k++;
		    i--;
		}
		countgaps(k, B0, B1, ngaps);
		if (ngaps <= mingaps) {
			mingaps = ngaps;
			bestB0 = B0;
			bestB1 = B1;
		    bestB0.erase(k);
			bestB1.erase(k);
		}
		//printf("ngaps = %d  mingaps = %d\n", ngaps,mingaps);
	}
	else {
		if (h[i][j] == h[i-1][j] - g) {
			B0[k] = model_seq[i-1];
			B1[k] = '-';
			backtrack(i-1, j, k+1, g, model_seq, pdb_seq, B0, B1, h, mingaps, bestB0, bestB1);
		}
		if (h[i][j] == h[i][j-1] - g) {
			B0[k] = '-';
			B1[k] = pdb_seq[j-1];
			backtrack(i, j-1, k+1, g, model_seq, pdb_seq, B0, B1, h, mingaps, bestB0, bestB1);
		}

		res1 = model_seq[i-1];
		res2 = pdb_seq[j-1];
		if (res1 == res2) {
			R = 2;              // score 2 if residues match, otherwise 0
		}
		else {
			R = 0;
		}

		if (h[i][j] == h[i-1][j-1] + R) {
			B0[k] = model_seq[i-1];
			B1[k] = pdb_seq[j-1];
			backtrack(i-1, j-1, k+1, g, model_seq, pdb_seq, B0, B1, h, mingaps, bestB0, bestB1);
		}
		else {
			//printf("fell through %d %d %d %d\n", h[i][j], h[i-1][j], h[i][j-1], h[i-1][j-1]);
		}
	}
}

void countgaps(int k, char *B0, char *B1, int &ngaps)
{
	// B0 and B1 store the sequences in reverse order
	// Cannot reverse them here as they may be needed for next call to backtrack
	int l;
	static int nsolns = 0;
	//printf("nsolns = %d\n",++nsolns);
	if (++nsolns > 4000) ccperror ( 1,"Chainsaw is having trouble reconciling input pdb with sequence.\n Check target sequence comes before model sequence in your alignment file.\n" );
	/*printf("B0 =\n");
	for (l=0; l<k; l++) {
		printf("%c", B0[k-l-1]);
	}
	printf("\n\n");
	printf("B1 =\n");
	for (l=0; l<k; l++) {
		printf("%c", B1[k-l-1]);
	}
	printf("\n");*/

	ngaps = 0;
	if (B1[0] == '-') ngaps++;
	for(l=1;l<k;l++) {
		if (B1[l] == '-' && B1[l-1] != '-') {
			ngaps++;
		}
	}
}

void revstring(std::string &str)
{
	// Reverse a string (like Windows strrev)
	std::string temp = str;
	int len = str.size();
	for (int i=0;i<len;i++) {
		str[i] = temp[len-1-i];
	}
}

void vnorm(float v[3])
{
	int i;
	float rnorm = vecabs(v);
	if (rnorm != 0.0 ) {
		for (i=0; i<3; i++) { v[i] /= rnorm; }
		return;
	}
	else {
		ccperror(1,"Attempt to normalise vector of zero length\nExecution suppressed");
	}
}

void cross(float u[3], float v[3], float w[3])
{
    w[0] = u[1]*v[2] - u[2]*v[1];
	w[1] = u[2]*v[0] - u[0]*v[2];
	w[2] = u[0]*v[1] - u[1]*v[0];
}

void transpose(float a[3][3], float at[3][3])
{
   int i,j;
   for (i=0; i<3; i++) {
	  for (j=0; j<3; j++) {
		 at[i][j] = a[j][i];
	  }
   }
}

void matmult(float rmat1[3][3], float rmat[3][3], float prod[3][3])
{
   int i,j,k;
   for (i=0; i<3; i++) {
	  for (j=0; j<3; j++) {
         prod[i][j] = 0.0;
		 for (k=0; k<3; k++) {
			prod[i][j] += rmat1[i][k] * rmat[k][j];
		 }
	  }
   }
}

void transform(float rmat[3][3], float xold[3], float t[3], float xnew[3])
{
   int i,j;
   for (i=0; i<3; i++) {
   xnew[i] = t[i];
	  for (j=0; j<3; j++) {
         xnew[i] += rmat[i][j] * xold[j];
	  }
   }
}

float dot(float u[3], float v[3])
{
	int i;
	float result = 0.0;
	for (i=0; i<3; i++) {
		result += u[i] * v[i];
	}
	return(result);
}

float vecabs(float v[3])
{
	return(sqrt(dot(v,v)));
}
