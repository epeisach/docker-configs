//
//  =================================================================
//
//    05.03.10   <--  Date of Last Modification.
//                   ~~~~~~~~~~~~~~~~~~~~~~~~~~~~
//  -----------------------------------------------------------------
//
//  **** Module  :  csm_structure  <interface>
//       ~~~~~~~~~
//  **** Project :  Chemical Structure Matching (CSM)
//       ~~~~~~~~~
//  **** Classes :  CSMStructure  - chemical structure
//       ~~~~~~~~~
//
//  (C) E. Krissinel 2010
//
//  =================================================================
//


#ifndef CSM_STRUCTURE_H
#define CSM_STRUCTURE_H

#ifndef  __MMDB_Manager__
#include "mmdb2/mmdb_manager.h"
#endif

#ifndef  __MMDB_Graph__
#include "mmdb2/mmdb_math_graph.h"
#endif


#define  CSM_Ok                    0
#define  CSM_noStructure       10000
#define  CSM_noAtomsSelected   10001
#define  CSM_cantMakeGraph     10002

DefineClass(CSMStructure)

class CSMStructure  {

  public:
    CSMStructure();
    ~CSMStructure();

    int   loadStructure     ( mmdb::cpstr fileName  );
    int   construct2DGraph  ( mmdb::cpstr selection );
    void  removeHydrogens   ();
    void  makeSymmetryRelief();
    void  build2DGraph      ( bool bondOrder );

    mmdb::cpstr  getFileName() { return fname; }
    int          getNofAtoms();
    mmdb::math::PGraph get2DGraph() { return G2; }

  protected:
    mmdb::PManager     M;   // molecule
    mmdb::math::PGraph G2;  // 2D (chemical) graph
    mmdb::pstr         fname;
    mmdb::pstr         sel;

    void Init      ();
    void FreeMemory();

};

#endif // CSM_STRUCTURE_H
