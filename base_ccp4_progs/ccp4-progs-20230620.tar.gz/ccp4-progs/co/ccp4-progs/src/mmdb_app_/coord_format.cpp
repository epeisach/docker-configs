//
//     COORD_FORMAT fix PDB format and convert to/from other formats
//     Copyright (C) 2003 Eugene Krissinel
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//
// =========================================================================

#include <string.h>
#include <stdlib.h>

#include "mmdb2/mmdb_manager.h"
#include "ccp4/ccp4_parser.h"
#include "ccp4/ccp4_general.h"
#include "ccp4/ccp4_program.h"

using namespace CCP4;

int FixBlankChainIDs(mmdb::Manager &MMDB) {

  // Attempt to fix those PDB entries with blank chain IDs.
  // This should only affect residues with chainID=' ' so it
  // should have zero effect on well-formed PDB files.

int selHnd,nSelResidues,selHnd2,nSelChains,i,ires;
int got_new_chain=0;
int debug=0;
char *chainIDs;
char new_chain_id;
char chain_sel[2];
mmdb::InsCode  insCode;
mmdb::PChain newChain,oldChain;
mmdb::PPChain selChain;
mmdb::PPResidue selResidue;

  // select all chains
  selHnd = MMDB.NewSelection();
  MMDB.Select      ( selHnd,mmdb::STYPE_CHAIN,"*",mmdb::SKEY_OR );
  MMDB.GetSelIndex ( selHnd,selChain,nSelChains );

  // get list of all chain IDs
  // if chainIDs are greater than 1 char, then chains beginning
  // with the same char are conflated - I don't think this matters
  // for the current purpose
  if (nSelChains>0)  {
    chainIDs = new char[nSelChains+1];
    for (i=0;i<nSelChains;i++) {
      chainIDs[i] = selChain[i]->GetChainID()[0];
      if (chainIDs[i] == char(0)) chainIDs[i] = ' ';
    }
    chainIDs[nSelChains] = char(0);
  } else {
    MMDB.DeleteSelection ( selHnd );
    return 0;
  }

  if (debug) printf(" nSelChains = %d\n",nSelChains);
  if (debug) printf(" chainIDs = %s\n",chainIDs);

  // return if no blank chain IDs
  if (!mmdb::FirstOccurence(chainIDs,' ')) {
    delete[] chainIDs;
    MMDB.DeleteSelection ( selHnd );
    return 0;
  }

  printf("\n Found blank chain ID. Fixing ... \n\n");

  // get first unused chainID
  new_chain_id = 'A';
  while (mmdb::FirstOccurence(chainIDs,new_chain_id)) new_chain_id = char(int(new_chain_id)+1);

  printf(" Creating new chain ID %c \n",new_chain_id);

  chain_sel[0] = new_chain_id;
  chain_sel[1] = '\0';

  // set blank chain ID to new_chain_id for all residues
  for (i=0;i<nSelChains;i++) {
    if (selChain[i]->GetChainID()[0] == ' ' || selChain[i]->GetChainID()[0] == char(0)) {
      if (debug) printf(" renaming chain %d %s \n",i,selChain[i]->GetChainID());
      selChain[i]->SetChainID(chain_sel);
    }
  }

  // select all residues with new_chain_id chain ID.
  selHnd2 = MMDB.NewSelection();
  MMDB.Select      ( selHnd2,mmdb::STYPE_RESIDUE,chain_sel,mmdb::SKEY_NEW );
  MMDB.GetSelIndex ( selHnd2,selResidue,nSelResidues   );
  if (debug) printf(" selected %d residues in new chain %s \n",nSelResidues,chain_sel);

  // loop over all residues in chain
  // if seqnum goes down, or a seqnum/inscode pair is repeated, then
  // create a new chain and assign subsequent residues to that
  if (nSelResidues>0)  {
    ires = selResidue[0]->seqNum;
    strcpy ( insCode, selResidue[0]->insCode);
    oldChain = selResidue[0]->GetChain();
    for (i=1;i<nSelResidues;i++) {
      if (debug) printf(" checking residue %d %s %s \n",selResidue[i]->seqNum,selResidue[i]->name,selResidue[i]->GetChainID());
      if (selResidue[i]->seqNum < ires ||
          (selResidue[i]->seqNum == ires && !strcmp(selResidue[i]->insCode,insCode))) {
        printf(" Detected new chain. \n");
        new_chain_id = char(int(new_chain_id)+1);
        while (mmdb::FirstOccurence(chainIDs,new_chain_id)) new_chain_id = char(int(new_chain_id)+1);
        printf(" Setting new chain ID %c \n",new_chain_id);

        chain_sel[0] = new_chain_id;
        chain_sel[1] = '\0';
        newChain = selResidue[i]->GetModel()->CreateChain(chain_sel);
        got_new_chain=1;
      }
      ires = selResidue[i]->seqNum;
      strcpy ( insCode, selResidue[i]->insCode);      
      if (got_new_chain) {
        if (debug) printf(" Moving residue from chain %c to chain %c \n",
                           oldChain->GetChainID()[0],newChain->GetChainID()[0]);
        newChain->AddResidue(selResidue[i]);
        delete selResidue[i];
        oldChain->TrimResidueTable ();
      }
    }
  }
  delete[] chainIDs;
  MMDB.DeleteSelection ( selHnd );
// We can't delete selHnd2 because we have removed some residues
// from the selection. 
// Old comment: Replacing "DeleteResidue" by "delete selResidue[i]"
// as in atom-level example in Eugene's doc doesn't seem to work either.
// Update: Now it seems OK. 
//  MMDB.DeleteSelection ( selHnd2 );
  MMDB.FinishStructEdit();
  return 0;
}

int main ( int argc, char ** argv, char ** env )  {
mmdb::Manager  MMDBManager;
int            kout,RC,lcount;
int            fix_blank_chain_ids=0;
char           S[500];

// input parser parameters
int           ntok=0;
char          line[201],*key;
CCP4PARSERTOKEN * token=NULL;
CCP4PARSERARRAY * parser;

  //  1.  General CCP4 initializations
  ccp4fyp         ( argc,argv );
  ccp4ProgramName ( "COORD_FORMAT"   );
  ccp4_banner();

  //  2.  Make routine initializations, which must always be done
  //      before working with MMDB
  mmdb::InitMatType();
  kout = mmdb::MMDB_FILE_PDB;

  // 3. Keyworded input

  /* Initialise a parser array used by cparser
     This is used to return the tokens and associated info
     Set maximum number of tokens per line to 20 */
  parser = (CCP4PARSERARRAY *) ccp4_parse_start(20);

  if (parser == NULL) ccperror ( 1,"Couldn't create parser array" );
  
  /* Set some convenient pointers to members of the parser array */
  key   = parser->keyword;
  token = parser->token;

  /* Read lines from stdin until END/end keyword is entered or
     EOF is reached */
  RC   = 0;

  while (!RC) {

    /* Always blank the line before calling cparser
       to force reading from stdin */
    line[0] = '\0';

    /* Call cparser to read input line and break into tokens
       Returns the number of tokens, or zero for eof */
    ntok = ccp4_parser(line,200,parser,1);

    if (ntok < 1) {

      /* End of file encountered */
      RC = 111;

    } else {      

      /* Keyword interpretation starts here */
      if (ccp4_keymatch("END",key))  {

        /* End of keyworded input */
        RC = 111;

      } else if (ccp4_keymatch("OUTPUT",key))  {
	if (ntok >= 2) {
          if (!strncmp(mmdb::UpperCase(token[1].fullstring),"PDB",3)) kout = mmdb::MMDB_FILE_PDB;
          if (!strncmp(mmdb::UpperCase(token[1].fullstring),"CIF",3)) kout = mmdb::MMDB_FILE_CIF;
          if (!strncmp(mmdb::UpperCase(token[1].fullstring),"BIN",3)) kout = mmdb::MMDB_FILE_Binary;
	}

      } else if (ccp4_keymatch("FIXBLANK",key))  {
        fix_blank_chain_ids=1;
      }
    }
  }

  if (RC==111)  RC = 0;  // normal return from the parser loop

  /* Clean up parser array */
  ccp4_parse_end ( parser );

  // Read input file

  // 4.1 Set slack flags for reading
  MMDBManager.SetFlag ( mmdb::MMDBF_IgnoreDuplSeqNum |
                        mmdb::MMDBF_IgnoreBlankLines |
                        mmdb::MMDBF_IgnoreRemarks    |
                        mmdb::MMDBF_IgnoreHash    |
                        mmdb::MMDBF_IgnoreNonCoorPDBErrors |
                        mmdb::MMDBF_IgnoreSegID |
                        mmdb::MMDBF_IgnoreElement |
                        mmdb::MMDBF_IgnoreCharge);

  // 4.2 Read coordinate file by its logical name
  RC = MMDBManager.ReadCoorFile1 ( "XYZIN" );

  // 4.3 Check for possible errors:
  if (RC) {
    //  An error was encountered. MMDB provides an error messenger
    //  function for easy error message printing.
    printf ( " ***** ERROR #%i READ:\n\n %s\n\n",RC,
             mmdb::GetErrorDescription((mmdb::ERROR_CODE)RC) );
    //  Location of the error may be identified as precise as line
    //  number and the line itself (PDB only. Errors in mmCIF are
    //  located by category/item name. Errors of reading BINary files
    //  are not locatable and the files are not editable). This
    //  information is now retrieved from MMDB input buffer:
    MMDBManager.GetInputBuffer ( S,lcount );
    if (lcount>=0) 
      printf ( "       LINE #%i:\n%s\n\n",lcount,S );
    else if (lcount==-1)
      printf ( "       CIF ITEM: %s\n\n",S );
    //  now quit
    ccperror ( 1,"Error reading XYZIN." );
  } else  {
    //  MMDB allows to identify the type of file that has been just
    //  read:
    switch (MMDBManager.GetFileType())  {
      case mmdb::MMDB_FILE_PDB    : printf ( " PDB"         );  break;
      case mmdb::MMDB_FILE_CIF    : printf ( " mmCIF"       );  break;
      case mmdb::MMDB_FILE_Binary : printf ( " MMDB binary" );  break;
      default : printf ( " Unknown format (report as a bug!)" );
    }
    printf ( " file %s has been read in.\n",getenv("XYZIN") );
  }

  if (fix_blank_chain_ids) RC = FixBlankChainIDs(MMDBManager);

  //  5.  Now output the whole MMDB in the required format:
  switch (kout)  {
    default               :
    case mmdb::MMDB_FILE_PDB    :
        printf ( "\n ...writing PDB file %s\n",getenv("XYZOUT") );
        RC = MMDBManager.WritePDBASCII1 ( "XYZOUT" );
      break;
    case mmdb::MMDB_FILE_CIF    :
        printf ( "\n ...writing CIF file %s\n",getenv("XYZOUT") );
        RC = MMDBManager.WriteCIFASCII1 ( "XYZOUT" );
      break;
    case mmdb::MMDB_FILE_Binary :
        printf ( "\n ...writing MMDB binary file %s\n",getenv("XYZOUT") );
        RC = MMDBManager.WriteMMDBF1 ("XYZOUT"  );
  }

  ccperror ( 0,"Normal termination" );

  return 0;

}
