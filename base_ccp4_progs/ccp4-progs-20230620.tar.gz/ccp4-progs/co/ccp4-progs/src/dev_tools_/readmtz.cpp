//     READMTZ
//     Copyright (C) 2006 Norman Stein
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//

/* Simple program to help fix corrupted mtz files. I use it in conjunction with
using the editor in Microsoft Visual Studio as a viewer for mtz files. You may 
be able to use another editor instead. 

Of course if half the reflection data is missing, the program can't resurrect 
it. However it may help if the odd spurious extra byte has crept in, or only a
few reflections are missing. Output is sent to the ascii file output.txt. It 
can be converted back to mtz format using the f2mtz program.

Some numbers will need to be changed/experimented with. The number of 
columns (ncol) is listed in the mtz header data. To work out the number of 
relections (ndata), use the line numbers in the MVS editor. Remember to remove 
the trailing zero, then convert from hex to decimal e.g. by using the 
Calculator accessory in Windows.
*/

#include <stdio.h>
#include <math.h>

int main(int argc, char **argv)
{
   FILE *filein,*fileout;
   int i,j;
   char ch;
   int nstart, ncols, ndata;

   union u_type {
	   int i;
	   char c[4];
	   float f;
   } u;

// 16 bytes per line when viewed in MVS

   nstart = 5;    // number of lines at start
   //ndata = 50106;  // number of reflections  
   //ncols = 6;      // number of columns

   if (argc < 2) {
	   printf("Usage: readmtz <input mtz file>\n");
       return(0);
   }

   //filein = fopen("test2.mtz","rb");
   filein = fopen(argv[1],"rb");
   fileout = fopen("output.txt","w");
   printf("enter number of columns, number of reflections\n");
   scanf("%d %d",&ncols, &ndata);
   for (i=0; i<nstart*16; i++) {
	   ch = fgetc(filein);
	   if (ch >= 'a' && ch <= 'z') printf("%c",ch);
   }
   printf("\n");
   for (j=0;j<ndata;j++){
       for (i=0;i<ncols;i++) {
          fread(u.c,4,1,filein);
	       // code for byte swapping not required

	       /*temp = u.c[3];
	       u.c[3] = u.c[0];
	       u.c[0] = temp;
	       temp = u.c[1];
	       u.c[1] = u.c[2];
	       u.c[2] = temp;*/

	       // note everything stored as floats - including h,k,l
           fprintf(fileout,"%10.3f ",u.f);
       }
   // add a line number to assist in fault finding
   fprintf(fileout,"%8d\n",j);
   // alternatively, write without line number, for use as input to f2mtz
   //fprintf(fileout,"\n");
   }
   // check we used right number of lines
   for (i=0; i<16; i++) {
	   ch = fgetc(filein);
	   printf("%c",ch);
   }
   printf("\n");
}

