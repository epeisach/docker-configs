/*
     MAPDIFF
     Copyright (C) 2003 Peter Briggs

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
*/

/* mapdiff.c

   Examine differences between two CCP4 map files

   Usage:
   mapdiff  <file1> <file2>

   Author: Peter Briggs March 2003
*/

/* Headers */
#include <math.h>
#include <ccp4/cmaplib.h>

static char rcsid[] = "$Id$";

/* Main program */

int main(int argc, char **argv) {

  /* Declarations */
  CMMFile *file1=NULL,*file2=NULL;
  int i,order1[3],order2[3],grid1[3],grid2[3];
  int origin1[3],origin2[3],dim1[3],dim2[3];
  float d,rhmin1,rhmin2,rhmax1,rhmax2;
  float cell1[6],cell2[6],maxd_cell=0.0;
  double rhmean1,rhmean2,rhrms1,rhrms2;

  /* Check we have enough arguments */
  if (argc != 3) {
    puts("Usage: mapdiff <file1> <file2>");
    exit(1);
  }

  /* Identify the program */
  printf("mapdiff ($Revision$): starting\n");

  /* Open the maps for reading only */
  file1 = ccp4_cmap_open(argv[1],0);
  if (!file1) {
    printf("FATAL: failed to read file \"%s\"\n",argv[1]);
    exit(1);
  }
  file2 = ccp4_cmap_open(argv[2],0);
  if (!file1) {
    printf("FATAL: failed to read file \"%s\"\n",argv[2]);
    exit(1);
  }

  /* Check that the datatypes stored in the maps is the same */
  if (ccp4_cmap_get_datamode(file1) != ccp4_cmap_get_datamode(file2)) {
    printf("FATAL: datatypes are not the same!\n");
    ccp4_cmap_close(file1);
    ccp4_cmap_close(file2);
    exit(1);
  }

  /* Do comparisions of header info */

  /* Cell */
  printf("Cells...");
  ccp4_cmap_get_cell(file1,cell1);
  ccp4_cmap_get_cell(file2,cell2);
  for (i=0; i < 6; i++) {
    d = fabs(cell1[i]-cell2[i]);
    if (d > maxd_cell) maxd_cell = d;
  }
  if (maxd_cell > 0.0) {
    printf("maximum diff %f\n",maxd_cell);
  } else {
    printf("identical\n");
  }

  /* Axis ordering */
  printf("Axis ordering...");
  ccp4_cmap_get_order(file1,order1);
  ccp4_cmap_get_order(file2,order2);
  for (i=0; i < 3; i++) {
    if (order1[i] != order2[i]) {
      printf("FATAL: axis order differs\n");
      exit(1);
    }
  }
  printf("ok (%d %d %d)\n",order1[0],order1[1],order1[2]);

  /* Axis origins */
  printf("Axis origins...");
  ccp4_cmap_get_origin(file1,origin1);
  ccp4_cmap_get_origin(file2,origin2);
    for (i=0; i < 3; i++) {
    if (origin1[i] != origin2[i]) {
      printf("FATAL: axis origins differ\n");
      exit(1);
    }
  }
  printf("ok (%d %d %d)\n",origin1[0],origin1[1],origin1[2]);

  /* Axis dimensions */
  printf("Axis dimensions...");
  ccp4_cmap_get_dim(file1,dim1);
  ccp4_cmap_get_dim(file2,dim2);
    for (i=0; i < 3; i++) {
    if (dim1[i] != dim2[i]) {
      printf("FATAL: axis dimensions differ\n");
      exit(1);
    }
  }
  printf("ok (%d %d %d)\n",dim1[0],dim1[1],dim1[2]);
  
  /* Grid */
  printf("Grids...");
  ccp4_cmap_get_grid(file1,grid1);
  ccp4_cmap_get_grid(file2,grid2);
  for (i=0; i < 3; i++) {
    if (grid1[i] != grid2[i]) {
      printf("FATAL: grids differ\n");
      exit(1);
    }
  }
  printf("ok (%d %d %d)\n",grid1[0],grid1[1],grid1[2]);
  
  /* Spacegroup */
  printf("Spacegroups...");
  if (ccp4_cmap_get_spacegroup(file1) != ccp4_cmap_get_spacegroup(file2)) {
    printf("WARNING: spacegroups differ\n");
  } else {
    printf("ok (%d)\n",ccp4_cmap_get_spacegroup(file1));
  }

  /* Statistics */
  ccp4_cmap_get_mapstats(file1,&rhmin1,&rhmax1,&rhmean1,&rhrms1);
  ccp4_cmap_get_mapstats(file2,&rhmin2,&rhmax2,&rhmean2,&rhrms2);
  printf("Differences in statistics:\n");
  printf("Minimum: %f\n",fabs(rhmin1-rhmin2));
  printf("Maximum: %f\n",fabs(rhmax1-rhmax2));
  printf("Mean   : %f\n",fabs(rhmean1-rhmean2));
  printf("RMS    : %f\n",fabs(rhrms1-rhrms2));
  
  /* Close the files */
  ccp4_cmap_close(file1);
  ccp4_cmap_close(file2);
  puts("mapdiff finished.");
  exit(0);
}
