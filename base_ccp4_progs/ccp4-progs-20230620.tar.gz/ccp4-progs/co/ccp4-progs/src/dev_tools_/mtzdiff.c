/*
     MTZDIFF
     Copyright (C) 2003 Peter Briggs

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
*/

/* mtzdiff.c

   Examine differences between two MTZ files

   Usage:
   mtzdiff <file1> <file2>

   Author: Peter Briggs March 2003

   Based on umtzdiff by Kevin Cowtan
   Migrated to CMTZ and extended by Peter Briggs
*/

/* Some limits */
#define MAX_N_COLS 200

/* Headers */
#include <math.h>
#include <ccp4/cmtzlib.h>

static char rcsid[] = "$Id$";

/* Main program */

int main(int argc, char **argv) {

  /* Declarations */
  MTZ *file1=NULL, *file2=NULL;
  MTZCOL *col_list1[MAX_N_COLS], *col_list2[MAX_N_COLS], *col;
  MTZXTAL *xtal;
  MTZSET *set;

  int   ncol=0,wlabel=0;
  int   ii,i,j,k;
  char  *label,type[MAX_N_COLS+1];
  float fdata1[MAX_N_COLS],fdata2[MAX_N_COLS],max[MAX_N_COLS]={0.0},d;
  float tot[MAX_N_COLS]={0.0},tot2[MAX_N_COLS]={0.0};
  float mean[MAX_N_COLS]={0.0},sig[MAX_N_COLS]={0.0};
  int   n[MAX_N_COLS]={0};
  int   present1[MAX_N_COLS],present2[MAX_N_COLS];


  /* Check we have enough arguments */
  if (argc != 3) {
    puts("Usage: mtzdiff <file1> <file2>");
    exit(1);
  }

  /* Identify the program */
  printf("mtzdiff ($Revision$): starting\n");

  /* Open the files and read into memory */
  file1 = MtzGet(argv[1],1);
  if (!file1) {
    printf("FATAL: failed to read file \"%s\"\n",argv[1]);
    exit(1);
  }
  file2 = MtzGet(argv[2],1);
  if (!file2) {
    printf("FATAL: failed to read file \"%s\"\n",argv[2]);
    exit(1);
  }

  /* Check number of columns and reflections
     It is fatal if these differ */
  printf("Number of columns...");
  if (MtzNcol(file1) != MtzNcol(file2)) {
    printf("FATAL: numbers of columns differ\n");
    exit(1);
  } else {
    printf("ok. (%d)\n",MtzNcol(file1));
  }
  printf("Number of reflections...");
  if (MtzNref(file1) != MtzNref(file2)) {
    printf("FATAL: numbers of reflections differ\n");
    exit(1);
  } else {
    printf("ok. (%d)\n",MtzNref(file1));
  }

  /* Check consistency between spacegroup and number of datasets
     Warn if these are different */
  printf("Spacegroups...");
  if (MtzSpacegroupNumber(file1) != MtzSpacegroupNumber(file2)) {
    printf("WARNING: spacegroups differ\n");
  } else {
    printf("ok. (%d)\n",MtzSpacegroupNumber(file1));
  }
  printf("Number of datasets...");
  if (MtzNset(file1) != MtzNset(file2)) {
    printf("WARNING: numbers of datasets differ\n");
  } else {
    printf("ok. (%d)\n",MtzNset(file1));
  }

  /* Get arrays of pointers to matching columns in each file
     First get the columns in file 1 */
  ncol = MtzNcol(file1);
  if (ncol > MAX_N_COLS) {
    printf("FATAL: number of columns (%d) too many for mtzdiff\n",ncol);
    exit(1);
  }
  ii = 0;
  for (i = 0; i < MtzNxtal(file1); i++) {
    xtal = MtzIxtal(file1,i);
    for (j = 0; j < MtzNsetsInXtal(xtal);  j++) {
      set = MtzIsetInXtal(xtal,j);
      for (k = 0; k < MtzNcolsInSet(set); k++) {
	col_list1[ii] = MtzIcolInSet(set,k);
	ii++;
      }
    }
  }
  /* For each column get the label and find the pointer
     for the matching column in file 2 */
  printf("Column labels...");
  for (i = 0; i < ncol; i++) {
    label = col_list1[i]->label;
    col = MtzColLookup(file2,label);
    if (col == NULL) {
      printf("FATAL: column \"%s\" in file 1 has no equivalent in file 2\n",
	     label);
      exit(1);
    } else {
      col_list2[i] = col;
      if (strlen(label) > wlabel) wlabel = strlen(label);
    }
    /* Look up column types */
    type[i]=col_list1[i]->type[0];
    if (type[i] != col_list2[i]->type[0]) {
      printf("FATAL: type of column \"%s\" in file doesn't match that in file 2\n",
	     label);
      exit(1);
    }
  }
  type[ncol]='#';   /* mark end column */
  printf("ok.\n");

  /* Try and group a phase with another column */
#if defined UGH
  /* PJX there seems to be some problem with this later on?
     Ignore for now ... */
  printf("Grouping columns...");
  for (i = 0; i < ncol; i++) {
    if ( type[i] == 'P' ) {
      if      ( type[i+1] == 'W' ) { type[i] = 'p'; } /* phi,fom */
      else if ( type[i-1] == 'F' ) { type[i] = 'q'; } /* f, phi */
    }
  }
  printf("ok.\n");
#endif

  /* Read the file data and compare */
  printf("Comparing data in the two files...\n");
  for (i = 0; i < MtzNref(file1); i++) {
    /* mtzdiff suffers from the lack of an MtzGetRefln function */
    for (j = 0; j < ncol; j++) {
      fdata1[j] = col_list1[j]->ref[i];
      present1[j] = (!ccp4_ismnf(file1,fdata1[j]));
      fdata2[j] = col_list2[j]->ref[i];
      present2[j] = (!ccp4_ismnf(file2,fdata2[j]));
    }
    for (j = 0; j < ncol; j++) {
      if ( present1[j] && present2[j] ) {
        switch ( type[j] ) {
        case 'p': /* phi,fom */
	  d = sqrt( pow( fdata1[j+1] * cos( M_PI*fdata1[j]/180.0 ) -
			 fdata2[j+1] * cos( M_PI*fdata2[j]/180.0 ), 2 ) +
		    pow( fdata1[j+1] * sin( M_PI*fdata1[j]/180.0 ) -
			 fdata2[j+1] * sin( M_PI*fdata2[j]/180.0 ), 2 ) );
          break;
        case 'q': /* f, phi */
	  d = sqrt( pow( fdata1[j-1] * cos( M_PI*fdata1[j]/180.0 ) -
                         fdata2[j-1] * cos( M_PI*fdata2[j]/180.0 ), 2 ) +
                    pow( fdata1[j-1] * sin( M_PI*fdata1[j]/180.0 ) -
                         fdata2[j-1] * sin( M_PI*fdata2[j]/180.0 ), 2 ) );
          break;
        case 'P': /* any other phase */
	  d = fabs( sin ( M_PI * ( fdata1[j] - fdata2[j] ) / 90.0 ) );
          break;
        case 'A': /* HL coeff */
	  d = fabs( tanh( fdata1[j] ) - tanh( fdata2[j] ) );
          break;
        default:
	  d = fabs( fdata1[j] - fdata2[j] );
        }
	n[j]++;
	tot[j] += d;
	tot2[j] += d*d;
        if ( d > max[j] ) max[j] = d;
      } else if ( present1[j] ^ present2[j] ) {
        max[j] = 999.0;
      }
    }
  }
  printf("ok.\n");

  /* Calculate average differences */
  for (i = 0; i < ncol; i++) {
    if (n[i] > 0 ) {
      mean[i] = tot[i]/n[i];
      sig[i] = sqrt((tot2[i] - mean[i]*mean[i])/n[i]);
    }
  }

  /* Results */
  puts("Differences for each column:");
  puts("----------------------------");
  printf("%3s %*s %12s %12s %12s\n",
	 "Col",wlabel,"Label","Maximum","Mean","Sigma");
  for (i = 0; i < ncol; i++) {
    printf("%3d %*s %12f %12f %12f\n",
	   i,wlabel,col_list1[i]->label,max[i],mean[i],sig[i]);
  }

  /* Close the files */
  if (file1) MtzFree(file1);
  if (file2) MtzFree(file2);
  puts("mtzdiff finished.");
  exit(0);
}
