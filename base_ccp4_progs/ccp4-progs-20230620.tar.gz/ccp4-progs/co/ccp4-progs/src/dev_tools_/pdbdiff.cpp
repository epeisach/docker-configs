//
//     PDBDIFF
//     Copyright (C) 2003 Peter Briggs
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//
//
// =========================================================================
//
// pdbdiff.cpp
//
// Examine differences between two coordinate files
//
//   Usage:
//   pdbdiff <file1> <file2>
//
// Author: Peter Briggs March 2003
//
// =========================================================================
//

#include <cstdlib>
#include <cstring>
#include <iostream>
#include <math.h>
#include <string>

#include <mmdb2/mmdb_manager.h>

using namespace std;

static char rcsid[] = "$Id$";

int main(int argc, char ** argv) {

  // Declarations
  mmdb::Manager MMDB1,MMDB2;
  mmdb::PAtom   atom1,atom2;
  int           i,bad_chains=0,bad_residues=0;
  double        dx,dy,dz,maxdx=0,maxdy=0,maxdz=0;

  // Check we have sufficient arguments
  if (argc != 3) {
    cout << "Usage: pdbdiff <file1> <file2>" << endl;
    exit(1);
  }

  // Identify the program
  cout << "pdbdiff ($Revision$): starting" << endl;
  
  // Make routine initialisations, which must always be done
  //      before working with MMDB
  mmdb::InitMatType();

  // Read in the PDB coordinate files by name
  if (mmdb::isPDB(argv[1]) != 0) {
    cout << "FATAL: \"" << argv[1] << "\" is not a valid PDB file" << endl;
    exit(1);
  } else if (MMDB1.ReadCoorFile(argv[1])) {
    cout << "FATAL: error reading file \"" << argv[1] << "\"" << endl;
    exit(1);
  }

  if (mmdb::isPDB(argv[2]) != 0) {
    cout << "FATAL: \"" << argv[2] << "\" is not a valid PDB file" << endl;
    exit(1);
  } else if (MMDB2.ReadCoorFile(argv[2])) {
    cout << "FATAL: error reading file \"" << argv[2] << "\"" << endl;
    exit(1);
  }
  
  // Do comparisons of cell information
  cout << "Cryst info...";
  if (MMDB1.isCrystInfo() && MMDB2.isCrystInfo()) {
    cout << "present in both files." << endl;
    // Check if cell information is the same
    // Missing as the current version of MMDB does have GetCell
  } else if (MMDB1.isCrystInfo() ^ MMDB2.isCrystInfo()) {
    cout << "WARNING only in one file." << endl;
  } else {
    cout << "missing from both files." << endl;
  }

  // Spacegroup
  cout << "Spacegroup...";
  if (MMDB1.isSpaceGroup() && MMDB2.isSpaceGroup()) {
    cout << "present in both files...";
    // Check whether spacegroups match
    if (strcmp(MMDB1.GetSpaceGroup(),MMDB2.GetSpaceGroup()) != 0) {
      cout << "WARNING: different spacegroups" << endl;
    } else {
      cout << "ok. (" << MMDB1.GetSpaceGroup() << ")" << endl;
    }
  } else if (MMDB1.isSpaceGroup() ^ MMDB2.isSpaceGroup()) {
    cout << "WARNING only in one file." << endl;
  } else {
    cout << "missing from both files." << endl;
  }

  // Check that the number of atoms is consistent
  cout << "Number of atoms...";
  if (MMDB1.GetNumberOfAtoms() != MMDB2.GetNumberOfAtoms()) {
    cout << "FATAL: numbers of atoms differ" << endl;
    exit(1);
  } else {
    cout << "ok. (" << MMDB1.GetNumberOfAtoms() << ")" << endl;
  }

  // Check the coordinates

  // Loop over all atoms
  for (i = 1; i <= MMDB1.GetNumberOfAtoms(); i++) {
    atom1 = MMDB1.GetAtomI(i);
    if (!atom1) {
      cout << "FATAL: couldn't find atom " << i << " in file 1" << endl;
      exit(1);
    }
    atom2 = MMDB2.GetAtomI(i);
    if (!atom2) {
      cout << "FATAL: couldn't find atom " << i << " in file 2" << endl;
      exit(1);
    }
    // Compare the chain id and residue names
    if (strcmp(atom1->GetChainID(),atom2->GetChainID()) != 0) {
      bad_chains++;
      if (bad_chains <= 5) {
	cout << "WARNING: Mismatched chain id at position " << i << endl;
      } else if (bad_chains == 5) {
	cout << "WARNING: more than 5 mismatched chains, no more reported" << endl;
      }
    }
    if (strcmp(atom1->GetResName(),atom2->GetResName()) != 0) {
      bad_residues++;
      if (bad_residues <= 5) {
	cout << "WARNING: Mismatched residue name at position " << i << endl;
      } else if (bad_residues == 6) {
	cout << "WARNING: more than 5 mismatched residues, no more reported" << endl;
      }
    }
    // Get differences in coordinates
    dx = fabs(atom1->x - atom2->x);
    if (dx > maxdx) maxdx = dx;
    dy = fabs(atom1->y - atom2->y);
    if (dy > maxdy) maxdy = dy;
    dz = fabs(atom1->z - atom2->z);
    if (dz > maxdz) maxdz = dz;
  }
  // Coordinate differences
  cout << "Maximum coordinate differences (A) between equivalent atoms:" << endl;
  cout << "DX: " << maxdx << " DY: " << maxdy << " DZ: " << maxdz << endl;

  // Report mismatches
  if (bad_chains > 0 || bad_residues > 0) {
    cout << bad_chains << " mismatched chains, " << bad_residues <<
      " mismatched residues" << endl;
  }

  cout << "pdbdiff finished." << endl;
  exit(0);
}
