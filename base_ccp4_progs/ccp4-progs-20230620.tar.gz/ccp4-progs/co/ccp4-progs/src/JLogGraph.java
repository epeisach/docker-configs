import java.lang.*;
import java.awt.*;
import java.awt.event.*;
import java.applet.Applet;

//     JLogGraph.java
//     Copyright (C) 1998-2007 Kevin Cowtan
//
//     This code is distributed under the terms and conditions of the
//     CCP4 Program Suite Licence Agreement as a CCP4 Application.
//     A copy of the CCP4 licence can be obtained by writing to the
//     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
//
//  The Xloggraph syntax cannot be implemented quite right due
//  to loss of carriage returns in the input parameters.
//  But it'll do for a proof of concept. by Kevin Cowtan
//
// This program uses the Applet class of the java.applet package which 
// contains the methods (subroutines)  getParameter (returns specified 
// applet parameters as a string) and init (called by the browser to 
// initialize the applet, used here, apart from others. 

public class JLogGraph extends Applet implements ItemListener {
  JLogCanvas jlc; // jlc is the variable declared to be of type JLogCanvas
  TextArea jlt; // TextArea and Panel are awt components.
  Panel cards; // These are subclasses of the package java.awt.Component 
  String tabTitle;
  public String[] graphTitles; //declaring a string array 
  public String[] graphFmts;
  public String[] colTitles;
  public int linewidth = 1;
  public int[]    graphNCols; //declaring an integer array
  public int[][]  graphCols; 
  public float[][] data;
  public float[] graphXmins, graphXmaxs, graphYmins, graphYmaxs;
  public int ngraphs,ncols,nrows,ndata,currgr;
  boolean useList; // select between Choice and List widget for choosing graph
  Choice grChoice; //Awt component for drop down list
  List   grList;    //Awt component for scrollable selection lists
  String wordise; int wordiseoff;
  float nan = Float.valueOf("NaN").floatValue();

  public void init() {
    String[] delim={new String("$TAB"),new String("$GRA"),
                    new String("$$"),
		    new String("$$"),new String("$$"),new String("$$")},
		    token=new String[delim.length+1], subtok, subsub;
//
// delim is a string array containing the arrays specified within qoutes.
// token is a string array whose length is determined by that of delim. 
// subtok and subsub are also declared as string arrays.
//
    StringBuffer tabletext; String word; 
//
// The strings created in quotes
// or read into objects of the String class (like delim,token etc)
// cannot be altered. The StringBuffer class allows alteration of the string. 
// tabletext is declared to be an object of StringBuffer class.
//
// read the loggraph
    String table=getParameter("table");
    // START OF HORRID HACK TO COPE WITH BUGGY JAVA ON FEDORA
    char[] ctable = table.toCharArray();  // translate "\n" to newline
    for ( int i = 0; i < ctable.length-1; i++ )
        if ( ctable[i] == '\\' && ctable[i+1] == 'n' )
            ctable[i] = ctable[i+1] = '\n';
    table = new String( ctable );
    // END OF HORRID HACK TO COPE WITH BUGGY JAVA ON FEDORA
// and the GUI options 
    String listsizestr=getParameter("list");
    int listsize;
    if ( listsizestr != null ) {
      listsize = Integer.parseInt(listsizestr);
      useList = true;
    } else {
      listsize = 1;
      useList = false;
    }
    grList = new List(listsize);
    grChoice = new Choice();
//
// uses the getParameter method to read and store the 'value' of the parameter 
// named 'table' as a string. The 'value' in our log tables includes the table 
// titles, graph titles, graph data columns and the table data.
//
    if ( -1 != table.indexOf("$SCA") ) {
      delim[1] = new String("$SCA");
      linewidth = 0;
      System.out.println("scatter"); }
    for (int i=0; i<delim.length; i++) {
      token[i]=table.substring(0,table.indexOf(delim[i]));
      table=table.substring(table.indexOf(delim[i])+delim[i].length());
    }
//
// The substring method in the String class permits a range of specified 
// characters, of a string  to be copied into another string. You can either   
// specify a start character and a end character or just the start character
// in which case the rest of the string from the start character is copied.
// The indexOf method in the String class is used to find a specified character
// in a string. Here it is used to identify the characters specified by the 
// the elements of the delim string array. Once that is done, the string 
// 'table' is broken up into separate strings containing the table title, 
// graph titles, the column titles, and table data and stored as the array 
// elements of the string 'token'.
// 
    token[delim.length]=table; // Assigning the last element of the array
//
// read the table title
    subtok=tokenise(token[1],':');
//
// The tokenise method in the JLogGraph class, takes the string token[1] 
// breaks it up into a new string each time it encounters the delimiter
// ':' and returns a string array whose elements contain the new strings.
// 
    tabTitle=subtok[1]; // the second element of the string array subtok
//                         will contain the table title.
//
// read the grapth titles
    subtok=tokenise(token[2],':');
    ngraphs=(subtok.length-1)/4; 
// for each graph the delimiter ':' appears  4 times (see the log file)
//
    graphTitles=new String[ngraphs]; 
// instantiating the string object graphTitles whose size is ngraphs
//
    graphFmts  =new String[ngraphs];
    graphNCols =new int[ngraphs];
    graphCols =new int[ngraphs][];
    graphXmins =new float[ngraphs];
    graphXmaxs =new float[ngraphs];
    graphYmins =new float[ngraphs];
    graphYmaxs =new float[ngraphs];
//
// The following loop stores for each graph, the title, formats, the No. of 
// columns of data (in graphNCols), the column numbers of the data (in
// graphCols and adds the graph titles to the dropdown list
    int tok=1,ngraph=0;
    do {
      // extract graph info
      graphTitles[ngraph]=subtok[tok++].trim();
      graphFmts[ngraph]=subtok[tok++].trim();
      subsub=tokenise(subtok[tok++],',');
      graphNCols[ngraph]=subsub.length;
      graphCols[ngraph]=new int[graphNCols[ngraph]]; //instantiating graphCols
      for (int i=0;i<subsub.length;i++)
	graphCols[ngraph][i]=Integer.valueOf(subsub[i].trim()).intValue()-1;
      grList.add(graphTitles[ngraph]);
      grChoice.add(graphTitles[ngraph]);
      // decode graph format info
      graphXmins[ngraph] = graphXmaxs[ngraph] = nan;
      graphYmins[ngraph] = graphYmaxs[ngraph] = nan;
      if ( graphFmts[ngraph].equals("N") ) graphYmins[ngraph] = 0.0f;
      String[] tokf = tokenise(graphFmts[ngraph],'x');
      if ( tokf.length == 2 ) {
	  String[] tokfx = tokenise(tokf[0],'|');
	  String[] tokfy = tokenise(tokf[1],'|');
	  if ( tokfx.length == 2 && tokfy.length == 2 ) {
	      graphXmins[ngraph] = Float.valueOf(tokfx[0].trim()).floatValue();
	      graphXmaxs[ngraph] = Float.valueOf(tokfx[1].trim()).floatValue();
	      graphYmins[ngraph] = Float.valueOf(tokfy[0].trim()).floatValue();
	      graphYmaxs[ngraph] = Float.valueOf(tokfy[1].trim()).floatValue();
	  }
      }

      // next graph
      tok++; ngraph++;
    } while (tok<subtok.length);
//
    grList.add("View table"); //Adds the 'view table' item
    grChoice.add("View table");

// addItemListener to grChoice
    grList.addItemListener(this);
    grChoice.addItemListener(this);
//
// read the colum labels
    colTitles=wordise(token[3]); // token[3] contains the column titles
// wordise is a method in JLogGraph class that is similar to tokenise, one
// difference being, this does not have a separator passed as a parameter. The 
// separator is a blank space' '.
//
    ncols=colTitles.length-1;
//
// save the text label. Stores the column titles and contents of token[4]
// in the StringBuffer tabletext 
    tabletext=new StringBuffer(token[3]+"\n"+token[4]+"\n");
//
// get the data and count
    subtok=wordise(token[5]); // token[5] contains the table data. Since
// wordise takes ' ' as the separator, each data number has to be separated
// by a blank space.
    ndata=subtok.length-1;
    if (ndata%ncols!=0) System.out.println("Error: wrong number of data items");
//
    nrows=ndata/ncols;
// read the data
    data=new float[ncols][nrows];
    tok=0;
    for (int j=0;j<nrows;j++) {
      for (int i=0;i<ncols;i++) {
	word=subtok[tok++];
	tabletext.append(word); // appends each data number to tabletext
	try {
	  data[i][j]=Float.valueOf(word.trim()).floatValue();
// valueOf is a static method in available in datatype classes such as String
// Float etc. Being a static method it is called by referencing its class- in
// this case Float. The data numbers stored as strings are converted to 
// float value and sored in the 2 dimensional array data.
	} catch (NumberFormatException e) {
          data[i][j]=nan;
        }
// NumberFormatException is an object of the subclass RuntimeException-a 
// descendent of the base exception class Throwable. The catch statement 
// deals with the exception stated within brackets. 
// MDW: here we assign it to NaN and deal with it later. If the input
// file actually includes "NaN" then this is not treated as an exception.
      }
      tabletext.append("\n");
    }

// now make the panel
    jlt=new TextArea(tabletext.toString(),80,132);
//
// TextArea is a subclass the awt component TextComponent. Here jlt, (the
// name of the TextArea), is constructed using the specified rows and columns
// and the specified string. The string tabletext contains the column title
// and table data.
// 
    jlt.setEditable(false);
    jlt.setFont(new Font("Monospaced",Font.PLAIN,12));
//
    jlc=new JLogCanvas(this);
    jlc.setFont(new Font("SansSerif",Font.PLAIN,10));
//
// Panels and Canvases are classes in java.awt used for grouping components 
// which can be moved together in a window and are protected from overwriting 
// each other.
//
    cards=new Panel();cards.setLayout(new CardLayout());
//
// Creates an instance of Panel and stores a reference to it in the variable 
// cards. Then sets the layout of the new Panel object cards, to CardLayout
// which means that the components to be added using cards.add will be one
// on top of the other
//
    cards.add("canvas",jlc);
    cards.add("table",jlt);
//
    setLayout(new BorderLayout());
    add("Center",cards);
    if (useList) add("South",grList);
    else         add("South",grChoice);
// The layout for the applet is specified to be an object of the container
// BorderLayout, so that when a component is added, we specify which border 
// the component should stick to. In this case the panel cards should be in 
// center and grChoice which is the pull down list should be to the south.
  }
//
// METHOD (SUBROUTINE) TO SPLIT A 'SOURCE' STRING INTO SEPARATE STRINGS EACH
// TIME THE CHARACTER 'SEP' APPEARS IN THE SOURCE AND STORE THEM IN A STRING
// ARRAY 
// 
  String[] tokenise(String source, char sep) {
    int ntokens=0,i,j;
    for (i=0;i<source.length();i++)
      if (source.charAt(i)==sep) ntokens++;
    String[] tokens=new String[ntokens+1];
    ntokens=0; i=0;
    for (j=0;j<source.length();j++)
      if (source.charAt(j)==sep) {
	tokens[ntokens++]=source.substring(i,j);
	i=j+1;
      }
    tokens[ntokens]=source.substring(i);
    return tokens;
  }
//
// METHOD (SUBROUTINE) TO SPLIT A 'SOURCE' STRING INTO SEPARATE STRINGS EACH
// TIME A BLANK SPACE APPEARS IN THE SOURCE AND STORE THEM IN A STRING
//
  String[] wordise(String source) {
    int ntokens=0,i,j;
    for (j=1;j<source.length();j++)
      if ((source.charAt(j-1)!=' '&&source.charAt(j-1)!='\n')&&
	  (source.charAt(j)==' '||source.charAt(j)=='\n')) ntokens++;
    if (source.charAt(j-1)!=' '&&source.charAt(j-1)!='\n') ntokens++;
    String[] tokens=new String[ntokens+1];
    ntokens=i=0;
    for (j=1;j<source.length();j++)
      if ((source.charAt(j-1)!=' '&&source.charAt(j-1)!='\n')&&
	  (source.charAt(j)==' '||source.charAt(j)=='\n')) {
	tokens[ntokens++]=source.substring(i,j);
	i=j;
      }
    if (source.charAt(j-1)!=' '&&source.charAt(j-1)!='\n')
	tokens[ntokens++]=source.substring(i,j);
    return tokens;
  }
// ACTION EVENTS ARE GENERATED IN RESPONSE TO THE USER PERFORMING SOME ACTION
// WITH ONE OF THE USER INTERFACE COMPONENTS
  public void itemStateChanged (ItemEvent e) {
      if (useList) currgr=grList.getSelectedIndex();
      else         currgr=grChoice.getSelectedIndex();
      if (currgr==ngraphs) {
          ((CardLayout)cards.getLayout()).show(cards,"table");
      } else {
          ((CardLayout)cards.getLayout()).show(cards,"canvas");
          jlc.repaint();
      }
   }
}

class JLogCanvas extends Canvas implements MouseListener , MouseMotionListener{
    JLogGraph parent;
    private int last_x, last_y;
    private float zoom_xmin, zoom_xmax, zoom_ymin, zoom_ymax;
    private int invalid=-99999;
    private int last_gr=-1;
    private boolean zoom,dragging;

// constructor
    public JLogCanvas(JLogGraph parent) {
	this.parent=parent;
        addMouseListener(this);
        addMouseMotionListener(this);
    }
           
    public void mouseDragged(MouseEvent e) {
	last_x = e.getX(); last_y = e.getY();
        if (zoom) {
            this.repaint();
            return;
        }
        
	if (!dragging) {
	    zoom_xmin=e.getX(); zoom_ymin=e.getY();
	    dragging=true;
	}
        this.repaint();	   
    }

    public void mouseMoved(MouseEvent e) { }
    
    public void mouseReleased(MouseEvent e) {
	if (zoom) {
	    this.repaint();
            return;
	}
	if (dragging) {
	    zoom_xmax=e.getX(); zoom_ymax=e.getY();
	    dragging=false;
	    zoom=true;
	} 
	last_x = e.getX(); last_y = e.getY();	 
	this.repaint();	    
    }

    public void mousePressed(MouseEvent e)  { }

    public void mouseClicked(MouseEvent e)  {
        last_x = e.getX(); last_y = e.getY();
        if (e.getX()<10 && e.getY()<10) {
            zoom=false;
            dragging=false;
            this.repaint();
        }
    }

    public void mouseEntered(MouseEvent e) { }

    public void mouseExited(MouseEvent e) { }

    public void paint(Graphics g) {
	float xmin=99999,xmax=-99999,ymin=99999,ymax=-99999,x,y,tmp;
	int w=getSize().width,h=getSize().height,fw,fh,icount;
	int wx0=2*w/10,wx=w/2,wy0=8*h/10,wy=-7*h/10, bx=wx/20, by=wy/20;
	int[] lx=new int[parent.nrows],ly=new int[parent.nrows];
	Color[] cols={Color.red,Color.blue,Color.green,Color.black,Color.magenta,Color.pink,Color.cyan,Color.gray};
// font information
	FontMetrics fontMetrics = g.getFontMetrics();
// clipping rectangles
	Rectangle oldclipbounds = g.getClipBounds();
	Rectangle clipbounds = new Rectangle(wx0-bx,  wy0+wy+by,
					     wx+2*bx, -wy-2*by   );

	if (last_gr==-1)
	    last_gr=parent.currgr;

	if (last_gr!=parent.currgr) {
	    zoom=false;
	    last_gr=parent.currgr;
	}
// background
	g.setColor(Color.white);
	g.fillRect(0,0,w,h);
	g.setColor(Color.gray);
	g.draw3DRect(0,0,w-1,h-1,false);
// dragging rectangle
	g.setColor(Color.red);
	if (dragging)
	    g.draw3DRect((int)zoom_xmin,(int)zoom_ymin,
			 last_x-(int)zoom_xmin,last_y-(int)zoom_ymin,false);
// zoom reset
	if (zoom) {
	    g.fill3DRect(0,0,10,10,false);
	    fh=fontMetrics.getHeight();
	    g.drawString("Reset zoom",15,fh);
	}

	g.setColor(Color.black);

// get max and min x and y values
	for (int i=0; i<parent.nrows; i++) {
	    x=parent.data[parent.graphCols[parent.currgr][0]][i];
            if (!Float.isNaN(x)) {
	      xmin=Math.min(xmin,x); xmax=Math.max(xmax,x);
	      for (int j=1; j<parent.graphNCols[parent.currgr]; j++) {
		y=parent.data[parent.graphCols[parent.currgr][j]][i];
                if (!Float.isNaN(y)) {
	 	  ymin=Math.min(ymin,y); ymax=Math.max(ymax,y);
		}
	      }
	    }
	}
	if ( !Float.isNaN(parent.graphXmins[parent.currgr]) )
	    xmin = parent.graphXmins[parent.currgr];
	if ( !Float.isNaN(parent.graphXmaxs[parent.currgr]) )
	    xmax = parent.graphXmaxs[parent.currgr];
	if ( !Float.isNaN(parent.graphYmins[parent.currgr]) )
	    ymin = parent.graphYmins[parent.currgr];
	if ( !Float.isNaN(parent.graphYmaxs[parent.currgr]) )
	    ymax = parent.graphYmaxs[parent.currgr];
	if ( xmax <= xmin ) {
	    tmp = (float)( 1.0e-24 + 1.0e-6*0.5*Math.abs(xmin+xmax) );
	    x = xmax - tmp; y = xmin + tmp; xmin = x; xmax = y;
	}
	if ( ymax <= ymin ) {
	    tmp = (float)( 1.0e-24 + 1.0e-6*0.5*Math.abs(ymin+ymax) );
	    x = ymax - tmp; y = ymin + tmp; ymin = x; ymax = y;
	}

	// chose sensible axis ticks
	float[] xticks = ticks( xmin, xmax, 4 );
	xmin = Math.min(xmin,xticks[0]);
	xmax = Math.max(xmax,xticks[xticks.length-1]);
	float[] yticks = ticks( ymin, ymax, 4 );
	ymin = Math.min(ymin,yticks[0]);
	ymax = Math.max(ymax,yticks[yticks.length-1]);

// get new values of xmin, ymin, xmax, ymax for zoom
	if (zoom && zoom_xmin != zoom_xmax && zoom_ymin != zoom_ymax) {
	    float tmin,tmax;
	    float oxmin,oxmax,oymin,oymax;
// max and min of zoom area
	    tmin=Math.min(zoom_xmin,zoom_xmax);
	    tmax=Math.max(zoom_xmin,zoom_xmax);
	    zoom_xmin=tmin;
	    zoom_xmax=tmax;

	    tmin=Math.min(zoom_ymin,zoom_ymax);
	    tmax=Math.max(zoom_ymin,zoom_ymax);
	    zoom_ymin=tmin;
	    zoom_ymax=tmax;
// store old values
	    oymin=ymin;
	    oymax=ymax;
	    oxmin=xmin;
	    oxmax=xmax;
		
	    xmin=(float)((oxmax-oxmin)*(zoom_xmin-wx0)/wx+oxmin);
	    xmax=(float)((oxmax-oxmin)*(zoom_xmax-wx0)/wx+oxmin);

	    ymax=(float)((oymax-oymin)*(zoom_ymin-wy0)/wy+oymin);
	    ymin=(float)((oymax-oymin)*(zoom_ymax-wy0)/wy+oymin);
	} else {
	    zoom=false;
	}

	fh=fontMetrics.getHeight();

 	// Check for graphs against resolution
	boolean isresol = false;
	String xlabel = parent.colTitles[parent.graphCols[parent.currgr][0]];
	if ( xlabel.indexOf( "1/resol^2" ) >= 0 ||
	     xlabel.indexOf( "4SSQ/LL" )   >= 0 ) {
	    isresol = true;
	    xlabel = "Resolution/A";
	}

	g.setColor(Color.red);
	g.drawString("Mouse Position",wx0+wx+50,wy0-4*fh);
	    g.drawString("(click to update)",wx0+wx+50,wy0-3*fh);
	if(!zoom) {
	    g.drawString("(drag to zoom)",wx0+wx+50,wy0-2*fh);
        }
	g.setColor(Color.blue);
	// picked x value
	float xv = (float)((xmax-xmin)*(last_x-wx0)/wx+xmin);
	if (isresol) {
	    xv = (float)Math.sqrt(1.0/Math.max((double)xv,1.0e-4));
	    g.drawString("r = " + String.valueOf(xv), wx0+wx+50,wy0-fh);
	} else {
	    g.drawString("x = " + String.valueOf(xv), wx0+wx+50,wy0-fh);
	}
	g.drawString("y = " + String.valueOf((float)(ymax-ymin)*(last_y-wy0)/wy+ymin),
		     wx0+wx+50,wy0);
	g.setColor(Color.black);


	// draw axes
	g.drawLine(wx0,wy0-by,wx0+wx,wy0-by);
	g.drawLine(wx0-bx,wy0,wx0-bx,wy0+wy);

	// X labels
	for (int i=0; i<xticks.length; i++) {
	    x = xticks[i];
	    if ( isresol ) x = (float)Math.sqrt(1.0/Math.max(x,1.0e-4));
	    String sx = floatfmt(x,6);
	    if (isresol) sx = floatfmt(x,4);
	    int xt = wx0+(int)(wx*(xticks[i]-xmin)/(xmax-xmin));
	    g.drawLine(xt,wy0-by,xt,wy0-by*4/3);
	    g.drawString(sx,xt,wy0-by*4/3+fh);
	}

	// Y labels
	for (int i=0; i<yticks.length; i++) {
	    y = yticks[i];
	    String sy = floatfmt(y,8);
	    fw=fontMetrics.stringWidth(sy);
	    int yt = wy0+(int)(wy*(yticks[i]-ymin)/(ymax-ymin));
	    g.drawLine(wx0-bx,yt,wx0-bx*4/3,yt);
	    g.drawString(sy,wx0-bx*4/3-fw,yt+fh/3);
	}

	fw=fontMetrics.stringWidth(xlabel);
	g.drawString(xlabel, wx0+(wx-fw)/2,wy0-by*4/3+2*fh);

	for (int j=1; j<parent.graphNCols[parent.currgr]; j++) {
	    g.setColor(cols[(j-1)%8]);
	    g.drawString(parent.colTitles[parent.graphCols[parent.currgr][j]],
			 wx0+wx+fh,wy0+wy+j*fh);
	    // generate the plot coordinates lx and ly
	    // omit these if either is NaN
	    // any non-numeric data is converted to NaN on input
            icount=0;
	    for (int i=0; i<parent.nrows; i++) {
		x=parent.data[parent.graphCols[parent.currgr][0]][i];
		y=parent.data[parent.graphCols[parent.currgr][j]][i];
                if (!Float.isNaN(x) && !Float.isNaN(y)) {
	     	  lx[icount]=(int)(wx0+wx*(x-xmin)/(xmax-xmin));
		  ly[icount]=(int)(wy0+wy*(y-ymin)/(ymax-ymin));
		  icount++;
		}
	    }
	    g.setClip(clipbounds);
            // linewidth == 0 gives scatter plot, others line
            if (parent.linewidth == 0) {
               for (int i=0; i < icount; i++) {
                  g.fillOval(lx[i]-2,ly[i]-2,5,5);
               }
            } else {
                for (int i=1; i<icount; i++) {
                    g.fillOval(lx[i]-1,ly[i]-1,3,3);
                    g.drawLine(lx[i-1],ly[i-1],lx[i],ly[i]);
                }
            }
            g.setClip(oldclipbounds);
        }
    }

    public String floatfmt( float x, int s ) {
	String r = String.valueOf(x);
	if ( r.length() > s ) {
	    int i = r.indexOf(".");
	    if ( i >= 0 && i <= s )
		r = r.substring( 0, s );
	}
	return r;
    }

    public float[] ticks( float xmin, float xmax, int nmin ) {
	double steps[] = {1.0, 2.0, 5.0};
	float rng = xmax - xmin;
	float stp = rng / (float)(nmin-1);
	double scl = 1.0;
	for ( int i = -12; i <= 12; i++ )
	    if ( Math.pow(10.0,i) * steps[0] < stp )
		scl = Math.pow(10.0,i);
	double fnl = scl * steps[0];
	for ( int i = 1; i < steps.length; i++ )
	    if ( scl * steps[i] < stp )
		fnl = scl * steps[i];
	long i0 = Math.round(xmin/fnl);
	long i1 = Math.round(xmax/fnl);
	int n = (int)(i1 - i0 + 1);
	float[] result = new float[n];
	for ( int i = 0; i < n; i++ )
	    result[i] = (float)( (i0+i) * fnl );
	return result;
    }

    public Dimension getMinimumSize()   {return new Dimension(200,150);}
    public Dimension getPreferredSize() {return new Dimension(800,600);}
}
