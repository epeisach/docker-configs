/*
     TLSEXTRACT
     Copyright (C) 2004 Jay Painter

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
*/

/*
 * tlsextract.c : extracts TLS tensors from the REMARK statments in a PDB
 *                file and writes out a TLS description file suitable for
 *                processing in tlsanl
 */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "ccp4/ccp4_parser.h"
#include "ccp4/ccp4_general.h"
#include "ccp4/ccp4_program.h"

static char rcsid[] = "$Id$";

#define MAX_LINE 82

int main(int argc, char *argv[])
{
  char  *xyzin  = NULL;
  char  *tlsout = NULL;

  FILE  *xyzin_fil  = NULL;
  FILE  *tlsout_fil = NULL;

  char   in_buff[MAX_LINE];
  char   out_buff[MAX_LINE];

  char   t1[MAX_LINE];
  char   t2[MAX_LINE];
  char   t3[MAX_LINE];
  char   t4[MAX_LINE];

  float  O[3];
  float  T[6];
  float  L[6];
  float  S[9];

  char  *c;
  int    i;
  int    r;

  /*  1.  General CCP4 initializations */
  ccp4fyp         ( argc,argv );
  ccp4ProgramName ( "TLSEXTRACT"   );
  ccp4_banner();

  xyzin = getenv("XYZIN");
  if (!xyzin) ccperror(1,"XYZIN not assigned.");

  tlsout = getenv("TLSOUT");
  if (!tlsout) ccperror(1,"TLSOUT not assigned.");

  /* open input/output files */
  if ((xyzin_fil = fopen(xyzin, "r")) == NULL) {
    printf("Unable to open file: %s\n", xyzin);
    ccperror(1,"Unable to open XYZIN.");
  } else {
    printf("Opened input coordinate file: %s\n", xyzin);
  }

  if ((tlsout_fil = fopen(tlsout, "w")) == NULL) {
    printf("Unable to open file: %s\n", tlsout);
    ccperror(1,"Unable to open TLSOUT.");
  } else {
    printf("Opened output TLS file: %s\n\n", tlsout);
  }

  /* the REFMAC line in the output file indicates the order of the
   * TLS tesors is the order used by REFMAC, which is different than
   * the order used by RESTRAIN
   */
  fprintf(tlsout_fil, "REFMAC\n");

  while (fgets(in_buff, MAX_LINE, xyzin_fil) != NULL) {

    /* strip newlines */
    i = ( strlen(in_buff) < MAX_LINE ) ? strlen(in_buff) : MAX_LINE;
    i--;
    while (in_buff[i] == '\n') {
      in_buff[i] = '\0';
      i--;
    }
    
    /* REMARK */
    if (strncmp(in_buff, "REMARK", 6) == 0) {
      if (sscanf(&in_buff[6], "%3d", &i) != 1) {
	continue;
      }

      /* filter for REMARK  3 */
      if (i != 3) {
	continue;
      }
 
      /* TLS GROUP: <num> */
      if (sscanf(&in_buff[10], " TLS GROUP :%d ", &i) == 1) {
        printf("Reading TLS group %d\n", i);
	fprintf(tlsout_fil, "\n");
	fprintf(tlsout_fil, "TLS\n");
	continue;
      }
      
      /* RESIDUE RANGE : <chn> <res> <chn> <res> */
      if (sscanf(&in_buff[10], " RESIDUE RANGE : %1s %4s %1s %4s", 
		 t1, t2, t3, t4) == 4) {
	fprintf(tlsout_fil, "RANGE  '%1s%4s.' '%1s%4s.' ALL\n", 
		t1, t2, t3, t4);
	continue;
      }

      /* SELECTION: chain <chn> and resid <res>-<res> */
      if (strstr(&in_buff, "SELECTION:") ) {
        i = sscanf(&in_buff[10], " SELECTION: %*[Cc]%*[Hh]%*[Aa]%*[Ii]%*[Nn] %1s %*[Aa]%*[Nn]%*[Dd] %*[Rr]%*[Ee]%*[Ss]%*[Ii]%*[Dd] %[0-9]%*[:-]%[0-9]",
                 t1, t2, t3);
        /*fprintf(tlsout_fil, "RANGE  '%1s%4s.' '%1s%4s.' ALL\n",
                t1, t2, t1, t4); */
           switch (i) {
             case 1:
               fprintf(tlsout_fil,"RANGE  '%1s' ALL\n", t1);
               break;
             case 3:
               fprintf(tlsout_fil,"RANGE  '%1s%4s.' '%1s%4s.' ALL\n", t1, t2, t1, t3);
               break;
             default:
               printf("Could not read SELECTION format\n");
           }
        continue;
      }

      /* ORIGIN FOR THE GROUP (A):  <x> <y> <z> */
      if (sscanf(&in_buff[10], " ORIGIN FOR THE GROUP (A): %f %f %f", 
		 &O[0], &O[1], &O[2]) == 3) {
	fprintf(tlsout_fil, "ORIGIN  %7.3f %7.3f %7.3f\n", O[0], O[1], O[2]);
	continue;
      }

      /* T11: <t11> T22: <t22> */
      if (sscanf(&in_buff[10], " T11: %f T22: %f", &T[0], &T[1]) == 2) {
	continue;
      }
      /* T33: <t33> T12: <t12> */
      if (sscanf(&in_buff[10], " T33: %f T12: %f", &T[2], &T[3]) == 2) {
	continue;
      }
      /* T13: <t13> T23: <t23> */
      if (sscanf(&in_buff[10], " T13: %f T23: %f", &T[4], &T[5]) == 2) {
	continue;
      }

      /* L11: <l11> L22: <l22> */
      if (sscanf(&in_buff[10], " L11: %f L22: %f", &L[0], &L[1]) == 2) {
	continue;
      }
      /* L33: <l33> L12: <l12> */
      if (sscanf(&in_buff[10], " L33: %f L12: %f", &L[2], &L[3]) == 2) {
	continue;
      }
      /* L13: <l13> L23: <l23> */
      if (sscanf(&in_buff[10], " L13: %f L23: %f", &L[4], &L[5]) == 2) {
	continue;
      }

      /* S11: <s11> S12: <s12> S13: <s13> */
      if (sscanf(&in_buff[10], " S11: %f S12: %f S13: %f", 
		 &S[0], &S[1], &S[2]) == 3) {
	continue;
      }
      /* S21: <s21> S22: <s22> S23: <s23> */
      if (sscanf(&in_buff[10], " S21: %f S22: %f S23: %f", 
		 &S[3], &S[4], &S[5]) == 3) {
	continue;
      }
      /* S31: <s31> S32: <s32> S33: <s33> */
      if (sscanf(&in_buff[10], " S31: %f S32: %f S33: %f", 
		 &S[6], &S[7], &S[8]) == 3) {

	fprintf(tlsout_fil, "T   %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f\n",
		T[0], T[1], T[2], T[3], T[4], T[5]);
	fprintf(tlsout_fil, "L   %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f\n",
		L[0], L[1], L[2], L[3], L[4], L[5]);

	/* <S22 - S11> <S11 - S33> <S12> <S13> <S23> <S21> <S31> <S32> */
	fprintf(tlsout_fil, "S   %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f\n",
		S[4]-S[0], S[0]-S[8], S[1], S[2], S[5], S[3], S[6], S[7]);

	fprintf(tlsout_fil, "\n");
      }

    } /* if (REMARK) */

  } /* while */

  fclose (xyzin_fil);
  fclose (tlsout_fil);
  printf("\n");

  ccperror(0,"Normal termination");

  return 0;
}


