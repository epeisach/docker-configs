#!/usr/bin/env python
from __future__ import print_function
# linear.py
# 
# A script to do some linear regression on data from a log-log plot and 
# see what comes out. Will also compute chi^2 based on the errors in real
# space. Will consider in terms of Nm and 0.5 Nm (Nm - 1) - that is the
# number of "baselines".
# 

import math, random

def linreg(coordinates):
    '''Fit a best fit straight line to a list of coordinate pairs.'''

    meanx = sum([c[0] for c in coordinates]) / len(coordinates)
    meany = sum([c[1] for c in coordinates]) / len(coordinates)

    sumxx = 0.0
    sumxy = 0.0

    for x, y in coordinates:
        sumxx += (x - meanx) * (x - meanx)
        sumxy += (x - meanx) * (y - meany)

    m = sumxy / sumxx
    c = meany - meanx * m

    return m, c

def test_linreg():

    coords = []

    for j in range(10):
        coords.append((1.0 * j, 1.0 + 2.8 * j))

    m, c = linreg(coords)

    if math.fabs(m - 2.8) > 0.001:
        raise RuntimeError('m error')

    if math.fabs(c - 1.0) > 0.001:
        raise RuntimeError('c error')

def chi(obs, ers, mods):

    if len(obs) != len(ers):
        raise RuntimeError('chi^2 error')

    if len(mods) != len(ers):
        raise RuntimeError('chi^2 error')

    chisq = 0.0

    for j in range(len(obs)):
        chisq += ((obs[j] - mods[j]) * (obs[j] - mods[j])) / \
                 (ers[j] * ers[j])

    return chisq / len(obs)

def test_chi():

    for p in range(2, 5):

        q = int(math.pow(10, p))

        coords = []
        obs = []
        
        for j in range(q):
            coords.append((1.0 * j, 1.0 + 2.8 * j + random.gauss(0.0, 0.1)))
            obs.append(coords[-1][1])

        m, c = linreg(coords)

        mods = []
        for j in range(q):
            mods.append(m * j + c)

        errs = [0.1 for j in range(q)]

        if math.fabs(chi(obs, errs, mods) - 1.0) > 0.2:
            raise RuntimeError('chi^2 error')


    return

def digest():

    nm = []
    sd = []
    sde = []
    count = 0

    for record in open('test5.dat', 'r').readlines():

        if not record.strip():
            break
        
        data = map(float, record.split())

        nm.append(data[0])
        sd.append(data[5])
        sde.append(data[6])

        count += 1

    # first examine in terms of log-log with the regular Nm
    # values not number of baselines

    coords = []

    for j in range(count):
        coords.append((math.log10(nm[j]), math.log10(sd[j])))

    m, c = linreg(coords)

    model = []

    for j in range(count):
        model.append(math.pow(10.0, c) * pow(10.0, math.log10(nm[j]) * m))

    for j in range(count):
        print(nm[j], sd[j], sde[j], model[j], (model[j] - sd[j]) / sde[j])

    print(m, pow(10.0, c), chi(sd, sde, model))

def digest2():
    '''Same as above but this time in terms of N(N-1)/2.'''
    

    nm = []
    sd = []
    sde = []
    count = 0

    for record in open('test5.dat', 'r').readlines():

        if not record.strip():
            break
        
        data = map(float, record.split())

        nm.append(0.5 * data[0] * (data[0] - 1))
        sd.append(data[5])
        sde.append(data[6])

        count += 1

    # first examine in terms of log-log with the regular Nm
    # values not number of baselines

    coords = []

    for j in range(count):
        coords.append((math.log10(nm[j]), math.log10(sd[j])))

    m, c = linreg(coords)

    model = []

    for j in range(count):
        model.append(math.pow(10.0, c) * pow(10.0, math.log10(nm[j]) * m))

    for j in range(count):
        print(nm[j], sd[j], sde[j], model[j], (model[j] - sd[j]) / sde[j])

    print(m, pow(10.0, c), chi(sd, sde, model))

def justfit():

    fn = []
    sd = []
    sde = []
    count = 0

    for record in open('test13a.dat', 'r').readlines():

        if not record.strip():
            break
        
        data = map(float, record.split())

        fn.append(data[7])
        sd.append(data[5])
        sde.append(data[6])

        count += 1

    coords = []

    for j in range(count):
        coords.append((fn[j], sd[j]))

    m, c = linreg(coords)

    model = []

    for j in range(count):
        model.append(c + m * fn[j])

    for j in range(count):
        print(fn[j], sd[j], sde[j], model[j], (model[j] - sd[j]) / sde[j])

    print('M     C      chi^2')

    print(m, c, chi(sd, sde, model))
    
        
if __name__ == '__main__':
    # test_linreg()
    # test_chi()
    # digest()
    # digest2()
    justfit()
