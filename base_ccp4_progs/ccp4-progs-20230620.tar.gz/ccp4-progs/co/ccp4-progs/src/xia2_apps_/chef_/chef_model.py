#!/usr/bin/env python
from __future__ import print_function
# chef_model.py
# 
# Some routines for modelling the output I expect from chef, based on 
# some random numbers selected from different distributions...
# 
# 13th February 2008

import math
import random

# some useful functions - generators for random numbers of a given
# I/sigma

def generate(number, isigma):
    '''Generete a population of numbers (from a Gaussian distribution)
    with the specified I/sigma. For this purpose, I == 1.0 while sigma is
    1.0 / required I/sigma.'''

    result = []
    for j in range(number):
        result.append(random.gauss(1.0, 1.0 / isigma))

    return result

def wilson(count, multiplicity, isigma):
    '''Generate count separate reflections each with given multiplicity
    which have an I/sigma as given. Mean value will be set as 1.0
    with intensities assigned from a Winson distribution.'''

    reflections = []
    for c in range(count):
        imean = random.expovariate(1.0)
        result = []
        for m in range(multiplicity):
            result.append(random.gauss(imean, imean / isigma))
        reflections.append(result)

    return reflections

def meansd(values):
    '''Compute the mean and standard deviation of a list of values.'''

    mean = sum(values) / len(values)

    sd = 0.0

    for v in values:
        sd += (v - mean) * (v - mean)

    sd = math.sqrt(sd / len(values))

    return mean, sd
        
def rd(values):
    '''Compute a difference-R for this list of values.'''

    top = 0.0
    bottom = 0.0

    count = len(values)

    for i in range(count):
        for j in range(i + 1, count):
            top += math.fabs(values[i] - values[j])
            bottom += 0.5 * (values[i] + values[j])

    return top / bottom

def rd_all(values_list):
    '''Compute a difference-R for this list of lists of values.'''

    top = 0.0
    bottom = 0.0

    for values in values_list:
        count = len(values)
        for i in range(count):
            for j in range(i + 1, count):
                top += math.fabs(values[i] - values[j])
                bottom += 0.5 * (values[i] + values[j])

    return top / bottom

# test number of observations - fix multiplicity to 10
def test1():

    for no in 10, 30, 100, 300, 1000, 3000, 10000:
        means = []
        sds = []
        for q in range(1000):
            diffs = [rd(generate(10, 2.0)) for j in range(no)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)
    
        print('%5d %.3f (%.3f) %.3f (%.3f) %.3f' % \
              (no, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean))

def test2():
    for mult in 2, 3, 4, 5, 7, 10, 15, 20, 25:
        means = []
        sds = []
        for q in range(1000):
            diffs = [rd(generate(mult, 2.0)) for j in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)
    
        print('%5d %.3f (%.3f) %.3f (%.3f) %.3f' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean))

def test2a():
    for mult in 2, 3, 4, 5, 7, 10, 15, 20, 25:
        means = []
        sds = []
        for q in range(1000):
            diffs = [rd(generate(mult, 10.0)) for j in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)
    
        print('%5d %.3f (%.3f) %.3f (%.3f) %.3f' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean))

def test2b():
    fout = open('test2b.log', 'w')
    for mult in range(2, 100):
        means = []
        sds = []
        for q in range(1000):
            diffs = [rd(generate(mult, 10.0)) for j in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)
    
        print('%5d %.3f (%.3f) %.3f (%.3f) %.3f' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean))
        fout.write('%5d %.3f (%.3f) %.3f (%.3f) %.3f\n' % \
                   (mult, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean))

    fout.close()

def test2c():
    fout = open('test2c.log', 'w')

    values = []
    for j in range(2, 30):
        q = int(math.pow(10, 0.08 * j))
        if not q in values and q > 1:
            values.append(q)

    print(values)

    for mult in values:
        means = []
        sds = []
        for q in range(1000):
            diffs = [rd(generate(mult, 10.0)) for j in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)
    
        print('%5d %.3f (%.3f) %.3f (%.3f) %.3f' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean))
        fout.write('%5d %.3f (%.3f) %.3f (%.3f) %.3f\n' % \
                   (mult, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean))

    fout.close()

def test4():
    fout = open('test4.log', 'w')

    for mult in range(2, 21):
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all([generate(mult, 10.0) for j in range(100)])
                     for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (mult, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test5():
    '''As test 4 but with intensities drawn from a Wilson distribution
    (assuming that they are all acentric).'''
    
    fout = open('test5a.log', 'w')

    for mult in range(11, 16):
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(100, mult, 10.0)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (mult, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test6():
    '''This time we are looking to see if there is any dependence
    on I/sigma in the ratios.'''
    
    fout = open('test6.log', 'w')

    for isigma in range(1, 31):
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(100, 5, isigma)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
            
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test7():
    '''As test 5 but this time with weak reflections (e.g. with
    I/sigma = 2).'''
    
    fout = open('test7.log', 'w')

    for mult in range(2, 11):
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(100, mult, 2.0)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
            
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (mult, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (mult, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test8():
    '''As test 5 but fiddling with e.g. No to make sure that these
    are not important...'''
    
    fout = open('test8.log', 'w')

    Nos = []
    for j in range(40):
        q = int(pow(10, 0.1 * (j + 1)))
        if not q in Nos:
            Nos.append(q)

    for No in Nos:
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(No, 5, 10.0)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (No, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (No, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test9():
    '''As test 8 but fiddling with e.g. No to make sure that these
    are not important... and with Nm = 10'''
    
    fout = open('test9.log', 'w')

    Nos = []
    for j in range(10):
        q = int(pow(10, 0.2 * (j + 4)))
        if not q in Nos:
            Nos.append(q)

    for No in Nos:
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(No, 10, 10.0)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (No, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (No, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test10():
    '''As test 9 but fiddling with e.g. other values make sure that these
    are not important... and with Nm = 10, No = 100'''
    
    fout = open('test10.log', 'w')

    for qs in [50, 100, 150, 200, 400, 800]:
        means = []
        sds = []
        for q in range(qs):
            diffs = [rd_all(wilson(100, 5, 10.0)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (qs, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (qs, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test11():
    '''As test 9 but fiddling with e.g. other values make sure that these
    are not important... and with Nm = 10, No = 100'''
    
    fout = open('test11.log', 'w')

    for qs in [50, 100, 150, 200, 400, 800]:
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(100, 5, 10.0)) for k in range(qs)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (qs, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        fout.write('%5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (qs, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def demonstrate():
    '''Show that the calculations I have done thus far work correctly...'''
    
    fout = open('demonstrate.log', 'w')

    for No in [10, 30, 100, 300, 1000, 3000]:
        for Nm in [2, 3, 4, 5, 7, 10, 15, 20]:
            means = []
            sds = []
            for q in range(100):
                diffs = [rd_all(wilson(No, Nm, 10.0)) for k in range(100)]
                mean, sd = meansd(diffs)
                means.append(mean)
                sds.append(sd)
            mean_mean, sd_mean = meansd(means)
            mean_sd, sd_sd = meansd(sds)

            sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                           (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                           (mean_sd / mean_mean)

            expected = math.pow(0.5 * Nm * (Nm - 1), -0.3) * \
                       math.pow(No, -0.5)
    
            print('%5d %5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) [%.4f]' % \
                  (No, Nm, mean_mean, sd_mean, mean_sd, sd_sd,
                   mean_sd / mean_mean, sd, expected))
            fout.write(
                '%5d %5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) [%.4f]\n' % \
                (No, Nm, mean_mean, sd_mean, mean_sd, sd_sd,
                 mean_sd / mean_mean, sd, expected))

    fout.close()

def demonstrate_weak():
    '''Show that the calculations I have done thus far work correctly...'''
    
    fout = open('demonstrate_weak.log', 'w')

    for No in [10, 30, 100, 300, 1000, 3000]:
        for Nm in [2, 3, 4, 5, 7, 10, 15, 20]:
            means = []
            sds = []
            for q in range(100):
                diffs = [rd_all(wilson(No, Nm, 2.0)) for k in range(100)]
                mean, sd = meansd(diffs)
                means.append(mean)
                sds.append(sd)
            mean_mean, sd_mean = meansd(means)
            mean_sd, sd_sd = meansd(sds)

            sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                           (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                           (mean_sd / mean_mean)

            expected = math.pow(0.5 * Nm * (Nm - 1), -0.3) * \
                       math.pow(No, -0.5)

            print('%5d %5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) [%.4f]' % \
                  (No, Nm, mean_mean, sd_mean, mean_sd, sd_sd,
                   mean_sd / mean_mean, sd, expected))
            fout.write(
                '%5d %5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) [%.4f]\n' % \
                (No, Nm, mean_mean, sd_mean, mean_sd, sd_sd,
                 mean_sd / mean_mean, sd, expected))

    fout.close()

def demonstrate_weak_2():
    '''Show that the calculations I have done thus far work correctly...'''
    
    fout = open('demonstrate_weak_2.log', 'w')

    # static calculated for an I/sigma ~ 2
    inflate = 1 + 0.02275 * 3.186

    for No in [10, 30, 100, 300, 1000, 3000]:
        for Nm in [2, 3, 4, 5, 7, 10, 15, 20]:
            means = []
            sds = []
            for q in range(100):
                diffs = [rd_all(wilson(No, Nm, 2.0)) for k in range(100)]
                mean, sd = meansd(diffs)
                means.append(mean)
                sds.append(sd)
            mean_mean, sd_mean = meansd(means)
            mean_sd, sd_sd = meansd(sds)

            sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                           (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                           (mean_sd / mean_mean)

            expected = math.pow(0.5 * Nm * (Nm - 1), -0.295) * \
                       math.pow(No, -0.5) * inflate
    
            q = math.fabs(expected - (mean_sd / mean_mean)) / sd
    
            print('%5d %5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) [%.4f] = %.4f' \
                   (No, Nm, mean_mean, sd_mean, mean_sd, sd_sd,
                     mean_sd / mean_mean, sd, expected, q))
            fout.write(
                '%5d %5d %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) [%.4f] = %.4f\n' \
                % (No, Nm, mean_mean, sd_mean, mean_sd, sd_sd,
                   mean_sd / mean_mean, sd, expected, q))

    fout.close()

def test12():
    '''This time we are looking to see if there is any dependence
    on I/sigma in the ratios, and in fine steps 1 - 5'''
    
    fout = open('test12.log', 'w')

    for jsigma in range(10, 51):
        isigma = 0.1 * jsigma
        means = []
        sds = []
        for q in range(100):
            diffs = [rd_all(wilson(100, 5, isigma)) for k in range(100)]
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
            
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       
    
        print('%5.1f %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)' % \
              (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd))
        
        fout.write('%5.1f %.4f (%.5f) %.4f (%.5f) %.4f (%.4f)\n' % \
                   (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd))

    fout.close()

def test13():
    '''This time we are looking to see if there is any dependence
    on I/sigma in the ratios, and in fine steps 1 - 5. Different to
    previous examples, count how many of the reflections (as a %age) are
    negative.'''
    
    fout = open('test13.log', 'w')

    for jsigma in range(10, 51):
        isigma = 0.1 * jsigma
        means = []
        sds = []
        neg = 0
        pos = 0
        for q in range(100):
            diffs = []
            for k in range(100):
                w = wilson(100, 5, isigma)
                for x in w:
                    for y in x:
                        if y > 0:
                            pos += 1
                        else:
                            neg += 1
                diffs.append(rd_all(w))
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
            
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       

        nfrac = 100.0 * float(neg) / float(neg + pos)
    
        print('%5.1f %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) %.4f' % \
              (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd, nfrac))
        
        fout.write('%5.1f %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) %.4f\n' % \
                   (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd, nfrac))

    fout.close()

def test13a():
    '''This time we are looking to see if there is any dependence
    on I/sigma in the ratios, and in fine steps 1 - 5. Different to
    previous examples, count how many of the reflections (as a %age) are
    negative. Now with better sampling for low I/sigma values.'''
    
    fout = open('test13a.log', 'w')

    for jsigma in range(50, 501):
        isigma = 0.01 * jsigma
        means = []
        sds = []
        neg = 0
        pos = 0
        for q in range(100):
            diffs = []
            for k in range(100):
                w = wilson(100, 5, isigma)
                for x in w:
                    for y in x:
                        if y > 0:
                            pos += 1
                        else:
                            neg += 1
                diffs.append(rd_all(w))
            mean, sd = meansd(diffs)
            means.append(mean)
            sds.append(sd)
            
        mean_mean, sd_mean = meansd(means)
        mean_sd, sd_sd = meansd(sds)

        sd = math.sqrt((sd_mean / mean_mean) * (sd_mean / mean_mean) +
                       (sd_sd / mean_sd) * (sd_sd / mean_sd)) * \
                       (mean_sd / mean_mean)
                       

        nfrac = 1.0 * float(neg) / float(neg + pos)
    
        print('%5.2f %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) %.6f' % \
              (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
               mean_sd / mean_mean, sd, nfrac))
        
        fout.write('%5.2f %.4f (%.5f) %.4f (%.5f) %.4f (%.4f) %.6f\n' % \
                   (isigma, mean_mean, sd_mean, mean_sd, sd_sd,
                    mean_sd / mean_mean, sd, nfrac))
        
    fout.close()



if __name__ == '__main__':
    # test13a()
    demonstrate_weak_2()
    
    


