./chef hklin1 test.mtz << eof
labin BASE=BATCH
print comp rdcu chi
sdcorrection 1.5 0.0 0.0
range width 1.0 max 50.0
end
eof

