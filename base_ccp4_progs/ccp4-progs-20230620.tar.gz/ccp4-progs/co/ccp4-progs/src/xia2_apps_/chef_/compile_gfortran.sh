#!/bin/bash
# compile chef...

gfortran -g -ffpe-trap=invalid,zero,overflow -Wall -o chef \
accumulate.f \
chef.f \
chef_init.f \
chef_rd.f \
chef_rdc.f \
chef_rsym.f \
chef_rmerge.f \
command.f \
rmerge.f \
chisq.f \
nref.f \
meansd.f \
merge.f \
chef_model.f \
chef_chi.f \
-L$CLIB -lccp4f -lccp4c

