The source code for support applications for xia2:

symop2mat
mat2symop
doser
chef

