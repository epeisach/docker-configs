/*
     PDBHTF PDB html filter
     Copyright (C) 1998 Guoguang Lu

     This code is distributed under the terms and conditions of the
     CCP4 Program Suite Licence Agreement as a CCP4 Application.
     A copy of the CCP4 licence can be obtained by writing to the
     CCP4 Secretary, Daresbury Laboratory, Warrington WA4 4AD, UK.
*/
#define EOF -1
#include <stdio.h>

main () /* PDB html filter Gugouang 980301 */
  {
   int cut,out,flag,c;
   int o1,o2;
   out=cut=flag=0;
   o1=o2=0;
   while ((c = getchar()) != EOF) {
    if (o1=='&') {
                if (o2=='L') {
                 if (c=='T') {putchar('<'); o1=0; o2=0;}
                 else {
                  putchar(o1); putchar(o2); putchar(c);
                  o1=0; o2=0; 
                      }
                             }
                else if (o2=='G') {
                 if (c=='T') {putchar('>'); o1=0; o2=0;}
                 else {
                   putchar(o1); putchar(o2); putchar(c);
                   o1=0; o2=0; 
                      }
                                  }
                else if (c=='G') o2=c ;
                else if (c=='L') o2=c ;
                else {putchar(o1); putchar(c); o1 = 0; o2=0;}
                }
    else if (c=='&' && flag<=0) {o1=c; o2=0;}
    else {
    if (c=='<') flag++;
    if (flag<=0) {
     out++; 
     if (out > 24) putchar(c);}
    else cut++; 
    if (c=='>') flag--;
    if (flag<0) flag=0; 
         }
                                  }
   }
